import { Routes, Route, Navigate, useParams } from 'react-router'
import Layout from './components/Layout'
import Home from './pages/Home'
import Courses from './pages/Courses'
import Category from './pages/Category'
import CourseDetail from './pages/CourseDetail'
import ForeignEmployment from './pages/ForeignEmployment'
import Certification from './pages/Certification'
import Corporate from './pages/Corporate'
import SuccessStories from './pages/SuccessStories'
import GraduateRegistry from './pages/GraduateRegistry'
import Blog from './pages/Blog'
import BlogPost from './pages/BlogPost'
import About from './pages/About'
import Contact from './pages/Contact'
import NotFound from './pages/NotFound'
import { categoryBySlug } from './data/categories'
import { courseBySlug, coursePath } from './data/courses'

/**
 * Legacy single-segment /courses/:segment/ resolver:
 * - category slug  → static category page
 * - course slug    → 301-style <Navigate replace> to the canonical nested URL
 * - anything else  → NotFound
 */
function CoursesSegment() {
  const { segment } = useParams<{ segment: string }>()
  const category = segment ? categoryBySlug(segment) : undefined
  if (category) return <Category category={category} />
  const course = segment ? courseBySlug(segment) : undefined
  if (course) return <Navigate to={coursePath(course)} replace />
  return <NotFound />
}

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="courses" element={<Courses />} />
        <Route path="courses/:categorySlug/:courseSlug" element={<CourseDetail />} />
        <Route path="courses/:segment" element={<CoursesSegment />} />
        <Route path="foreign-employment-preparation" element={<ForeignEmployment />} />
        <Route path="skill-test-and-certification" element={<Certification />} />
        <Route path="corporate-and-group-training" element={<Corporate />} />
        <Route path="success-stories" element={<SuccessStories />} />
        <Route path="graduate-registry" element={<GraduateRegistry />} />
        <Route path="blog" element={<Blog />} />
        <Route path="blog/:slug" element={<BlogPost />} />
        <Route path="about" element={<About />} />
        <Route path="contact-and-counseling" element={<Contact />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  )
}
