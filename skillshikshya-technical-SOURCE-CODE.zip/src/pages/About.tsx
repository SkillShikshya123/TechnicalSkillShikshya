import { useEffect, useRef } from "react";
import { Link } from "react-router";
import { motion } from "framer-motion";
import { Award, Clock, FileCheck, MapPin, Phone, ShieldCheck, Users } from "lucide-react";
import SEO, { aboutPageJsonLd, breadcrumbJsonLd, orgJsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import SectionEyebrow from "@/components/SectionEyebrow";
import StatBlock from "@/components/StatBlock";
import TrustBadgePill from "@/components/TrustBadgePill";
import BadgeChip from "@/components/BadgeChip";
import Reveal from "@/components/Reveal";
import { instructors } from "@/data/instructors";
import { site } from "@/data/site";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";

const H1_WORDS = ["We", "train", "people", "for", "work", "that", "actually", "hires"];

const ACCREDITATIONS = [
  { icon: ShieldCheck, label: "CTEVT Affiliated — Reg. No. 2018-KTM-0421" },
  { icon: Award, label: "NSTB Partner" },
  { icon: FileCheck, label: "Ministry of Labour & Employment Accredited" },
];

const STATS = [
  { value: 2000, suffix: "+", label: "Graduates" },
  { value: 90, suffix: "%+", label: "Placement Rate" },
  { value: 10, suffix: "", label: "Trade Courses" },
  { value: 30, suffix: "+", label: "Employer Partners" },
];

const TIMELINE = [
  { year: "2018", label: "Founded, first electrician batch" },
  { year: "2020", label: "CTEVT affiliation granted" },
  { year: "2022", label: "Beauty & Hospitality labs open" },
  { year: "2024", label: "G2G caregiver pathway begins" },
  { year: "2026", label: "2,000th graduate placed" },
];

const MAPS_URL =
  "https://www.google.com/maps/search/?api=1&query=SkillShikshya+Technical+Center+Opposite+Civil+Hospital+New+Baneshwar+Kathmandu";

/** Section 1 — hero + mission: word-split H1, accreditation pills, campus image. */
function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo("[data-fade]", { opacity: 0 }, { opacity: 1, duration: 0.5, stagger: 0.08 });
        return;
      }
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
      tl.fromTo(
        "[data-word] > span",
        { yPercent: 110 },
        { yPercent: 0, duration: 0.7, stagger: 0.06 },
        0.15,
      )
        .fromTo(
          "[data-hl]",
          { "--hl-scale": 0 },
          { "--hl-scale": 1, duration: 0.5, ease: "power2.out" },
          0.85,
        )
        .fromTo("[data-lead]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 1.0)
        .fromTo(
          "[data-pill]",
          { opacity: 0, scale: 0.8 },
          { opacity: 1, scale: 1, duration: 0.4, stagger: 0.08, ease: "back.out(2)" },
          1.1,
        )
        .fromTo(
          "[data-clip]",
          { clipPath: "inset(0 0 0 100%)" },
          { clipPath: "inset(0 0 0 0%)", duration: 0.9, ease: "power3.out" },
          0.3,
        );
      // Gentle parallax on the campus image
      gsap.to("[data-hero-img]", {
        y: -25,
        ease: "none",
        scrollTrigger: { trigger: el, start: "top top", end: "bottom top", scrub: true },
      });
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <section ref={sectionRef} className="overflow-hidden bg-forest bg-stripes" aria-label="About SkillShikshya Technical">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-16 md:px-8 md:py-20 lg:grid-cols-2">
        <div>
          <Breadcrumbs dark items={[{ label: "Home", to: "/" }, { label: "About" }]} />
          <SectionEyebrow dark className="mt-6">
            — ABOUT US
          </SectionEyebrow>
          <h1 className="mt-4 font-heading text-[34px] font-extrabold leading-[1.1] text-white md:text-[52px] md:leading-[1.05]">
            {H1_WORDS.map((w, i) => (
              <span key={i} data-word className="mr-[0.28em] inline-block overflow-hidden align-bottom last:mr-0">
                <span className="inline-block will-change-transform">
                  {i >= 6 ? (
                    <span
                      className="hl-underline"
                      data-hl
                      style={{ ["--hl-scale" as never]: reduced ? 1 : 0 }}
                    >
                      {w}
                    </span>
                  ) : (
                    w
                  )}
                </span>
              </span>
            ))}
          </h1>
          <p data-lead data-fade className="mt-5 max-w-xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
            SkillShikshya Technical is a CTEVT registered training centre in Kathmandu — a hands-on
            vocational training institute in New Baneshwar, opposite Civil Hospital. Since 2018, our
            measure of success has been simple: a job or self-employment for every graduate — not
            portfolio projects.
          </p>
          <div className="mt-8 flex flex-wrap gap-2.5">
            {ACCREDITATIONS.map((a) => (
              <span key={a.label} data-pill data-fade>
                <TrustBadgePill icon={a.icon} label={a.label} dark />
              </span>
            ))}
          </div>
        </div>
        <div data-clip className="overflow-hidden rounded-2xl shadow-lift">
          <img
            data-hero-img
            src="/about-campus.webp"
            alt="SkillShikshya Technical training center in New Baneshwar, Kathmandu"
            className="aspect-video w-full scale-110 object-cover"
          />
        </div>
      </div>
    </section>
  );
}

/** Section 3 — horizontal mini-timeline (vertical on mobile) with drawn line + popping nodes. */
function StoryTimeline() {
  const reduced = usePrefersReducedMotion();
  return (
    <div className="relative mx-auto mt-14 max-w-3xl md:max-w-6xl">
      {/* horizontal line (desktop) */}
      <motion.div
        aria-hidden="true"
        className="absolute left-0 right-0 top-[7px] hidden h-0.5 bg-border-soft md:block"
        initial={{ scaleX: reduced ? 1 : 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: true, amount: 0.6 }}
        transition={{ duration: 1, ease: "easeOut" }}
        style={{ transformOrigin: "left" }}
      />
      {/* vertical line (mobile) */}
      <motion.div
        aria-hidden="true"
        className="absolute bottom-0 left-[7px] top-0 w-0.5 bg-border-soft md:hidden"
        initial={{ scaleY: reduced ? 1 : 0 }}
        whileInView={{ scaleY: 1 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 1, ease: "easeOut" }}
        style={{ transformOrigin: "top" }}
      />
      <ol className="grid gap-8 md:grid-cols-5 md:gap-6">
        {TIMELINE.map((e, i) => (
          <li key={e.year} className="relative pl-8 md:pl-0 md:pt-8">
            <motion.span
              aria-hidden="true"
              className="absolute left-0 top-1 h-4 w-4 rounded-full border-2 border-amber bg-white md:top-0"
              initial={{ scale: reduced ? 1 : 0 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{ delay: i * 0.15, type: "spring", bounce: 0.5 }}
            />
            <p className="font-heading text-xl font-bold text-forest">{e.year}</p>
            <p className="mt-1 text-sm leading-relaxed text-muted">{e.label}</p>
          </li>
        ))}
      </ol>
    </div>
  );
}

export default function About() {
  const reduced = usePrefersReducedMotion();

  return (
    <>
      <SEO
        title="About SkillShikshya — CTEVT Registered Training Centre in Kathmandu, New Baneshwar"
        description="SkillShikshya Technical: a CTEVT registered training centre in Kathmandu and vocational training institute in New Baneshwar — 2,000+ graduates, 90%+ placement since 2018."
        path="/about/"
        jsonLd={[
          aboutPageJsonLd(),
          orgJsonLd(),
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "About", path: "/about/" },
          ]),
        ]}
      />

      {/* 1 — Hero + mission */}
      <Hero />

      {/* 2 — Stats band */}
      <section className="bg-mint" aria-label="Institute statistics">
        <div className="mx-auto max-w-6xl px-5 py-12 md:px-8 md:py-16">
          <Reveal y={24} stagger={0.1}>
            <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:grid-cols-5 lg:divide-x lg:divide-border-soft">
              {/* Year shown statically — no count-up for a founding year */}
              <div className="text-center md:text-left">
                <p className="font-heading text-[44px] font-bold leading-none text-forest md:text-[52px]">
                  2018
                </p>
                <p className="mt-2 font-mono text-xs font-medium uppercase tracking-[0.12em] text-muted">
                  Founded
                </p>
              </div>
              {STATS.map((s, i) => (
                <StatBlock
                  key={s.label}
                  value={s.value}
                  suffix={s.suffix}
                  label={s.label}
                  delay={0.15 * (i + 1)}
                  className="lg:pl-6"
                />
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* 3 — Our story + timeline */}
      <section className="bg-white" aria-label="Our story">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
          <Reveal className="mx-auto max-w-3xl text-center" stagger={0.12} y={24}>
            <div>
              <SectionEyebrow center>— OUR STORY</SectionEyebrow>
              <h2 className="mt-3 font-heading text-3xl font-bold text-ink md:text-[40px] md:leading-[1.1]">
                From one workshop to Kathmandu's trade-skill hub
              </h2>
            </div>
            <p className="mt-6 text-[17px] leading-[1.65] text-muted">
              SkillShikshya Technical was founded in 2018 in New Baneshwar, Kathmandu with a single
              electrical wiring lab and one belief: training only counts if it leads to work.
            </p>
            <p className="mt-4 text-[17px] leading-[1.65] text-muted">
              As foreign-employment demand grew, we expanded into beauty, hospitality, and care
              training — building real workshop labs instead of adding more classroom slides.
            </p>
            <p className="mt-4 text-[17px] leading-[1.65] text-muted">
              Today we run 10 courses across 4 trade categories, with graduates working in 7+
              countries — and we still measure ourselves by placements, not certificates.
            </p>
          </Reveal>
          <StoryTimeline />
        </div>
      </section>

      {/* 4 — Meet the instructors */}
      <section className="bg-mint" aria-label="Meet the instructors">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
          <SectionEyebrow>— THE TEAM</SectionEyebrow>
          <h2 className="mt-3 font-heading text-3xl font-bold text-ink md:text-[40px]">
            Learn from people who still do the work
          </h2>
          <Reveal className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4" stagger={0.12}>
            {instructors.map((t) => (
              <div key={t.id} className="group">
                <div className="relative overflow-hidden rounded-2xl">
                  <img
                    src={t.image}
                    alt={`${t.name}, ${t.role} instructor at SkillShikshya Technical`}
                    loading="lazy"
                    className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-forest/90 to-transparent p-4 pt-12">
                    <p className="translate-y-2 text-sm text-forest-body opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                      {t.credential}
                    </p>
                  </div>
                </div>
                <div className="mt-4 flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-heading text-lg font-semibold text-ink">{t.name}</h3>
                    <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-amber">
                      {t.role}
                    </p>
                  </div>
                  <BadgeChip label={`${t.yearsExp} YRS EXP`} variant="soft" />
                </div>
                <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-muted">{t.bio}</p>
              </div>
            ))}
            {/* 4th "office" card — Counseling & Placement Desk */}
            <div className="flex h-full flex-col justify-center rounded-2xl border border-border-soft bg-white p-6 shadow-soft">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-soft">
                <Users className="h-6 w-6 text-brand" />
              </span>
              <h3 className="mt-4 font-heading text-lg font-semibold text-ink">
                Counseling &amp; Placement Desk
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                Our counselors handle batch scheduling, NSTB registration guidance, and employer
                introductions.
              </p>
            </div>
          </Reveal>
          <p className="mt-8 text-center text-sm italic text-muted">
            Small team, active professionals — that's deliberate.
          </p>
        </div>
      </section>

      {/* 5 — Facility & location */}
      <section className="bg-white" aria-label="Facility and location">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-16 md:px-8 md:py-24 lg:grid-cols-2">
          <Reveal y={24} stagger={0.1}>
            <div>
              <h2 className="font-heading text-3xl font-bold text-ink md:text-[40px]">
                Our training facility in New Baneshwar
              </h2>
              <p className="mt-4 max-w-xl text-[17px] leading-[1.65] text-muted">
                Purpose-built workshop labs in New Baneshwar — electrical wiring bays, carpentry
                benches, a working café simulator for barista training, salon stations, and a
                caregiver practice room.
              </p>
              <ul className="mt-7 space-y-3">
                <li className="flex items-center gap-3 text-[15px] text-ink">
                  <MapPin className="h-5 w-5 shrink-0 text-brand" />
                  Opposite Civil Hospital, New Baneshwar, Kathmandu
                </li>
                <li className="flex items-center gap-3 text-[15px] text-ink">
                  <Clock className="h-5 w-5 shrink-0 text-brand" />
                  {site.contact.hours}
                </li>
                <li className="flex items-center gap-3 text-[15px] text-ink">
                  <Phone className="h-5 w-5 shrink-0 text-brand" />
                  {site.contact.phoneLandline}
                </li>
              </ul>
            </div>
          </Reveal>
          <motion.div
            initial={reduced ? { opacity: 0 } : { opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="rounded-2xl bg-mint p-8 text-center shadow-soft"
          >
            <motion.span
              className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-white shadow-soft"
              initial={reduced ? {} : { y: -8 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4, duration: 0.5, type: "spring", bounce: 0.5 }}
            >
              <MapPin className="h-7 w-7 text-brand" />
            </motion.span>
            <p className="mt-5 font-heading text-lg font-semibold text-ink">
              SkillShikshya Technical Center
            </p>
            <p className="mt-1 text-sm text-muted">
              Opposite Civil Hospital, New Baneshwar, Kathmandu
            </p>
            <a
              href={MAPS_URL}
              target="_blank"
              rel="noreferrer"
              className="mt-5 inline-flex items-center gap-1.5 font-semibold text-brand transition-colors hover:text-brand-dark"
            >
              Get Directions
              <span aria-hidden="true">→</span>
            </a>
          </motion.div>
        </div>
      </section>

      {/* 6 — CTA variant (about.md §6) */}
      <section className="bg-forest bg-stripes" aria-label="Visit the institute">
        <motion.div
          className="mx-auto max-w-4xl px-5 py-16 text-center md:px-8 md:py-24"
          initial={reduced ? { opacity: 0 } : { opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        >
          <SectionEyebrow dark>— SEE IT IN PERSON</SectionEyebrow>
          <h2 className="mt-4 font-heading text-3xl font-bold text-white md:text-[40px] md:leading-[1.1]">
            Come see the workshops yourself.
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
            Visit us any working day, or book a free counseling session first.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              to="/contact-and-counseling/"
              className="rounded-xl bg-amber px-7 py-3.5 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
            >
              Get Free Career Counseling
            </Link>
            <a
              href={`tel:${site.contact.phoneLandline}`}
              className="flex items-center gap-2 rounded-xl border border-white/40 px-7 py-3.5 font-semibold text-white transition-colors hover:border-white hover:bg-white/5"
            >
              <Phone className="h-4 w-4" />
              Call {site.contact.phoneLandline}
            </a>
          </div>
        </motion.div>
      </section>
    </>
  );
}
