import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Coffee,
  Wrench,
  Users,
  HeartHandshake,
  CheckCircle2,
  MessageCircle,
  Phone,
  ClipboardList,
  BookOpen,
  Award,
} from "lucide-react";
import SEO, { breadcrumbJsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import SectionEyebrow from "@/components/SectionEyebrow";
import TrustBadgePill from "@/components/TrustBadgePill";
import StepCard from "@/components/StepCard";
import FormField from "@/components/FormField";
import Reveal from "@/components/Reveal";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";
import { scrollToTarget } from "@/lib/scroll";
import { site } from "@/data/site";

const PAGE_PATH = "/corporate-and-group-training/";

const AUDIENCES = [
  {
    icon: Coffee,
    title: "Hotels & Cafes",
    description: "Specialty espresso extraction, sensory training, and service soft skills for your F&B crew.",
  },
  {
    icon: Wrench,
    title: "Construction Firms",
    description: "National Electric Code wiring, safety compliance, and equipment operation for site teams.",
  },
  {
    icon: Users,
    title: "NGOs & Agencies",
    description: "An experienced NGO vocational training partner — tailored batches for community empowerment and livelihood projects.",
  },
  {
    icon: HeartHandshake,
    title: "Care Providers",
    description: "Professional caregiver cohorts trained to the G2G syllabus standard.",
  },
];

const STEPS = [
  {
    icon: ClipboardList,
    number: "01",
    title: "Identify Skill Gap",
    description: "Tell us where your team's skills fall short; we audit and map training needs.",
  },
  {
    icon: BookOpen,
    number: "02",
    title: "Custom Curriculum",
    description: "We build a syllabus around your equipment, standards, and schedule.",
  },
  {
    icon: Wrench,
    number: "03",
    title: "Practical Training",
    description: "Hands-on sessions in our Baneshwar labs or on your site.",
  },
  {
    icon: Award,
    number: "04",
    title: "Certification & Audit",
    description: "CTEVT-recognized completion certification plus a skills audit report.",
  },
];

const SKILL_AREAS = [
  { value: "barista-hospitality", label: "Barista & Hospitality" },
  { value: "electrical-construction", label: "Electrical & Construction" },
  { value: "beauty-wellness", label: "Beauty & Wellness" },
  { value: "caregiving", label: "Caregiving" },
  { value: "other", label: "Other — custom" },
];

const COHORT_SIZES = [
  { value: "5-10", label: "5–10" },
  { value: "11-20", label: "11–20" },
  { value: "21-50", label: "21–50" },
  { value: "50+", label: "50+" },
];

/* ---------- Section 1 — Hero ---------- */
function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo("[data-corp-fade]", { opacity: 0 }, { opacity: 1, duration: 0.5, stagger: 0.08 });
        return;
      }
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
      tl.fromTo(
        "[data-word] > span",
        { yPercent: 110 },
        { yPercent: 0, duration: 0.7, stagger: 0.06 },
        0.15,
      )
        .fromTo("[data-corp-lead]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5 }, 0.5)
        .fromTo(
          "[data-corp-pill]",
          { opacity: 0, scale: 0.8 },
          { opacity: 1, scale: 1, duration: 0.4, stagger: 0.07, ease: "back.out(2)" },
          0.7,
        )
        .fromTo("[data-corp-ctas]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5 }, 0.85);
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  const fade = reduced ? { "data-corp-fade": true } : {};

  return (
    <section ref={ref} className="relative overflow-hidden bg-forest bg-stripes" aria-label="Corporate and group training">
      <div
        className="pointer-events-none absolute -right-40 -top-40 h-[560px] w-[560px] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(242,169,59,0.08) 0%, transparent 65%)" }}
      />
      <div className="mx-auto max-w-6xl px-5 pb-16 pt-12 md:px-8 md:pb-20 md:pt-16">
        <Breadcrumbs
          dark
          className={reduced ? undefined : "opacity-0"}
          {...fade}
          items={[{ label: "Home", to: "/" }, { label: "Corporate & Group Training" }]}
        />
        <div className="mt-8 max-w-3xl">
          <SectionEyebrow dark>— FOR ORGANIZATIONS</SectionEyebrow>
          <h1 className="mt-5 font-heading text-[34px] font-extrabold leading-[1.1] text-white md:text-[56px] md:leading-[1.05]">
            {["Corporate", "Vocational", "Training", "in", "Nepal"].map((w, i) => (
              <span key={i} data-word className="mr-[0.28em] inline-block overflow-hidden align-bottom last:mr-0">
                <span className="inline-block will-change-transform">{w}</span>
              </span>
            ))}
          </h1>
          <p data-corp-lead {...fade} className="mt-5 max-w-2xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
            Staff skill training for companies across Nepal: upskill your restaurant crew in specialty
            barista work, your construction team in code-compliant electrical wiring, or your care
            staff to the G2G caregiver syllabus. We deliver group vocational training in our Kathmandu
            labs or as on-site trade training at your workplace — and partner with NGOs on livelihood
            and community empowerment projects.
          </p>
          <div data-corp-ctas {...fade} className="mt-7 flex flex-col gap-4 sm:flex-row">
            <button
              onClick={() => scrollToTarget("#proposal-form")}
              className="rounded-xl bg-amber px-7 py-3.5 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
            >
              Request a Proposal
            </button>
            <a
              href={`tel:${site.contact.phoneLandline.replace(/-/g, "")}`}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/40 px-7 py-3.5 font-semibold text-white transition-colors hover:border-white hover:bg-white/5"
            >
              <Phone className="h-4 w-4" />
              Call {site.contact.phoneLandline}
            </a>
          </div>
          <div className="mt-9 flex flex-wrap gap-2.5">
            {[
              { icon: BookOpen, label: "Custom Curriculum" },
              { icon: Wrench, label: "On-site or In-lab" },
              { icon: Award, label: "Cohort Certification" },
            ].map((p) => (
              <span key={p.label} data-corp-pill {...fade}>
                <TrustBadgePill icon={p.icon} label={p.label} dark />
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- Section 3 — Custom batch steps with dashed connector ---------- */
function BatchSteps() {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo(
          "[data-batch-step]",
          { opacity: 0 },
          { opacity: 1, duration: 0.4, stagger: 0.1, scrollTrigger: { trigger: el, start: "top 85%", once: true } },
        );
        return;
      }
      // Dashed connector draws left → right
      gsap.fromTo(
        "[data-batch-line]",
        { scaleX: 0 },
        {
          scaleX: 1,
          duration: 0.9,
          ease: "power2.inOut",
          scrollTrigger: { trigger: el, start: "top 85%", once: true },
        },
      );
      // Step cards pop in sequence
      gsap.fromTo(
        "[data-batch-step]",
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          stagger: 0.12,
          ease: "back.out(1.6)",
          scrollTrigger: { trigger: el, start: "top 85%", once: true },
        },
      );
      // Mono number tick 0 → step number
      gsap.utils.toArray<HTMLElement>("[data-batch-step]").forEach((card, i) => {
        const num = card.querySelector<HTMLElement>("span");
        if (!num) return;
        const counter = { v: 0 };
        gsap.to(counter, {
          v: i + 1,
          duration: 0.7,
          delay: i * 0.12,
          ease: "power2.out",
          snap: { v: 1 },
          onUpdate: () => {
            num.textContent = String(Math.round(counter.v)).padStart(2, "0");
          },
          scrollTrigger: { trigger: el, start: "top 85%", once: true },
        });
      });
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <div ref={ref} className="relative mt-12">
      <div
        data-batch-line
        className="absolute left-0 right-0 top-1/2 hidden origin-left border-t-2 border-dashed border-amber/60 md:block"
        aria-hidden="true"
      />
      <div className="relative grid gap-6 sm:grid-cols-2 lg:grid-cols-4 md:gap-8">
        {STEPS.map((s) => (
          <div key={s.number} data-batch-step>
            <StepCard number={s.number} title={s.title} description={s.description} className="h-full" />
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Section 4 — Proposal request form ---------- */
function ProposalForm() {
  const [org, setOrg] = useState("");
  const [person, setPerson] = useState("");
  const [phone, setPhone] = useState("");
  const [skillArea, setSkillArea] = useState("");
  const [cohort, setCohort] = useState("");
  const [errors, setErrors] = useState<{
    org?: string;
    person?: string;
    phone?: string;
    skillArea?: string;
    cohort?: string;
  }>({});
  const [submitted, setSubmitted] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs: typeof errors = {};
    if (!org.trim()) errs.org = "Please enter your organization name";
    if (!person.trim()) errs.person = "Please enter a contact person name";
    if (!/^(9\d{9}|0\d{8,9}|\d{7,10})$/.test(phone.replace(/[\s-]/g, "")))
      errs.phone = "Enter a valid Nepali phone number (e.g. 98XXXXXXXX)";
    if (!skillArea) errs.skillArea = "Please choose a skill area";
    if (!cohort) errs.cohort = "Please choose an approximate cohort size";
    setErrors(errs);
    if (Object.keys(errs).length === 0) setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="flex flex-col items-center py-10 text-center">
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", bounce: 0.5 }}>
          <CheckCircle2 className="h-14 w-14 text-brand" />
        </motion.div>
        <h3 className="mt-4 font-heading text-lg font-semibold text-ink">Proposal request received!</h3>
        <p className="mt-2 max-w-md text-sm text-muted">
          Our corporate training manager will contact you within 1 business day.
        </p>
        <a
          href={site.contact.whatsapp}
          target="_blank"
          rel="noreferrer"
          className="mt-5 inline-flex items-center gap-2 rounded-xl bg-whatsapp px-5 py-2.5 text-sm font-semibold text-white"
        >
          <MessageCircle className="h-4 w-4" />
          Follow up instantly on WhatsApp
        </a>
      </div>
    );
  }

  return (
    <form onSubmit={submit} noValidate className="mt-8 space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField
          label="Organization Name"
          value={org}
          onChange={setOrg}
          placeholder="Your company, NGO or institution"
          error={errors.org}
          required
          name="organization"
        />
        <FormField
          label="Contact Person Name"
          value={person}
          onChange={setPerson}
          placeholder="Who should we speak with?"
          error={errors.person}
          required
          name="contact-person"
        />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField
          label="Contact Phone Number"
          type="tel"
          value={phone}
          onChange={setPhone}
          placeholder="98XXXXXXXX"
          error={errors.phone}
          required
          name="phone"
        />
        <FormField
          label="Skill Area of Interest"
          type="select"
          value={skillArea}
          onChange={setSkillArea}
          placeholder="Select a skill area"
          options={SKILL_AREAS}
          error={errors.skillArea}
          required
          name="skill-area"
        />
      </div>
      <FormField
        label="Approximate Cohort Size"
        type="select"
        value={cohort}
        onChange={setCohort}
        placeholder="Select cohort size"
        options={COHORT_SIZES}
        error={errors.cohort}
        required
        name="cohort-size"
      />
      <button
        type="submit"
        className="w-full rounded-xl bg-amber px-6 py-3.5 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
      >
        Submit Request for Proposal
      </button>
      <p className="text-center text-xs text-muted">Our manager will reply within 1 business day.</p>
    </form>
  );
}

/* ---------- Page ---------- */
export default function Corporate() {
  return (
    <>
      <SEO
        title="Corporate Vocational Training Nepal — Group Skill Training for Businesses & NGOs | SkillShikshya Technical"
        description="Corporate vocational training in Nepal for hotels, cafes, construction firms, care providers & NGOs. Group training in Kathmandu labs or on-site, CTEVT-certified cohort audits."
        path={PAGE_PATH}
        jsonLd={[
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Corporate & Group Training", path: PAGE_PATH },
          ]),
          {
            "@context": "https://schema.org",
            "@type": "Service",
            name: "Corporate & Group Vocational Training",
            description:
              "Custom CTEVT-certified vocational training batches for hotels, cafes, construction firms, care providers and NGOs in Nepal — on-site or in-lab, with cohort certification and skills audit.",
            provider: {
              "@type": "Organization",
              name: site.name,
              sameAs: site.url,
            },
            areaServed: { "@type": "Country", name: "Nepal" },
            url: `${site.url}${PAGE_PATH}`,
          },
        ]}
      />

      {/* 1 — Hero */}
      <Hero />

      {/* 2 — Institutions, Businesses, and NGOs */}
      <section className="bg-white py-16 md:py-24" aria-label="Who we train">
        <div className="mx-auto max-w-6xl px-5 md:px-8">
          <Reveal className="max-w-2xl" stagger={0.12}>
            <SectionEyebrow>— WHO WE TRAIN</SectionEyebrow>
            <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
              Staff skill training for every kind of organization
            </h2>
          </Reveal>
          <Reveal className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4 md:gap-8" stagger={0.1}>
            {AUDIENCES.map((a) => (
              <div
                key={a.title}
                className="group rounded-2xl border border-border-soft bg-white p-6 shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-mint transition-colors duration-300 group-hover:bg-brand">
                  <a.icon className="h-6 w-6 text-brand transition-colors duration-300 group-hover:text-white" />
                </div>
                <h3 className="mt-4 font-heading text-xl font-semibold text-ink">{a.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{a.description}</p>
              </div>
            ))}
          </Reveal>
        </div>
      </section>

      {/* 3 — How to Set Up a Custom Batch */}
      <section className="bg-mint py-16 md:py-24" aria-label="Custom batch process">
        <div className="mx-auto max-w-6xl px-5 md:px-8">
          <div className="flex flex-col items-start justify-between gap-8 md:flex-row md:items-center">
            <Reveal className="max-w-2xl" stagger={0.12}>
              <SectionEyebrow>— THE PROCESS</SectionEyebrow>
              <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
                How to Set Up On-Site Trade Training or a Group Batch
              </h2>
            </Reveal>
            <Reveal y={24}>
              <img
                src="/about-campus.webp"
                alt="SkillShikshya Technical training center in New Baneshwar, Kathmandu"
                loading="lazy"
                className="w-full max-w-xs rounded-2xl shadow-soft md:w-64"
              />
            </Reveal>
          </div>
          <BatchSteps />
        </div>
      </section>

      {/* 4 — Request Corporate Training Proposal */}
      <section id="proposal-form" className="bg-white py-16 md:py-24" aria-label="Request proposal form">
        <div className="mx-auto max-w-3xl px-5 md:px-8">
          <Reveal y={40}>
            <div className="rounded-2xl border border-border-soft bg-white p-8 shadow-lift">
              <SectionEyebrow>— GET A PROPOSAL</SectionEyebrow>
              <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
                Request Corporate Training Proposal
              </h2>
              <p className="mt-4 text-[17px] leading-[1.65] text-muted">
                Tell us about your team — our manager will reply within 1 business day.
              </p>
              <AnimatePresence mode="wait">
                <ProposalForm key="proposal" />
              </AnimatePresence>
            </div>
          </Reveal>
        </div>
      </section>

      {/* 5 — Pre-footer CTA banner rendered by Layout */}
    </>
  );
}
