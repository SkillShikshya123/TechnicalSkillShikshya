import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import { motion } from "framer-motion";
import {
  ArrowRight,
  ArrowUpRight,
  Banknote,
  CalendarDays,
  CheckCircle2,
  Clock,
  FileCheck,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
} from "lucide-react";
import SEO, { breadcrumbJsonLd, contactPageJsonLd, localBusinessJsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import SectionEyebrow from "@/components/SectionEyebrow";
import FormField from "@/components/FormField";
import Reveal from "@/components/Reveal";
import { courses } from "@/data/courses";
import { site } from "@/data/site";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";
import { cn } from "@/lib/utils";

const H1_WORDS = ["Free", "Career", "Counseling", "in", "Kathmandu"];

const TIME_OPTIONS = [
  { value: "morning", label: "Morning (9am – 12pm)" },
  { value: "afternoon", label: "Afternoon (12pm – 3pm)" },
  { value: "evening", label: "Evening (3pm – 5pm)" },
];

const DIRECTIONS_URL =
  "https://www.google.com/maps/search/?api=1&query=Civil+Hospital+New+Baneshwar+Kathmandu";

interface FormErrors {
  name?: string;
  phone?: string;
  course?: string;
  time?: string;
}

function CallbackForm() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [course, setCourse] = useState("");
  const [time, setTime] = useState("");
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs: FormErrors = {};
    if (!name.trim()) errs.name = "Please enter your full name";
    if (!/^(9\d{9}|0\d{8,9}|\d{7,10})$/.test(phone.replace(/[\s-]/g, "")))
      errs.phone = "Enter a valid Nepali phone number (e.g. 98XXXXXXXX)";
    if (!course) errs.course = "Please choose a course of interest";
    if (!time) errs.time = "Please pick a preferred contact time";
    setErrors(errs);
    if (Object.keys(errs).length === 0) setSubmitted(true);
  };

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="flex flex-col items-center py-10 text-center"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", bounce: 0.5 }}
        >
          <CheckCircle2 className="h-14 w-14 text-brand" />
        </motion.div>
        <h3 className="mt-4 font-heading text-xl font-semibold text-ink">Callback requested!</h3>
        <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted">
          Expect our call at your preferred time — we'll call you back within one business day.
        </p>
        <a
          href={site.contact.whatsapp}
          target="_blank"
          rel="noreferrer"
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-whatsapp px-5 py-2.5 text-sm font-semibold text-white transition-transform duration-150 hover:scale-[1.02]"
        >
          <MessageCircle className="h-4 w-4" />
          Chat instantly on WhatsApp
        </a>
      </motion.div>
    );
  }

  return (
    <motion.form
      key="form"
      onSubmit={submit}
      noValidate
      initial={{ opacity: 1 }}
      className="mt-5 space-y-4"
    >
      <FormField
        label="Full name"
        value={name}
        onChange={setName}
        placeholder="Your full name"
        error={errors.name}
        required
        name="name"
      />
      <FormField
        label="Phone number"
        type="tel"
        value={phone}
        onChange={setPhone}
        placeholder="98XXXXXXXX"
        error={errors.phone}
        required
        name="phone"
      />
      <FormField
        label="Course of interest"
        type="select"
        value={course}
        onChange={setCourse}
        placeholder="Select a course"
        options={[
          ...courses.map((c) => ({ value: c.slug, label: c.name })),
          { value: "not-sure", label: "Not sure yet — help me decide" },
        ]}
        error={errors.course}
        required
        name="course"
      />
      {/* Preferred contact time — select with tiny Clock icon (contact.md §Interactions) */}
      <div>
        <label
          htmlFor="preferred-time"
          className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-ink"
        >
          <Clock className="h-3.5 w-3.5 text-brand" />
          Preferred contact time
          <span className="ml-0.5 text-amber">*</span>
        </label>
        <select
          id="preferred-time"
          name="preferred-time"
          value={time}
          onChange={(e) => setTime(e.target.value)}
          className={cn(
            "w-full rounded-xl border bg-white px-4 py-3 text-[15px] text-ink outline-none transition-all",
            errors.time
              ? "border-red-400 focus:border-red-500 focus:ring-2 focus:ring-red-200"
              : "border-border-soft focus:border-brand focus:ring-2 focus:ring-brand/25",
          )}
        >
          <option value="" disabled>
            Select a time window
          </option>
          {TIME_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
        {errors.time && <p className="mt-1.5 text-xs font-medium text-red-500">{errors.time}</p>}
      </div>
      <button
        type="submit"
        className="w-full rounded-xl bg-amber px-6 py-3.5 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
      >
        Request Free Callback
      </button>
      <p className="text-center text-xs text-muted">
        Free, zero-obligation. We respond within 1 hour on working days.
      </p>
    </motion.form>
  );
}

const QUICK_ANSWERS = [
  {
    icon: Banknote,
    q: "What are the fees?",
    a: "From Rs 8,000 with 50/50 installments and scholarships.",
    href: "/courses/",
    cta: "Browse courses & fees",
  },
  {
    icon: CalendarDays,
    q: "When do batches start?",
    a: "Next batches: Aug 1 / 5 / 10, 2026 — limited seats.",
    href: "/?scroll=batches",
    cta: "See upcoming batches",
  },
  {
    icon: FileCheck,
    q: "Which certificate do I need for abroad?",
    a: "Usually NSTB Level 1/2 — depends on country.",
    href: "/skill-test-and-certification/",
    cta: "Read the certification guide",
  },
];

export default function Contact() {
  const heroRef = useRef<HTMLElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = heroRef.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo("[data-fade]", { opacity: 0 }, { opacity: 1, duration: 0.4, stagger: 0.08 });
        return;
      }
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
      tl.fromTo(
        "[data-word] > span",
        { yPercent: 110 },
        { yPercent: 0, duration: 0.7, stagger: 0.06 },
        0.15,
      )
        .fromTo(
          "[data-lead]",
          { opacity: 0, y: 16 },
          { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" },
          0.5,
        )
        .fromTo(
          "[data-form-card]",
          { opacity: 0, y: 40 },
          { opacity: 1, y: 0, duration: 0.6, ease: "power3.out" },
          0.65,
        )
        .fromTo(
          "[data-right-card]",
          { opacity: 0, x: 40 },
          { opacity: 1, x: 0, duration: 0.6, ease: "power3.out", stagger: 0.12 },
          0.8,
        )
        .fromTo(
          "[data-map-pin]",
          { y: -14 },
          { y: 0, duration: 0.5, ease: "bounce.out" },
          1.2,
        );
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <>
      <SEO
        title="Free Career Counseling in Kathmandu — Contact SkillShikshya Technical, New Baneshwar"
        description="Free career counseling in Kathmandu: vocational training counseling on fees, batch dates and NSTB certification. Call 01-4000000 or visit us opposite Civil Hospital, New Baneshwar."
        path="/contact-and-counseling/"
        jsonLd={[
          contactPageJsonLd(),
          localBusinessJsonLd(),
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Contact & Counseling", path: "/contact-and-counseling/" },
          ]),
        ]}
      />

      {/* Section 1 — Hero + callback form + location */}
      <section ref={heroRef} className="bg-forest bg-stripes">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-10 px-5 py-20 md:px-8 lg:grid-cols-[55fr_45fr] lg:gap-12">
          {/* Left — intro + form card */}
          <div>
            <div data-fade>
              <Breadcrumbs dark items={[{ label: "Home", to: "/" }, { label: "Contact & Counseling" }]} />
            </div>
            <SectionEyebrow dark className="mt-6">
              — CONTACT &amp; COUNSELING
            </SectionEyebrow>
            <h1 className="mt-4 font-heading text-[34px] font-extrabold leading-[1.1] text-white md:text-[48px] md:leading-[1.05]">
              {H1_WORDS.map((w, i) => (
                <span key={i} data-word className="inline-block overflow-hidden pb-1 align-bottom">
                  <span className="inline-block will-change-transform">{w}&nbsp;</span>
                </span>
              ))}
            </h1>
            <p data-lead data-fade className="mt-5 max-w-xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
              Questions about course fees, upcoming batch dates, or vocational training counseling
              for work in Nepal or abroad? Reach out for a free, zero-obligation callback from our
              New Baneshwar counseling desk.
            </p>

            <div data-form-card data-fade className="mt-8 rounded-2xl bg-white p-7 shadow-lift">
              <h2 className="font-heading text-xl font-semibold text-ink">Request Callback</h2>
              <CallbackForm />
            </div>
          </div>

          {/* Right — Training Location & Details stack */}
          <div className="space-y-6 lg:pt-24">
            <div data-right-card data-fade className="rounded-2xl border border-white/15 bg-white/5 p-6 backdrop-blur-sm">
              <h2 className="font-heading text-lg font-semibold text-white">
                Training Location &amp; Details
              </h2>
              <ul className="mt-4 space-y-4">
                <li>
                  <a
                    href={`tel:${site.contact.phoneLandline}`}
                    className="flex items-center gap-3 text-forest-body transition-colors hover:text-white"
                  >
                    <Phone className="h-5 w-5 shrink-0 text-amber" />
                    <span className="font-mono text-sm">
                      {site.contact.phoneLandline} / {site.contact.phoneMobile}
                    </span>
                  </a>
                </li>
                <li>
                  <a
                    href={`mailto:${site.contact.email}`}
                    className="flex items-center gap-3 text-forest-body transition-colors hover:text-white"
                  >
                    <Mail className="h-5 w-5 shrink-0 text-amber" />
                    <span className="text-sm">{site.contact.email}</span>
                  </a>
                </li>
                <li className="flex items-center gap-3 text-forest-body">
                  <MapPin className="h-5 w-5 shrink-0 text-amber" />
                  <span className="text-sm">{site.contact.address}</span>
                </li>
                <li className="flex items-center gap-3 text-forest-body">
                  <Clock className="h-5 w-5 shrink-0 text-amber" />
                  <span className="font-mono text-sm">{site.contact.hours}</span>
                </li>
              </ul>
            </div>

            <motion.a
              data-right-card
              data-fade
              href={site.contact.whatsapp}
              target="_blank"
              rel="noreferrer"
              className="flex w-full items-center justify-center gap-2.5 rounded-xl bg-whatsapp px-6 py-4 font-semibold text-white transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
              initial={{ boxShadow: "0 0 0 0 rgba(37,211,102,0)" }}
              animate={
                reduced
                  ? undefined
                  : {
                      boxShadow: [
                        "0 0 0 0 rgba(37,211,102,0.45)",
                        "0 0 0 18px rgba(37,211,102,0)",
                      ],
                    }
              }
              transition={{ duration: 1.6, delay: 1.2, ease: "easeOut" }}
            >
              <MessageCircle className="h-5 w-5" />
              Chat instantly on WhatsApp
            </motion.a>

            <div data-right-card data-fade className="overflow-hidden rounded-2xl bg-mint">
              <div className="aspect-[16/10]">
                <iframe
                  title="SkillShikshya Technical Center location map"
                  src="https://www.google.com/maps?q=New+Baneshwar,+Kathmandu,+Nepal&output=embed"
                  loading="lazy"
                  allowFullScreen
                  referrerPolicy="no-referrer-when-downgrade"
                  className="h-full w-full border-0"
                />
              </div>
              <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5">
                <span className="flex items-center gap-2 text-sm font-medium text-ink">
                  <span data-map-pin className="inline-flex">
                    <MapPin className="h-4 w-4 text-brand" />
                  </span>
                  SkillShikshya Technical Center — New Baneshwar, Kathmandu
                </span>
                <a
                  href={DIRECTIONS_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-brand transition-colors hover:text-brand-dark"
                >
                  Get Directions
                  <ArrowUpRight className="h-4 w-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2 — Quick answers band */}
      <section className="bg-white">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
          <SectionEyebrow>— BEFORE YOU CALL</SectionEyebrow>
          <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
            Quick answers
          </h2>
          <Reveal className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-3 md:gap-8" stagger={0.1}>
            {QUICK_ANSWERS.map((item) => (
              <Link
                key={item.q}
                to={item.href}
                className="group rounded-2xl border border-border-soft bg-white p-6 shadow-soft transition-all duration-300 hover:-translate-y-1 hover:shadow-lift"
              >
                <item.icon className="h-6 w-6 text-brand" />
                <h3 className="mt-3 font-heading text-lg font-semibold text-ink">{item.q}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{item.a}</p>
                <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-brand">
                  {item.cta}
                  <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                </span>
              </Link>
            ))}
          </Reveal>
        </div>
      </section>
      {/* Section 3 — Footer rendered directly by Layout (no pre-footer CTA on this page) */}
    </>
  );
}
