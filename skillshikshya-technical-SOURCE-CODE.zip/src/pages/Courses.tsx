import { useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router";
import { AnimatePresence, motion } from "framer-motion";
import { ShieldCheck, Award, Briefcase, LayoutGrid, ArrowRight } from "lucide-react";
import SEO, { breadcrumbJsonLd, itemListJsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import SectionEyebrow from "@/components/SectionEyebrow";
import TrustBadgePill from "@/components/TrustBadgePill";
import FilterPills from "@/components/FilterPills";
import CourseCard from "@/components/CourseCard";
import Reveal from "@/components/Reveal";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";
import { scrollToTarget } from "@/lib/scroll";
import { coursePath, courses } from "@/data/courses";
import { categories } from "@/data/categories";
import { cn } from "@/lib/utils";

const ALL_LABEL = "Show All Courses";
const H1_WORDS = ["Vocational", "Courses", "in", "Nepal"];

const pillLabel = (name: string, count: number) => `${name} · ${count}`;

export default function Courses() {
  const reduced = usePrefersReducedMotion();
  const pageRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState<string>("all");

  // URL param support: /courses/?cat=construction-electrical activates that filter
  const [searchParams, setSearchParams] = useSearchParams();
  useEffect(() => {
    const h = searchParams.get("cat") ?? "";
    if (h && categories.some((c) => c.anchorId === h)) setActive(h);
  }, [searchParams]);

  // Hero entrance: H1 word-split rise → lead fade-up → pills pop
  useEffect(() => {
    const el = pageRef.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo(
          "[data-fade]",
          { opacity: 0 },
          { opacity: 1, duration: 0.5, stagger: 0.08 },
        );
        return;
      }
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
      tl.fromTo("[data-crumb]", { opacity: 0 }, { opacity: 1, duration: 0.3 }, 0.1)
        .fromTo(
          "[data-word] > span",
          { yPercent: 110 },
          { yPercent: 0, duration: 0.7, stagger: 0.06 },
          0.2,
        )
        .fromTo("[data-lead]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 0.85)
        .fromTo(
          "[data-pill]",
          { opacity: 0, scale: 0.8 },
          { opacity: 1, scale: 1, duration: 0.4, stagger: 0.07, ease: "back.out(2)" },
          1.0,
        )
        .fromTo(
          "[data-filter-bar]",
          { opacity: 0, y: 14 },
          { opacity: 1, y: 0, duration: 0.45, ease: "power3.out" },
          1.15,
        );
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  const options = [ALL_LABEL, ...categories.map((c) => pillLabel(c.name, c.courseCount))];
  const activeLabel =
    active === "all"
      ? ALL_LABEL
      : pillLabel(categories.find((c) => c.anchorId === active)?.name ?? "", categories.find((c) => c.anchorId === active)?.courseCount ?? 0);

  const onFilter = (label: string) => {
    if (label === ALL_LABEL) {
      setActive("all");
      setSearchParams({});
    } else {
      const cat = categories.find((c) => pillLabel(c.name, c.courseCount) === label);
      if (!cat) return;
      setActive(cat.anchorId);
      setSearchParams({ cat: cat.anchorId });
    }
    scrollToTarget("#courses-grid");
  };

  const visible = active === "all" ? categories : categories.filter((c) => c.anchorId === active);

  return (
    <div ref={pageRef}>
      <SEO
        title="Vocational Courses in Nepal — 10 CTEVT-Certified Trade Courses | SkillShikshya Technical"
        description="Skill training courses in Kathmandu: the full CTEVT course list — electrician, barista, beautician, caregiver & more. NSTB-mapped, placement support, fees from Rs 8,000."
        path="/courses/"
        jsonLd={[
          itemListJsonLd(courses.map((c) => ({ name: c.name, path: coursePath(c) }))),
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Courses", path: "/courses/" },
          ]),
        ]}
      />

      {/* 1 — Hero */}
      <section className="bg-forest bg-stripes" aria-label="All courses">
        <div className="mx-auto max-w-6xl px-5 py-16 text-center md:px-8 md:py-20">
          <div data-crumb data-fade={reduced ? true : undefined} className="flex justify-center">
            <Breadcrumbs dark items={[{ label: "Home", to: "/" }, { label: "Courses" }]} />
          </div>
          <p className="mt-6 font-mono text-[12.5px] font-medium uppercase tracking-[0.12em] text-amber">
            — ALL COURSES
          </p>
          <h1 className="mt-4 font-heading text-[34px] font-extrabold leading-[1.1] text-white md:text-[56px] md:leading-[1.05]">
            {H1_WORDS.map((w, i) => (
              <span
                key={i}
                data-word
                className="mr-[0.28em] inline-block overflow-hidden align-bottom last:mr-0"
              >
                <span className="inline-block will-change-transform">{w}</span>
              </span>
            ))}
          </h1>
          <p
            data-lead
            data-fade={reduced ? true : undefined}
            className="mx-auto mt-5 max-w-2xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]"
          >
            Skill training courses in Kathmandu built for real careers: every vocational training
            program on this CTEVT course list is heavily hands-on and maps directly to National
            Skill Testing Board (NSTB) certification. Ten trade courses Nepal employers hire for —
            choose your career path below.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-2.5">
            {[
              { icon: ShieldCheck, label: "CTEVT Affiliated" },
              { icon: Award, label: "NSTB Level 1 & 2" },
              { icon: Briefcase, label: "Placement Support" },
              { icon: LayoutGrid, label: "10 Courses" },
            ].map((p) => (
              <span
                key={p.label}
                data-pill
                data-fade={reduced ? true : undefined}
                className={reduced ? undefined : "opacity-0"}
              >
                <TrustBadgePill icon={p.icon} label={p.label} dark />
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* 2 — Filter pills (sticky-ish) */}
      <div
        id="courses-grid"
        className="sticky top-16 z-30 border-b border-border-soft bg-white/95 backdrop-blur"
      >
        <div className="mx-auto max-w-6xl px-5 py-4 md:px-8">
          <div data-filter-bar data-fade={reduced ? true : undefined} className="overflow-x-auto pb-1">
            <FilterPills
              options={options}
              active={activeLabel}
              onChange={onFilter}
              className="flex-nowrap whitespace-nowrap md:flex-wrap md:whitespace-normal"
            />
          </div>
        </div>
      </div>

      {/* 3 — Category sections ×4 */}
      <AnimatePresence initial={false} mode="popLayout">
        {visible.map((cat) => {
          const catCourses = courses.filter((c) => c.categorySlug === cat.slug);
          const origIdx = categories.findIndex((c) => c.slug === cat.slug);
          const mintBg = origIdx % 2 === 1;
          return (
            <motion.div
              key={cat.slug}
              layout="position"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.35, ease: "easeInOut" }}
              style={{ overflow: "hidden" }}
            >
              <section
                id={cat.anchorId}
                aria-label={cat.name}
                className={cn(mintBg ? "bg-mint" : "bg-white")}
              >
                <div className="mx-auto max-w-6xl px-5 py-14 md:px-8">
                  <Reveal stagger={0.1} y={24}>
                    <div>
                      <SectionEyebrow>— CATEGORY</SectionEyebrow>
                      <h2 className="mt-3 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
                        {cat.name}
                      </h2>
                      <p className="mt-3 max-w-2xl text-[16px] leading-[1.6] text-muted">
                        {cat.intro}
                      </p>
                      <p className="mt-3 font-mono text-xs uppercase tracking-[0.1em] text-muted">
                        {cat.courseCount} courses · {cat.fromPrice}
                      </p>
                      <Link
                        to={`/courses/${cat.slug}/`}
                        className="group mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-brand"
                      >
                        View {cat.name} category page
                        <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                      </Link>
                    </div>
                  </Reveal>
                  <Reveal key={`${cat.slug}-${active}`} className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 md:gap-8" stagger={0.1}>
                    {catCourses.map((course) => (
                      <CourseCard key={course.slug} course={course} />
                    ))}
                  </Reveal>
                </div>
              </section>
            </motion.div>
          );
        })}
      </AnimatePresence>
      {/* Pre-footer CTA + Footer rendered by Layout */}
    </div>
  );
}
