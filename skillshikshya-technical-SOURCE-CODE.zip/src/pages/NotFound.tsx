import { Placeholder } from "./Placeholder";

export default function NotFound() {
  return <Placeholder name="Page Not Found" />;
}
