import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import { AnimatePresence, motion, useAnimationControls } from "framer-motion";
import { AlertCircle, ArrowRight, CheckCircle2, Loader2 } from "lucide-react";
import SEO, { breadcrumbJsonLd } from "@/components/SEO";
import type { JsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import SectionEyebrow from "@/components/SectionEyebrow";
import Reveal from "@/components/Reveal";
import StepCard from "@/components/StepCard";
import { graduates, lookupGraduate, type GraduateRecord } from "@/data/registry";
import { site } from "@/data/site";
import { usePrefersReducedMotion } from "@/lib/motion";

const ID_PATTERN = /^SS-\d{4}-\d{3}$/;

const HERO_BULLETS = [
  "Government-aligned certification records",
  "NSTB skill level confirmation",
  "Placement status where reported",
];

const STEPS = [
  {
    number: "01",
    title: "Certificate Issued",
    description: "Every graduate receives a unique Certificate ID with their CTEVT-affiliated completion certificate.",
  },
  {
    number: "02",
    title: "Record Stored",
    description: "Trade, skill level, and NSTB results are recorded in our graduate registry at graduation.",
  },
  {
    number: "03",
    title: "Instant Verification",
    description: "Enter the ID above to verify a skill certificate instantly, or call our office to confirm a candidate's credentials before hiring.",
  },
];

const webPageJsonLd = (): JsonLd => ({
  "@context": "https://schema.org",
  "@type": "WebPage",
  name: "Certificate Verification Nepal — Verify a Skill Certificate by ID",
  url: `${site.url}/graduate-registry/`,
  description:
    "Certificate verification in Nepal for employers and manpower agencies: verify a SkillShikshya Technical graduate's skill certificate, trade, NSTB level and placement status by certificate ID.",
});

/** Lookup card — enhanced page-local variant of the shared RegistryLookup
 *  (adds fake checking delay, format validation, not-found shake, autofill+submit chips). */
function RegistryLookupCard() {
  const reduced = usePrefersReducedMotion();
  const [query, setQuery] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [result, setResult] = useState<GraduateRecord | "not-found" | null>(null);
  const shakeControls = useAnimationControls();
  const timers = useRef<number[]>([]);

  useEffect(() => () => timers.current.forEach((t) => window.clearTimeout(t)), []);

  const later = (fn: () => void, ms: number) => {
    timers.current.push(window.setTimeout(fn, ms));
  };

  const submit = (raw?: string) => {
    const value = (raw ?? query).trim().toUpperCase();
    if (raw !== undefined) setQuery(value);
    if (!value) {
      setError("Please enter a certificate ID.");
      return;
    }
    if (!ID_PATTERN.test(value)) {
      setError("Invalid format — use SS-YYYY-NNN (e.g. SS-2026-001).");
      setResult(null);
      return;
    }
    setError(null);
    setResult(null);
    setChecking(true);
    // Fake "checking…" delay for realism (graduate-registry.md §1)
    later(() => {
      setChecking(false);
      const rec = lookupGraduate(value);
      if (rec) {
        setResult(rec);
      } else {
        if (!reduced) {
          shakeControls.start({ x: [0, -6, 6, -4, 4, 0], transition: { duration: 0.3 } });
        }
        later(() => setResult("not-found"), reduced ? 0 : 300);
      }
    }, 600);
  };

  return (
    <div className="rounded-2xl bg-white p-7 shadow-lift">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
        noValidate
      >
        <label htmlFor="registry-cert-id" className="mb-1.5 block text-sm font-medium text-ink">
          Certificate ID
        </label>
        <motion.div animate={shakeControls}>
          <input
            id="registry-cert-id"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value.toUpperCase());
              if (error) setError(null);
            }}
            placeholder="e.g. SS-2026-001"
            autoComplete="off"
            spellCheck={false}
            aria-invalid={!!error}
            aria-describedby={error ? "registry-cert-id-error" : undefined}
            className={
              error
                ? "w-full rounded-xl border border-red-500 bg-white px-4 py-3 font-mono text-[15px] uppercase text-ink outline-none transition-all placeholder:text-muted/60 focus:border-red-500 focus:ring-2 focus:ring-red-200"
                : "w-full rounded-xl border border-border-soft bg-white px-4 py-3 font-mono text-[15px] uppercase text-ink outline-none transition-all placeholder:text-muted/60 focus:border-brand focus:ring-2 focus:ring-brand/25"
            }
          />
        </motion.div>
        {error && (
          <p id="registry-cert-id-error" className="mt-1.5 text-sm text-red-600">
            {error}
          </p>
        )}
        <button
          type="submit"
          disabled={checking}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-brand px-6 py-3.5 font-semibold text-white transition-colors hover:bg-brand-dark disabled:opacity-70"
        >
          {checking ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Checking…
            </>
          ) : (
            "Verify Certificate"
          )}
        </button>
      </form>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-muted">Try:</span>
        {graduates.map((g, i) => (
          <motion.button
            key={g.certificateId}
            type="button"
            initial={reduced ? { opacity: 0 } : { opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6 + i * 0.06, duration: 0.3, ease: "easeOut" }}
            onClick={() => submit(g.certificateId)}
            className="rounded-full border border-border-soft bg-mint px-3 py-1 font-mono text-xs text-ink transition-colors hover:border-brand/50"
          >
            {g.certificateId}
          </motion.button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {result && (
          <motion.div
            key={result === "not-found" ? "not-found" : result.certificateId}
            initial={reduced ? { opacity: 0 } : { opacity: 0, scale: 0.94, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, transition: { duration: 0.25 } }}
            transition={reduced ? { duration: 0.25 } : { type: "spring", bounce: 0.35, duration: 0.5 }}
            className="mt-5"
            aria-live="polite"
          >
            {result === "not-found" ? (
              <div className="flex items-start gap-3 rounded-xl bg-amber-soft p-4">
                <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-[#9A6714]" />
                <p className="text-sm leading-relaxed text-ink">
                  Certificate not found. Double-check the ID format (SS-YYYY-NNN) or contact our
                  office at {site.contact.phoneLandline} for manual verification.
                </p>
              </div>
            ) : (
              <div className="rounded-xl border border-brand/25 bg-mint p-5">
                <p className="flex items-center gap-2 font-heading text-base font-semibold text-brand">
                  <CheckCircle2 className="h-5 w-5" />
                  Verified Graduate
                </p>
                <dl className="mt-4 space-y-2.5 text-sm">
                  {[
                    ["Name", result.name],
                    ["Trade", result.trade],
                    ["Graduation Status", result.status],
                    ["NSTB Level", result.nstbLevel],
                    ["Current Placement", result.placement],
                  ].map(([k, v]) => (
                    <div key={k} className="flex items-start justify-between gap-4">
                      <dt className="shrink-0 text-muted">{k}</dt>
                      <dd className="text-right font-semibold text-ink">{v}</dd>
                    </div>
                  ))}
                </dl>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/** Section 1 — hero + lookup tool (combined, above the fold). */
function Hero() {
  const reduced = usePrefersReducedMotion();
  const container = {
    hidden: {},
    show: { transition: { staggerChildren: 0.1 } },
  };
  const item = {
    hidden: reduced ? { opacity: 0 } : { opacity: 0, y: 16 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" as const } },
  };

  return (
    <section className="bg-forest bg-stripes" aria-label="Graduate registry lookup">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-20 md:px-8 lg:grid-cols-2">
        <div>
          <Breadcrumbs dark items={[{ label: "Home", to: "/" }, { label: "Graduate Registry" }]} />
          <motion.div variants={container} initial="hidden" animate="show">
            <motion.div variants={item}>
              <SectionEyebrow dark className="mt-6">
                — VERIFIED GRADUATE REGISTRY
              </SectionEyebrow>
            </motion.div>
            <motion.h1
              variants={item}
              className="mt-4 font-heading text-[34px] font-extrabold leading-[1.1] text-white md:text-[48px] md:leading-[1.05]"
            >
              Certificate Verification in Nepal, in Seconds
            </motion.h1>
            <motion.p variants={item} className="mt-5 max-w-xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
              Employers and manpower agencies: verify a skill certificate issued to any SkillShikshya
              graduate. Enter the unique Certificate ID below to confirm their trade, graduation
              status, NSTB level, and placement.
            </motion.p>
            <motion.ul variants={item} className="mt-7 space-y-3">
              {HERO_BULLETS.map((b) => (
                <li key={b} className="flex items-center gap-3 text-[15px] text-forest-body">
                  <CheckCircle2 className="h-5 w-5 shrink-0 text-amber" />
                  {b}
                </li>
              ))}
            </motion.ul>
          </motion.div>
        </div>
        <motion.div
          initial={reduced ? { opacity: 0 } : { opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
        >
          <RegistryLookupCard />
        </motion.div>
      </div>
    </section>
  );
}

export default function GraduateRegistry() {
  return (
    <>
      <SEO
        title="Certificate Verification Nepal — Verify a Skill Certificate by ID | SkillShikshya Technical"
        description="Certificate verification in Nepal for employers & manpower agencies: verify a SkillShikshya graduate's skill certificate, trade, NSTB level and placement by certificate ID."
        path="/graduate-registry/"
        jsonLd={[
          webPageJsonLd(),
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Graduate Registry", path: "/graduate-registry/" },
          ]),
        ]}
      />

      {/* 1 — Hero + lookup tool */}
      <Hero />

      {/* 2 — How verification works */}
      <section className="bg-white" aria-label="How verification works">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
          <SectionEyebrow>— HOW IT WORKS</SectionEyebrow>
          <h2 className="mt-3 font-heading text-3xl font-bold text-ink md:text-[40px]">
            How skill certificate verification works
          </h2>
          <Reveal className="mt-10 grid gap-6 md:grid-cols-3 md:gap-8" stagger={0.12}>
            {STEPS.map((s) => (
              <StepCard key={s.number} number={s.number} title={s.title} description={s.description} />
            ))}
          </Reveal>
        </div>
      </section>

      {/* 3 — For graduates */}
      <section className="bg-mint" aria-label="For graduates">
        <Reveal y={24} stagger={0.1}>
          <div className="mx-auto flex max-w-6xl flex-col items-start gap-6 px-5 py-12 md:flex-row md:items-center md:justify-between md:px-8 md:py-16">
            <div>
              <h3 className="font-heading text-2xl font-semibold text-ink md:text-[28px]">
                Are you a graduate?
              </h3>
              <p className="mt-2 max-w-xl text-[15px] leading-relaxed text-muted">
                Lost your certificate ID or need a reprint? Our office can reissue verified documents.
              </p>
            </div>
            <Link
              to="/contact-and-counseling/"
              className="group inline-flex shrink-0 items-center gap-1.5 rounded-xl border border-brand/40 bg-white px-6 py-3 font-semibold text-brand transition-colors hover:border-brand hover:bg-mint-deep"
            >
              Contact the office
              <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
            </Link>
          </div>
        </Reveal>
      </section>

      {/* 4 — CTA variant (graduate-registry.md §4) */}
      <section className="bg-forest bg-stripes" aria-label="Graduate referrals">
        <motion.div
          className="mx-auto max-w-4xl px-5 py-16 text-center md:px-8 md:py-24"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        >
          <SectionEyebrow dark>— FOR EMPLOYERS</SectionEyebrow>
          <h2 className="mt-4 font-heading text-3xl font-bold text-white md:text-[40px] md:leading-[1.1]">
            Hiring? Ask us for graduate referrals.
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
            Our placement desk connects verified graduates with employers and manpower agencies in
            Nepal and abroad.
          </p>
          <div className="mt-8">
            <Link
              to="/contact-and-counseling/"
              className="inline-block rounded-xl bg-amber px-7 py-3.5 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
            >
              Talk to Our Placement Desk
            </Link>
          </div>
        </motion.div>
      </section>
    </>
  );
}
