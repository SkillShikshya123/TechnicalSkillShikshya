import { useEffect, useRef } from "react";
import { Link } from "react-router";
import {
  ShieldCheck,
  Award,
  Briefcase,
  LayoutGrid,
  ArrowRight,
  Sparkles,
  Wrench,
  Coffee,
  HeartHandshake,
  Store,
  Plane,
  HeartPulse,
  TrendingUp,
} from "lucide-react";
import SEO, { breadcrumbJsonLd, itemListJsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import SectionEyebrow from "@/components/SectionEyebrow";
import TrustBadgePill from "@/components/TrustBadgePill";
import CourseCard from "@/components/CourseCard";
import Reveal from "@/components/Reveal";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";
import { coursePath, coursesByCategory } from "@/data/courses";
import type { Category, CategoryIcon } from "@/data/categories";

const highlightIcons = {
  Sparkles,
  Wrench,
  Coffee,
  HeartHandshake,
  Store,
  Award,
  Plane,
  Briefcase,
  HeartPulse,
  TrendingUp,
} satisfies Record<CategoryIcon, typeof Sparkles>;

/**
 * Static category page — /courses/<categorySlug>/
 * One data-driven template for all four trade categories (design: courses.md language).
 * Pre-footer CTA banner + Footer are rendered by Layout.
 */
export default function CategoryPage({ category }: { category: Category }) {
  const reduced = usePrefersReducedMotion();
  const pageRef = useRef<HTMLDivElement>(null);
  const catCourses = coursesByCategory(category.slug);
  const h1Words = category.h1.split(" ");

  // Hero entrance: H1 word-split rise → lead fade-up → pills pop (courses.md §1)
  useEffect(() => {
    const el = pageRef.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo(
          "[data-fade]",
          { opacity: 0 },
          { opacity: 1, duration: 0.5, stagger: 0.08 },
        );
        return;
      }
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
      tl.fromTo("[data-crumb]", { opacity: 0 }, { opacity: 1, duration: 0.3 }, 0.1)
        .fromTo(
          "[data-word] > span",
          { yPercent: 110 },
          { yPercent: 0, duration: 0.7, stagger: 0.06 },
          0.2,
        )
        .fromTo(
          "[data-lead]",
          { opacity: 0, y: 16 },
          { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" },
          0.85,
        )
        .fromTo(
          "[data-pill]",
          { opacity: 0, scale: 0.8 },
          { opacity: 1, scale: 1, duration: 0.4, stagger: 0.07, ease: "back.out(2)" },
          1.0,
        );
    }, el);
    return () => ctx.revert();
  }, [reduced, category.slug]);

  return (
    <div ref={pageRef}>
      <SEO
        title={category.pageTitle}
        description={category.metaDescription}
        path={`/courses/${category.slug}/`}
        jsonLd={[
          itemListJsonLd(catCourses.map((c) => ({ name: c.name, path: coursePath(c) }))),
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Courses", path: "/courses/" },
            { name: category.name, path: `/courses/${category.slug}/` },
          ]),
        ]}
      />

      {/* 1 — Hero */}
      <section className="bg-forest bg-stripes" aria-label={category.name}>
        <div className="mx-auto max-w-6xl px-5 py-16 text-center md:px-8 md:py-20">
          <div data-crumb data-fade={reduced ? true : undefined} className="flex justify-center">
            <Breadcrumbs
              dark
              items={[
                { label: "Home", to: "/" },
                { label: "Courses", to: "/courses/" },
                { label: category.name },
              ]}
            />
          </div>
          <p className="mt-6 font-mono text-[12.5px] font-medium uppercase tracking-[0.12em] text-amber">
            — COURSE CATEGORY
          </p>
          <h1 className="mt-4 font-heading text-[34px] font-extrabold leading-[1.1] text-white md:text-[52px] md:leading-[1.05]">
            {h1Words.map((w, i) => (
              <span
                key={i}
                data-word
                className="mr-[0.28em] inline-block overflow-hidden align-bottom last:mr-0"
              >
                <span className="inline-block will-change-transform">{w}</span>
              </span>
            ))}
          </h1>
          <p
            data-lead
            data-fade={reduced ? true : undefined}
            className="mx-auto mt-5 max-w-2xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]"
          >
            {category.heroLead}
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-2.5">
            {[
              { icon: ShieldCheck, label: "CTEVT Affiliated" },
              { icon: Award, label: "NSTB Skill-Test Mapped" },
              { icon: Briefcase, label: "Placement Support" },
              {
                icon: LayoutGrid,
                label: `${category.courseCount} Course${category.courseCount > 1 ? "s" : ""}`,
              },
            ].map((p) => (
              <span
                key={p.label}
                data-pill
                data-fade={reduced ? true : undefined}
                className={reduced ? undefined : "opacity-0"}
              >
                <TrustBadgePill icon={p.icon} label={p.label} dark />
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* 2 — Keyword-rich intro copy */}
      <section className="bg-white" aria-label={`About ${category.name} training`}>
        <div className="mx-auto max-w-3xl px-5 py-14 md:px-8 md:py-16">
          <Reveal stagger={0.1} y={20}>
            <div>
              <SectionEyebrow>— WHY THIS TRADE</SectionEyebrow>
              <h2 className="mt-3 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[36px]">
                {category.name} training in Nepal at SkillShikshya
              </h2>
              <p className="mt-4 text-[16px] leading-[1.7] text-muted">{category.pageIntro}</p>
              <p className="mt-4 font-mono text-xs uppercase tracking-[0.1em] text-muted">
                {category.courseCount} course{category.courseCount > 1 ? "s" : ""} · {category.fromPrice} · CTEVT affiliated
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* 3 — Course grid */}
      <section className="bg-mint" aria-label={`${category.name} courses`}>
        <div className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-20">
          <Reveal stagger={0.1} y={24}>
            <div>
              <SectionEyebrow>— COURSES IN THIS CATEGORY</SectionEyebrow>
              <h2 className="mt-3 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[36px]">
                Choose your course
              </h2>
            </div>
          </Reveal>
          <Reveal className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 md:gap-8" stagger={0.1}>
            {catCourses.map((course) => (
              <CourseCard key={course.slug} course={course} />
            ))}
          </Reveal>
          <Reveal y={16}>
            <p className="mt-8 text-center text-sm text-muted">
              Looking for a different trade?{" "}
              <Link to="/courses/" className="group inline-flex items-center gap-1 font-semibold text-brand">
                Browse all 10 courses
                <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
              </Link>
            </p>
          </Reveal>
        </div>
      </section>

      {/* 4 — Why these trades: outcomes strip */}
      <section className="bg-white" aria-label="Outcomes">
        <div className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-20">
          <Reveal stagger={0.1} y={24}>
            <div>
              <SectionEyebrow>— WHERE IT LEADS</SectionEyebrow>
              <h2 className="mt-3 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[36px]">
                Why these trades pay off
              </h2>
            </div>
          </Reveal>
          <Reveal className="mt-8 grid gap-6 sm:grid-cols-3 md:gap-8" stagger={0.1}>
            {category.highlights.map((h) => {
              const Icon = highlightIcons[h.icon];
              return (
                <div
                  key={h.title}
                  className="group rounded-2xl border border-border-soft bg-white p-6 shadow-soft transition-all duration-200 hover:-translate-y-1 hover:shadow-lift"
                >
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand/10 transition-transform duration-200 group-hover:rotate-[8deg]">
                    <Icon className="h-5 w-5 text-brand" />
                  </span>
                  <h3 className="mt-4 font-heading text-lg font-semibold text-ink">{h.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{h.text}</p>
                </div>
              );
            })}
          </Reveal>
        </div>
      </section>
      {/* Pre-footer CTA + Footer rendered by Layout */}
    </div>
  );
}
