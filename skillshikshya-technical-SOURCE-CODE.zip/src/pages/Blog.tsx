import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import { motion } from "framer-motion";
import { ArrowRight, CalendarDays, Clock } from "lucide-react";
import SEO, { breadcrumbJsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import SectionEyebrow from "@/components/SectionEyebrow";
import FilterPills from "@/components/FilterPills";
import type { BlogPost } from "@/data/posts";
import { posts } from "@/data/posts";
import { site } from "@/data/site";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";
import { cn } from "@/lib/utils";

const FILTERS = ["All Posts", "Certification", "Foreign Employment", "Careers", "Salaries"];
const H1_WORDS = ["Skills,", "careers,", "and", "working", "abroad", "—", "explained"];

function PostCard({ post, index }: { post: BlogPost; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.35, delay: index * 0.06, ease: "easeOut" }}
    >
      <Link
        to={`/blog/${post.slug}/`}
        className="group flex h-full flex-col overflow-hidden rounded-2xl border border-border-soft bg-white shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift"
      >
        <div className="relative aspect-[16/9] overflow-hidden bg-forest">
          <img
            src={post.cover}
            alt={post.coverAlt}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-forest/50 via-transparent to-transparent" />
        </div>
        <div className="flex flex-1 flex-col p-5 md:p-6">
          <span className="inline-block w-fit rounded-full bg-amber-soft px-3 py-1 font-mono text-[11px] font-medium uppercase tracking-[0.1em] text-[#9A6714]">
            {post.category}
          </span>
          <h2 className="mt-3 font-heading text-xl font-semibold leading-snug text-ink">
            {post.title}
          </h2>
          <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted">{post.excerpt}</p>
          <div className="mt-4 flex items-center gap-4 border-t border-border-soft pt-4 font-mono text-xs font-medium uppercase tracking-wide text-muted">
            <span className="inline-flex items-center gap-1.5">
              <CalendarDays className="h-3.5 w-3.5" />
              {post.date}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" />
              {post.readTime}
            </span>
          </div>
          <span className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-brand">
            Read guide
            <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
          </span>
        </div>
      </Link>
    </motion.div>
  );
}

export default function Blog() {
  const [filter, setFilter] = useState("All Posts");
  const heroRef = useRef<HTMLElement>(null);
  const reduced = usePrefersReducedMotion();

  const visible = filter === "All Posts" ? posts : posts.filter((p) => p.category === filter);

  useEffect(() => {
    const el = heroRef.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo("[data-blog-fade]", { opacity: 0 }, { opacity: 1, duration: 0.4, stagger: 0.08 });
        return;
      }
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
      tl.fromTo(
        "[data-word] > span",
        { yPercent: 110 },
        { yPercent: 0, duration: 0.7, stagger: 0.05 },
        0.1,
      ).fromTo("[data-lead]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 0.75);
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <>
      <SEO
        title="Skill & Career Guides — Vocational Training Blog Nepal | SkillShikshya Technical"
        description="Guides on NSTB skill tests, foreign employment skills, trade salaries, and career options after SEE — from Kathmandu's vocational training experts."
        path="/blog/"
        jsonLd={[
          {
            "@context": "https://schema.org",
            "@type": "Blog",
            name: `${site.name} Blog`,
            description:
              "Practical guides on NSTB skill tests, foreign employment skills, trade salaries, and career options after SEE.",
            url: `${site.url}/blog/`,
            publisher: { "@type": "Organization", name: site.name, url: site.url },
          },
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Blog", path: "/blog/" },
          ]),
        ]}
      />

      {/* Section 1 — Hero */}
      <section ref={heroRef} className="bg-forest bg-stripes">
        <div className="mx-auto max-w-4xl px-5 py-20 text-center md:px-8">
          <div data-blog-fade className="flex justify-center">
            <Breadcrumbs
              dark
              items={[{ label: "Home", to: "/" }, { label: "Blog" }]}
            />
          </div>
          <SectionEyebrow dark center className="mt-6">
            — GUIDES &amp; INSIGHTS
          </SectionEyebrow>
          <h1
            className={cn(
              "mt-4 font-heading text-[34px] font-extrabold leading-[1.1] text-white md:text-[56px] md:leading-[1.05]",
            )}
          >
            {H1_WORDS.map((w, i) => (
              <span key={i} data-word className="inline-block overflow-hidden pb-1 align-bottom">
                <span className="inline-block will-change-transform">{w}&nbsp;</span>
              </span>
            ))}
          </h1>
          <p
            data-lead
            data-blog-fade
            className="mx-auto mt-5 max-w-2xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]"
          >
            Practical guides written by our instructors and counselors. No fluff — just what
            actually helps you get certified and hired.
          </p>
        </div>
      </section>

      {/* Section 2 — Filter pills + post grid */}
      <section className="bg-white">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
          <FilterPills options={FILTERS} active={filter} onChange={setFilter} />
          <div key={filter} className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 md:gap-8">
            {visible.map((post, i) => (
              <PostCard key={post.slug} post={post} index={i} />
            ))}
          </div>
        </div>
      </section>
      {/* Section 3 — Pre-footer CTA + Footer rendered by Layout */}
    </>
  );
}
