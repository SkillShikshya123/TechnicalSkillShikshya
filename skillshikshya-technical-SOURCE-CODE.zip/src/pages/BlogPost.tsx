import { useState } from "react";
import { Link, useParams } from "react-router";
import { motion } from "framer-motion";
import {
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  Clock,
  Link2,
  PenLine,
} from "lucide-react";
import SEO, { blogPostingJsonLd, breadcrumbJsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import FAQAccordion from "@/components/FAQAccordion";
import SectionEyebrow from "@/components/SectionEyebrow";
import CourseCard from "@/components/CourseCard";
import type { BlogPost, PostBlock } from "@/data/posts";
import { postBySlug, posts } from "@/data/posts";
import { courses } from "@/data/courses";
import { site } from "@/data/site";
import { usePrefersReducedMotion } from "@/lib/motion";

const AUTHOR = "SkillShikshya Counseling Team";

/** Most relevant course for each post's related strip. */
const RELATED_COURSE: Record<string, string> = {
  "how-to-get-nstb-skill-test-certificate-nepal": "electrician-training",
  "top-10-skills-in-demand-for-foreign-employment-nepal": "elderly-caregiver-training",
  "electrician-vs-plumber-which-trade-pays-better-nepal": "electrician-training",
  "best-career-options-after-see-without-plus-two": "barista-training",
  "nstb-level-1-vs-2-vs-3-difference": "electrician-training",
  "skill-test-documents-checklist-foreign-employment": "elderly-caregiver-training",
  "beautician-vs-makeup-artist-career-comparison-nepal": "makeup-beautician-course",
  "barista-course-vs-on-the-job-training-nepal": "barista-training",
  "what-is-vocational-training-nepal-guide": "electrician-training",
  "vocational-training-vs-technical-training-difference": "electrician-training",
  "self-employment-ideas-after-beauty-wellness-course": "nail-art-training",
};

const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number];

function CategoryChip({ label }: { label: string }) {
  return (
    <span className="inline-block rounded-full bg-amber-soft px-3 py-1 font-mono text-[11px] font-medium uppercase tracking-[0.1em] text-[#9A6714]">
      {label}
    </span>
  );
}

/** Light scroll fade-up for body blocks (y 16→0, 0.4s, once). */
function FadeBlock({ children }: { children: React.ReactNode }) {
  const reduced = usePrefersReducedMotion();
  return (
    <motion.div
      initial={{ opacity: 0, y: reduced ? 0 : 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
}

function BlockRenderer({ block }: { block: PostBlock }) {
  const reduced = usePrefersReducedMotion();
  switch (block.type) {
    case "h2":
      return (
        <FadeBlock>
          <h2 className="mt-10 flex items-start gap-3 font-heading text-[28px] font-bold leading-[1.15] text-ink">
            <span aria-hidden className="mt-1.5 h-7 w-1 shrink-0 rounded-full bg-amber" />
            {block.text}
          </h2>
        </FadeBlock>
      );
    case "h3":
      return (
        <FadeBlock>
          <h3 className="mt-8 font-heading text-[22px] font-semibold leading-[1.25] text-ink">
            {block.text}
          </h3>
        </FadeBlock>
      );
    case "p":
      return (
        <FadeBlock>
          <p className="mt-4 text-[17px] leading-[1.75] text-ink/90">{block.text}</p>
        </FadeBlock>
      );
    case "list":
      return (
        <FadeBlock>
          <ul className="mt-5 space-y-3">
            {block.items.map((item, i) => (
              <li key={i} className="flex items-start gap-3 text-[16px] leading-relaxed text-ink/90">
                <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-brand" />
                {item}
              </li>
            ))}
          </ul>
        </FadeBlock>
      );
    case "cta":
      return (
        <FadeBlock>
          <motion.div
            className="my-8 rounded-2xl bg-forest bg-stripes p-7 md:p-8"
            initial={{ boxShadow: "0 0 0 0 rgba(242,169,59,0)" }}
            whileInView={
              reduced
                ? undefined
                : {
                    boxShadow: [
                      "0 0 0 0 rgba(242,169,59,0.35)",
                      "0 0 0 18px rgba(242,169,59,0)",
                    ],
                  }
            }
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 1.6, ease: "easeOut" }}
          >
            <h3 className="font-heading text-2xl font-semibold text-white">{block.heading}</h3>
            <p className="mt-2 text-[15px] leading-relaxed text-forest-body">{block.text}</p>
            <Link
              to={block.href}
              className="mt-5 inline-flex items-center gap-2 rounded-xl bg-amber px-6 py-3 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
            >
              {block.buttonLabel}
              <ArrowRight className="h-4 w-4" />
            </Link>
          </motion.div>
        </FadeBlock>
      );
    case "faq":
      return (
        <FadeBlock>
          <div className="mt-10">
            <h2 className="flex items-start gap-3 font-heading text-[28px] font-bold leading-[1.15] text-ink">
              <span aria-hidden className="mt-1.5 h-7 w-1 shrink-0 rounded-full bg-amber" />
              Frequently asked questions
            </h2>
            <FAQAccordion items={block.faqs} className="mt-5" />
          </div>
        </FadeBlock>
      );
    default:
      return null;
  }
}

function ShareRow() {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = window.location.href;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2500);
  };
  return (
    <div className="flex items-center gap-3">
      <button
        onClick={copy}
        className="inline-flex items-center gap-2 rounded-xl border border-border-soft bg-white px-4 py-2.5 text-sm font-semibold text-ink transition-colors hover:border-brand/50 hover:text-brand"
      >
        <Link2 className="h-4 w-4" />
        Copy link
      </button>
      {copied && (
        <motion.span
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-sm font-semibold text-brand"
          role="status"
        >
          Link copied!
        </motion.span>
      )}
    </div>
  );
}

function PostNotFound() {
  return (
    <>
      <SEO
        title="Guide Not Found | SkillShikshya Technical"
        description="The guide you are looking for does not exist. Browse all our vocational training guides."
        path="/blog/"
      />
      <div className="mx-auto flex min-h-[50vh] max-w-3xl flex-col items-center justify-center px-5 py-24 text-center">
        <p className="font-mono text-xs uppercase tracking-[0.12em] text-muted">— 404</p>
        <h1 className="mt-3 font-heading text-4xl font-bold text-forest">Guide not found</h1>
        <p className="mt-3 text-muted">
          This guide doesn't exist (yet). Browse all our skill and career guides instead.
        </p>
        <Link
          to="/blog/"
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-brand px-6 py-3 font-semibold text-white transition-colors hover:bg-brand-dark"
        >
          All guides
          <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </>
  );
}

export default function BlogPost() {
  const { slug = "" } = useParams();
  const post = postBySlug(slug);
  const reduced = usePrefersReducedMotion();

  if (!post) return <PostNotFound />;

  const relatedPosts = posts.filter((p) => p.slug !== post.slug).slice(0, 2);
  const relatedCourse =
    courses.find((c) => c.slug === RELATED_COURSE[post.slug]) ??
    courses.find((c) => c.slug === "electrician-training");

  return (
    <>
      <SEO
        title={`${post.title} | ${site.name}`}
        description={post.excerpt}
        path={`/blog/${post.slug}/`}
        ogImage={post.cover}
        ogType="article"
        jsonLd={[
          blogPostingJsonLd(post),
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Blog", path: "/blog/" },
            { name: post.title, path: `/blog/${post.slug}/` },
          ]),
        ]}
      />

      <article className="bg-white">
        {/* Post header */}
        <header className="mx-auto max-w-3xl px-5 pt-12 md:px-8 md:pt-16">
          <motion.div
            initial="hidden"
            animate="show"
            variants={{
              hidden: {},
              show: { transition: { staggerChildren: 0.08 } },
            }}
          >
            {[
              <Breadcrumbs
                key="crumbs"
                items={[
                  { label: "Home", to: "/" },
                  { label: "Blog", to: "/blog/" },
                  { label: post.title },
                ]}
              />,
              <div key="chip" className="mt-6">
                <CategoryChip label={post.category} />
              </div>,
              <h1
                key="h1"
                className="mt-4 font-heading text-[28px] font-extrabold leading-[1.15] text-ink md:text-[40px]"
              >
                {post.title}
              </h1>,
              <div
                key="meta"
                className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2 font-mono text-xs font-medium uppercase tracking-wide text-muted"
              >
                <span className="inline-flex items-center gap-1.5">
                  <CalendarDays className="h-3.5 w-3.5" />
                  {post.date}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5" />
                  {post.readTime}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <PenLine className="h-3.5 w-3.5" />
                  By {AUTHOR}
                </span>
              </div>,
            ].map((node, i) => (
              <motion.div
                key={i}
                variants={{
                  hidden: { opacity: 0, y: reduced ? 0 : 24 },
                  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
                }}
              >
                {node}
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            className="mt-8 overflow-hidden rounded-2xl bg-forest"
            initial={
              reduced
                ? { opacity: 0 }
                : { opacity: 0, clipPath: "inset(100% 0% 0% 0%)" }
            }
            animate={{ opacity: 1, clipPath: "inset(0% 0% 0% 0%)" }}
            transition={{ duration: 0.8, delay: 0.2, ease: EASE }}
          >
            <img
              src={post.cover}
              alt={post.coverAlt}
              className="aspect-[16/9] w-full object-cover"
            />
          </motion.div>
        </header>

        {/* Article body */}
        <div className="mx-auto max-w-3xl px-5 pb-16 md:px-8">
          {post.body.map((block, i) => (
            <BlockRenderer key={i} block={block} />
          ))}

          {/* Post footer: author card + share row */}
          <div className="mt-12 flex flex-col gap-6 rounded-2xl border border-border-soft bg-mint/60 p-6 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-muted">
                WRITTEN BY
              </p>
              <p className="mt-1.5 font-heading text-lg font-semibold text-ink">{AUTHOR}</p>
              <p className="mt-1 max-w-md text-sm text-muted">
                Free counseling, course guidance, and foreign-employment prep from our New
                Baneshwar team.
              </p>
            </div>
            <ShareRow />
          </div>
        </div>
      </article>

      {/* Related strip */}
      <section className="bg-mint">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
          <SectionEyebrow>— KEEP READING</SectionEyebrow>
          <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-3 md:gap-8">
            {relatedPosts.map((p, i) => (
              <motion.div
                key={p.slug}
                initial={{ opacity: 0, y: reduced ? 0 : 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.5, delay: i * 0.08, ease: "easeOut" }}
              >
                <Link
                  to={`/blog/${p.slug}/`}
                  className="group flex h-full flex-col overflow-hidden rounded-2xl border border-border-soft bg-white shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift"
                >
                  <div className="relative aspect-[16/9] overflow-hidden bg-forest">
                    <img
                      src={p.cover}
                      alt={p.coverAlt}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    <CategoryChip label={p.category} />
                    <h3 className="mt-3 font-heading text-lg font-semibold leading-snug text-ink">
                      {p.title}
                    </h3>
                    <span className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-brand">
                      Read guide
                      <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                    </span>
                  </div>
                </Link>
              </motion.div>
            ))}
            {relatedCourse && (
              <motion.div
                initial={{ opacity: 0, y: reduced ? 0 : 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.5, delay: 0.16, ease: "easeOut" }}
              >
                <CourseCard course={relatedCourse} className="h-full" />
              </motion.div>
            )}
          </div>
        </div>
      </section>
      {/* Pre-footer CTA + Footer rendered by Layout */}
    </>
  );
}
