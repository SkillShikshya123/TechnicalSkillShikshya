import { useEffect, useRef } from "react";
import { Link } from "react-router";
import { motion } from "framer-motion";
import { GraduationCap, Award, ShieldCheck, Briefcase, Database } from "lucide-react";
import SEO, { breadcrumbJsonLd, faqPageJsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import SectionEyebrow from "@/components/SectionEyebrow";
import TrustBadgePill from "@/components/TrustBadgePill";
import FAQAccordion from "@/components/FAQAccordion";
import Reveal from "@/components/Reveal";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";

const PAGE_PATH = "/skill-test-and-certification/";

const FAQS = [
  {
    question: "What is the NSTB certificate?",
    answer:
      "The National Skill Testing Board (NSTB) is Nepal's government body for certifying individual trade skills. It conducts practical, hands-on exams and awards the National Skill Certificate at Level 1, 2 or 3 — a personal credential that proves you can actually do the trade, not just that you attended a class.",
  },
  {
    question: "What is the difference between CTEVT and NSTB?",
    answer:
      "CTEVT certifies the training institution and its program — it means our curriculum, instructors and facilities meet national standards. NSTB certifies the individual worker through a practical exam, issuing a personal Level 1 or Level 2 skill card. In short: CTEVT accredits the school, NSTB certifies you.",
  },
  {
    question: "What is the NSTB skill test fee in Nepal?",
    answer:
      "Board-set fees are Rs 500 for Level 1, Rs 1,200 for Level 2 and Rs 2,500 for Level 3, plus Rs 150 for the certificate and ID card. Concessional rates apply for women, Dalit, Janajati and candidates with disabilities — ask our office to confirm your category before registering.",
  },
  {
    question: "Who is eligible for the NSTB Level 1 skill test?",
    answer:
      "You qualify with either at least one year of relevant work experience in the trade or completion of roughly 160 hours of formal training. Our 390-hour CTEVT courses exceed that bar, so every graduate is eligible — and higher levels require progressively deeper experience.",
  },
  {
    question: "What documents do I need for the NSTB skill test?",
    answer:
      "Typically: a citizenship certificate copy, passport-size photos, your training certificate or employer experience letter, the completed NSTB application form, and the exam fee voucher. Our counseling desk checks your file before submission so nothing bounces back.",
  },
  {
    question: "Where is the NSTB skill test centre in Kathmandu?",
    answer:
      "Exams run at NSTB-designated testing centres in the Kathmandu Valley, scheduled by the board throughout the year. We handle registration guidance, confirm your session venue and date, and run mock tests beforehand so you walk in knowing the exact format and timing.",
  },
  {
    question: "How do I check my NSTB skill test result?",
    answer:
      "NSTB publishes results after each exam session, and successful candidates are issued the National Skill Certificate and ID card. Our office tracks result notices for every batch we prepare and helps you collect or verify your card.",
  },
  {
    question: "Is the NSTB certificate valid for abroad?",
    answer:
      "Yes — it is the credential foreign employers, manpower agencies and embassies ask for in the Gulf, Malaysia, Europe, Israel, Japan and Korea, and it supports the skilled-category labour permit (shram swikriti) from the Department of Foreign Employment. For most destination countries it is effectively required.",
  },
  {
    question: "What is RPL — Recognition of Prior Learning?",
    answer:
      "RPL is the route for experienced workers who never had formal training: instead of taking a course, you document your work history and sit the NSTB practical exam directly. It's the fastest path to certification for people already working in their trade.",
  },
  {
    question: "Do I get a certificate on course completion?",
    answer:
      "Yes — every graduate receives a CTEVT-affiliated completion certificate. On top of that, our curriculum includes NSTB exam preparation so you can earn the individual government skill card on the next exam session.",
  },
];

const BENEFITS = [
  {
    icon: Database,
    title: "National Database",
    line: "Your credential is recorded in a government-recognized system.",
  },
  {
    icon: ShieldCheck,
    title: "Government Verified",
    line: "Issued and backed by national training authorities.",
  },
  {
    icon: Briefcase,
    title: "Manpower Approved",
    line: "Accepted by manpower agencies for overseas job processing.",
  },
  {
    icon: Award,
    title: "Lifetime Credential",
    line: "Once earned, your skill level card is yours for life.",
  },
];

/* ---------- Section 1 — Hero ---------- */
function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo("[data-cert-fade]", { opacity: 0 }, { opacity: 1, duration: 0.5, stagger: 0.08 });
        return;
      }
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
      tl.fromTo(
        "[data-word] > span",
        { yPercent: 110 },
        { yPercent: 0, duration: 0.7, stagger: 0.05 },
        0.15,
      )
        .fromTo("[data-cert-lead]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5 }, 0.6)
        .fromTo(
          "[data-cert-pill]",
          { opacity: 0, scale: 0.8 },
          { opacity: 1, scale: 1, duration: 0.4, stagger: 0.07, ease: "back.out(2)" },
          0.8,
        );
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  const fade = reduced ? { "data-cert-fade": true } : {};

  return (
    <section ref={ref} className="relative overflow-hidden bg-forest bg-stripes" aria-label="Certification guide">
      <div
        className="pointer-events-none absolute -left-40 -top-40 h-[560px] w-[560px] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(242,169,59,0.07) 0%, transparent 65%)" }}
      />
      <div className="mx-auto max-w-4xl px-5 py-20 text-center md:px-8">
        <div className={reduced ? undefined : "opacity-0"} {...fade}>
          <Breadcrumbs
            dark
            className="justify-center"
            items={[{ label: "Home", to: "/" }, { label: "Skill Test & Certification" }]}
          />
        </div>
        <p className="mt-6">
          <SectionEyebrow dark>— CERTIFICATION GUIDE</SectionEyebrow>
        </p>
        <h1 className="mt-5 font-heading text-[34px] font-extrabold leading-[1.1] text-white md:text-[56px] md:leading-[1.05]">
          {["CTEVT", "&", "NSTB", "Certification", "in", "Nepal"].map((w, i) => (
            <span key={i} data-word className="mr-[0.28em] inline-block overflow-hidden align-bottom last:mr-0">
              <span className="inline-block will-change-transform">{w}</span>
            </span>
          ))}
        </h1>
        <p data-cert-lead {...fade} className="mx-auto mt-5 max-w-2xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
          The two credentials behind every skilled trade career in Nepal: CTEVT affiliation certifies
          the training institute, while the NSTB skill test certifies you. Here's what each means —
          fees, Levels 1/2/3, the RPL route, and which certificate you need for work in Nepal or abroad.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-2.5">
          {[
            { icon: GraduationCap, label: "CTEVT Reg. No. 2018-KTM-0421" },
            { icon: Award, label: "NSTB Partner" },
            { icon: ShieldCheck, label: "Ministry of Labour Accredited" },
          ].map((p) => (
            <span key={p.label} data-cert-pill {...fade}>
              <TrustBadgePill icon={p.icon} label={p.label} dark />
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Section 2 — Two-system comparison cards ---------- */
function ComparisonCards() {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo(
          "[data-cmp-card]",
          { opacity: 0 },
          { opacity: 1, duration: 0.4, stagger: 0.12, scrollTrigger: { trigger: el, start: "top 82%", once: true } },
        );
        return;
      }
      gsap.fromTo(
        "[data-cmp-left]",
        { opacity: 0, x: -40 },
        { opacity: 1, x: 0, duration: 0.6, ease: "power3.out", scrollTrigger: { trigger: el, start: "top 82%", once: true } },
      );
      gsap.fromTo(
        "[data-cmp-right]",
        { opacity: 0, x: 40 },
        { opacity: 1, x: 0, duration: 0.6, ease: "power3.out", scrollTrigger: { trigger: el, start: "top 82%", once: true } },
      );
      // Top border accents draw in
      gsap.fromTo(
        "[data-cmp-accent]",
        { scaleX: 0 },
        {
          scaleX: 1,
          duration: 0.5,
          ease: "power3.out",
          delay: 0.3,
          scrollTrigger: { trigger: el, start: "top 82%", once: true },
        },
      );
      // "vs" circle pops with spring
      gsap.fromTo(
        "[data-cmp-vs]",
        { scale: 0 },
        {
          scale: 1,
          duration: 0.5,
          ease: "back.out(2.5)",
          delay: 0.4,
          scrollTrigger: { trigger: el, start: "top 82%", once: true },
        },
      );
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <div ref={ref} className="relative mt-12 grid gap-6 md:grid-cols-2 md:gap-8">
      {/* CTEVT card */}
      <div data-cmp-card data-cmp-left className="overflow-hidden rounded-2xl border border-border-soft bg-white shadow-soft">
        <div data-cmp-accent className="h-1 origin-left bg-brand" />
        <div className="p-8">
          <div className="flex items-start justify-between gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-mint">
              <GraduationCap className="h-6 w-6 text-brand" />
            </div>
            <span className="rounded-full bg-mint px-3 py-1 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-brand">
              Institution-Level
            </span>
          </div>
          <h3 className="mt-5 font-heading text-[22px] font-semibold text-ink">CTEVT Affiliation</h3>
          <p className="mt-3 text-[15px] leading-relaxed text-muted">
            The Council for Technical Education and Vocational Training (CTEVT) is the national
            government body regulating vocational training in Nepal. Our affiliation means our
            curriculum, instructors, and facilities meet national standards — and your completion
            certificate is issued under a recognized framework.
          </p>
        </div>
      </div>

      {/* vs connector */}
      <div
        data-cmp-vs
        className="absolute left-1/2 top-1/2 z-10 hidden h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-4 border-white bg-amber font-heading text-sm font-bold text-forest shadow-lift md:flex"
        aria-hidden="true"
      >
        vs
      </div>

      {/* NSTB card */}
      <div data-cmp-card data-cmp-right className="overflow-hidden rounded-2xl border border-border-soft bg-white shadow-soft">
        <div data-cmp-accent className="h-1 origin-left bg-amber" />
        <div className="p-8">
          <div className="flex items-start justify-between gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-soft">
              <Award className="h-6 w-6 text-amber" />
            </div>
            <span className="rounded-full bg-amber-soft px-3 py-1 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-amber">
              Individual-Level
            </span>
          </div>
          <h3 className="mt-5 font-heading text-[22px] font-semibold text-ink">The NSTB Skill Test</h3>
          <p className="mt-3 text-[15px] leading-relaxed text-muted">
            The National Skill Testing Board (NSTB) conducts physical, practical exams to certify
            individual trade workers. Passing earns you a personal Level 1 or Level 2 qualification
            card — the credential foreign employers and embassies ask for.
          </p>
        </div>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */
export default function Certification() {
  const reduced = usePrefersReducedMotion();

  return (
    <>
      <SEO
        title="CTEVT & NSTB Certification in Nepal — What's the Difference? | SkillShikshya Technical"
        description="CTEVT and NSTB certification in Nepal explained: skill test fees (L1 Rs 500 / L2 Rs 1,200 / L3 Rs 2,500), eligibility, RPL route, skill test centres & validity for work abroad."
        path={PAGE_PATH}
        jsonLd={[
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Skill Test & Certification", path: PAGE_PATH },
          ]),
          faqPageJsonLd(FAQS),
        ]}
      />

      {/* 1 — Hero */}
      <Hero />

      {/* 2 — The Two Systems */}
      <section className="bg-white py-16 md:py-24" aria-label="Two credentials compared">
        <div className="mx-auto max-w-6xl px-5 md:px-8">
          <Reveal className="max-w-2xl" stagger={0.12}>
            <SectionEyebrow>— TWO CREDENTIALS</SectionEyebrow>
            <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
              What Is the Difference Between CTEVT and NSTB?
            </h2>
          </Reveal>
          <ComparisonCards />
        </div>
      </section>

      {/* 3 — Benefits at a Glance */}
      <section className="bg-mint py-16 md:py-24" aria-label="Benefits at a glance">
        <div className="mx-auto max-w-6xl px-5 md:px-8">
          <Reveal className="max-w-2xl" stagger={0.12}>
            <SectionEyebrow>— AT A GLANCE</SectionEyebrow>
            <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
              Why the National Skill Certificate Matters
            </h2>
          </Reveal>
          <Reveal className="mt-10 grid grid-cols-2 gap-6 lg:grid-cols-4 md:gap-8" stagger={0.09}>
            {BENEFITS.map((b) => (
              <div
                key={b.title}
                className="rounded-2xl border border-border-soft bg-white p-6 shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-mint">
                  <b.icon className="h-5 w-5 text-brand" />
                </div>
                <h3 className="mt-4 font-heading text-lg font-semibold text-ink">{b.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{b.line}</p>
              </div>
            ))}
          </Reveal>
        </div>
      </section>

      {/* 4 — Common Certification FAQs */}
      <section className="bg-white py-16 md:py-24" aria-label="Certification FAQs">
        <div className="mx-auto max-w-3xl px-5 md:px-8">
          <Reveal className="text-center" stagger={0.12}>
            <SectionEyebrow>— QUESTIONS</SectionEyebrow>
            <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
              CTEVT & NSTB Certification FAQs
            </h2>
          </Reveal>
          <Reveal className="mt-10" stagger={0.06} y={24}>
            <FAQAccordion items={FAQS} />
          </Reveal>
        </div>
      </section>

      {/* 5 — Counseling CTA banner (serves as this page's pre-footer CTA) */}
      <section className="bg-forest bg-stripes" aria-label="Counseling CTA">
        <motion.div
          className="mx-auto max-w-4xl px-5 py-16 text-center md:px-8 md:py-24"
          initial={reduced ? { opacity: 0 } : { opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        >
          <SectionEyebrow dark>— STILL CONFUSED?</SectionEyebrow>
          <h2 className="mt-4 font-heading text-3xl font-bold text-white md:text-[40px] md:leading-[1.1]">
            Which certificate do you actually need?
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
            Confused about visa certificate requirements? Let our counselors explain exactly which
            certificate (CTEVT or NSTB) you need based on your target country.
          </p>
          <div className="mt-8">
            <motion.div
              className="inline-block"
              animate={reduced ? {} : { boxShadow: ["0 0 0 0 rgba(242,169,59,0.45)", "0 0 0 14px rgba(242,169,59,0)"] }}
              transition={{ duration: 2.4, repeat: Infinity }}
              style={{ borderRadius: 12 }}
              whileHover={{ boxShadow: "0 0 0 0 rgba(242,169,59,0)" }}
            >
              <Link
                to="/contact-and-counseling/"
                className="inline-block rounded-xl bg-amber px-7 py-3.5 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
              >
                Talk to a counselor for free
              </Link>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* 6 — Footer rendered by Layout */}
    </>
  );
}
