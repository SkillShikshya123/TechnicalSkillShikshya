import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Plane } from "lucide-react";
import SEO, { breadcrumbJsonLd, reviewJsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import SectionEyebrow from "@/components/SectionEyebrow";
import StatBlock from "@/components/StatBlock";
import FilterPills from "@/components/FilterPills";
import TestimonialCard from "@/components/TestimonialCard";
import { testimonials, type Testimonial } from "@/data/testimonials";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";

const CATEGORY_ORDER = [
  "Construction & Electrical",
  "Beauty & Wellness",
  "Hospitality & Culinary",
  "Care Services",
];

const H1_WORDS = ["Graduate", "Success", "Stories,", "Real", "Placements"];
const HERO_STATS = [
  { value: 2000, suffix: "+", label: "Graduates" },
  { value: 90, suffix: "%+", label: "Placement" },
  { value: 7, suffix: "+", label: "Countries" },
];

/** Abroad placements get a tiny Plane icon + destination chip (success-stories.md §2). */
function abroadDestination(t: Testimonial): string | null {
  if (/saudi/i.test(t.location)) return "Saudi Arabia";
  if (/israel/i.test(t.location)) return "Israel";
  return null;
}

function StoryCard({ t, index }: { t: Testimonial; index: number }) {
  const reduced = usePrefersReducedMotion();
  const dest = abroadDestination(t);
  return (
    <motion.div
      className="relative h-full"
      initial={reduced ? { opacity: 0 } : { opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.35, ease: "easeOut", delay: index * 0.06 }}
    >
      {dest && (
        <span className="absolute right-4 top-4 z-10 inline-flex items-center gap-1 rounded-full bg-amber-soft px-2.5 py-1 text-[11px] font-semibold text-[#9A6714]">
          <Plane className="h-3 w-3" />
          {dest}
        </span>
      )}
      <TestimonialCard testimonial={t} className="h-full" />
    </motion.div>
  );
}

/** Section 1 — forest hero with kinetic H1 + compact dark stat chips. */
function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo("[data-fade]", { opacity: 0 }, { opacity: 1, duration: 0.5, stagger: 0.08 });
        return;
      }
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
      tl.fromTo(
        "[data-word] > span",
        { yPercent: 110 },
        { yPercent: 0, duration: 0.7, stagger: 0.06 },
        0.15,
      )
        .fromTo(
          "[data-hl]",
          { "--hl-scale": 0 },
          { "--hl-scale": 1, duration: 0.5, ease: "power2.out" },
          0.9,
        )
        .fromTo("[data-lead]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 1.0)
        .fromTo("[data-stats]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 1.1);
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <section ref={sectionRef} className="bg-forest bg-stripes" aria-label="Success stories introduction">
      <div className="mx-auto max-w-4xl px-5 py-20 text-center md:px-8">
        <div className="flex justify-center">
          <Breadcrumbs dark items={[{ label: "Home", to: "/" }, { label: "Success Stories" }]} />
        </div>
        <SectionEyebrow dark center className="mt-6">
          — SUCCESS STORIES
        </SectionEyebrow>
        <h1 className="mt-4 font-heading text-[34px] font-extrabold leading-[1.1] text-white md:text-[56px] md:leading-[1.05]">
          {H1_WORDS.map((w, i) => (
            <span key={i} data-word className="mr-[0.28em] inline-block overflow-hidden align-bottom last:mr-0">
              <span className="inline-block will-change-transform">
                {i >= 3 ? (
                  <span
                    className="hl-underline"
                    data-hl
                    style={{ ["--hl-scale" as never]: reduced ? 1 : 0 }}
                  >
                    {w}
                  </span>
                ) : (
                  w
                )}
              </span>
            </span>
          ))}
        </h1>
        <p data-lead data-fade className="mx-auto mt-5 max-w-2xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
          Graduate success stories with real placement outcomes: electricians wiring Gulf sites in
          Saudi Arabia, beauticians running Kathmandu salons, caregivers in Israel G2G homes —
          2,000+ graduates placed since 2018, every one verifiable in our registry.
        </p>
        <div data-stats data-fade className="mx-auto mt-10 grid max-w-2xl grid-cols-3 gap-4 md:gap-6">
          {HERO_STATS.map((s, i) => (
            <StatBlock
              key={s.label}
              value={s.value}
              suffix={s.suffix}
              label={s.label}
              dark
              delay={0.7 + i * 0.15}
              className="md:text-center"
            />
          ))}
        </div>
      </div>
    </section>
  );
}

export default function SuccessStories() {
  const groups = CATEGORY_ORDER.map((cat) => ({
    cat,
    items: testimonials.filter((t) => t.category === cat),
  }));
  const options = [
    `All Stories (${testimonials.length})`,
    ...groups.map((g) => `${g.cat} (${g.items.length})`),
  ];
  const [active, setActive] = useState(options[0]);
  const activeCat = active.replace(/ \(\d+\)$/, "");
  const visibleGroups = activeCat === "All Stories" ? groups : groups.filter((g) => g.cat === activeCat);

  return (
    <>
      <SEO
        title="Graduate Success Stories — Real Placements in Nepal & Abroad | SkillShikshya Technical"
        description="SkillShikshya graduate success stories and placement outcomes: electrician course reviews from Nepal to Saudi Arabia, beautician success stories in Kathmandu, caregivers in Israel & more."
        path="/success-stories/"
        jsonLd={[
          ...reviewJsonLd(testimonials.map((t) => ({ author: t.name, body: t.quote, rating: t.stars }))),
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Success Stories", path: "/success-stories/" },
          ]),
        ]}
      />

      {/* 1 — Hero */}
      <Hero />

      {/* 2 — Filter pills + grouped testimonials */}
      <section className="bg-white" aria-label="Filter stories by trade category">
        <div className="mx-auto max-w-6xl px-5 pb-10 pt-16 md:px-8 md:pt-24">
          <FilterPills options={options} active={active} onChange={setActive} />
        </div>
      </section>
      <AnimatePresence mode="wait">
        <motion.div
          key={active}
          initial={false}
          exit={{ opacity: 0, scale: 0.99, transition: { duration: 0.2 } }}
        >
          {visibleGroups.map((g, gi) => (
            <section key={g.cat} className={gi % 2 === 1 ? "bg-mint" : "bg-white"} aria-label={g.cat}>
              <div className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-20">
                <SectionEyebrow>— {g.cat.toUpperCase()}</SectionEyebrow>
                <motion.h3
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.6 }}
                  transition={{ duration: 0.4, ease: "easeOut" }}
                  className="mt-3 font-heading text-2xl font-semibold text-ink md:text-[28px]"
                >
                  {g.cat}
                </motion.h3>
                <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {g.items.map((t, i) => (
                    <StoryCard key={t.id} t={t} index={i} />
                  ))}
                </div>
              </div>
            </section>
          ))}
        </motion.div>
      </AnimatePresence>

      {/* 3 — Registry cross-link band */}
      <section className="bg-forest bg-stripes" aria-label="Verify graduates">
        <motion.div
          className="mx-auto flex max-w-6xl flex-col items-start gap-6 px-5 py-12 md:flex-row md:items-center md:justify-between md:px-8 md:py-16"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        >
          <div>
            <h2 className="font-heading text-2xl font-semibold text-white md:text-[28px]">
              Employers: verify any graduate by certificate ID
            </h2>
            <p className="mt-2 max-w-xl text-[15px] leading-relaxed text-forest-body">
              Every story above maps to a verifiable record in our graduate registry.
            </p>
          </div>
          <Link
            to="/graduate-registry/"
            className="group inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-amber px-6 py-3.5 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
          >
            Open Graduate Registry
            <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
          </Link>
        </motion.div>
      </section>

      {/* 4 — CTA variant (success-stories.md §4) */}
      <section className="bg-forest bg-stripes" aria-label="Become a success story">
        <motion.div
          className="mx-auto max-w-4xl px-5 py-16 text-center md:px-8 md:py-24"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        >
          <SectionEyebrow dark>— YOUR TURN</SectionEyebrow>
          <h2 className="mt-4 font-heading text-3xl font-bold text-white md:text-[40px] md:leading-[1.1]">
            Want to be our next success story?
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
            Schedule a quick, free call with our career counseling office today.
          </p>
          <div className="mt-8">
            <Link
              to="/contact-and-counseling/"
              className="inline-block rounded-xl bg-amber px-7 py-3.5 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
            >
              Request Counseling Callback
            </Link>
          </div>
        </motion.div>
      </section>
    </>
  );
}
