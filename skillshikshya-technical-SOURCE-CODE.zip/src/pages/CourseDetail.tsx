import { useEffect, useRef, useState } from "react";
import { Link, Navigate, useParams } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import {
  ShieldCheck,
  Award,
  Clock,
  FileCheck,
  Briefcase,
  Store,
  Plane,
  CheckCircle2,
  ChevronDown,
  GraduationCap,
  MessageCircle,
  ArrowRight,
} from "lucide-react";
import SEO, { breadcrumbJsonLd, courseJsonLd, faqPageJsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import SectionEyebrow from "@/components/SectionEyebrow";
import BadgeChip from "@/components/BadgeChip";
import CourseCard from "@/components/CourseCard";
import FAQAccordion from "@/components/FAQAccordion";
import InquiryForm from "@/components/InquiryForm";
import Reveal from "@/components/Reveal";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";
import { scrollToTarget } from "@/lib/scroll";
import { categoryPath, coursePath, courses, type Course } from "@/data/courses";
import { batches } from "@/data/batches";
import { site } from "@/data/site";
import { cn } from "@/lib/utils";

const PHONE_RE = /^(9\d{9}|0\d{8,9}|\d{7,10})$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const trackIcons = [Briefcase, Store, Plane];

/** Fee count-up (0 → target, 1.2s, formatted) on first scroll into view. */
function FeeCountUp({ value }: { value: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const reduced = usePrefersReducedMotion();
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const fmt = (n: number) => `NPR ${Math.round(n).toLocaleString("en-US")}`;
    if (reduced) {
      el.textContent = fmt(value);
      return;
    }
    const obj = { v: 0 };
    const tween = gsap.to(obj, {
      v: value,
      duration: 1.2,
      ease: "power2.out",
      snap: { v: 100 },
      onUpdate: () => {
        el.textContent = fmt(obj.v);
      },
      scrollTrigger: { trigger: el, start: "top 85%", once: true },
    });
    return () => {
      tween.scrollTrigger?.kill();
      tween.kill();
    };
  }, [value, reduced]);
  return <span ref={ref}>NPR {value.toLocaleString("en-US")}</span>;
}

/** Gated brochure download card (forest). */
function BrochureCard({ course }: { course: Course }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState<{ name?: string; phone?: string; email?: string }>({});
  const [sent, setSent] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs: typeof errors = {};
    if (!name.trim()) errs.name = "Required";
    if (!PHONE_RE.test(phone.replace(/[\s-]/g, ""))) errs.phone = "Valid phone required";
    if (!EMAIL_RE.test(email.trim())) errs.email = "Valid email required";
    setErrors(errs);
    if (Object.keys(errs).length === 0) setSent(true);
  };

  return (
    <div className="rounded-2xl bg-forest bg-stripes p-6 text-white">
      <div className="flex items-center gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber/15">
          <FileCheck className="h-5 w-5 text-amber" />
        </span>
        <div>
          <h3 className="font-heading text-base font-semibold">Course brochure (PDF)</h3>
          <p className="text-xs text-forest-body">{course.name} syllabus, fees & batch calendar</p>
        </div>
      </div>
      {sent ? (
        <div className="mt-5 flex flex-col items-center py-4 text-center">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", bounce: 0.5 }}>
            <CheckCircle2 className="h-12 w-12 text-amber" />
          </motion.div>
          <p className="mt-3 text-sm font-medium">Brochure sent!</p>
          <p className="mt-1 text-xs text-forest-body">Check WhatsApp/SMS for your copy.</p>
        </div>
      ) : (
        <form onSubmit={submit} noValidate className="mt-4 space-y-3">
          {(
            [
              { label: "Name", value: name, set: setName, error: errors.name, type: "text", placeholder: "Your name" },
              { label: "Phone", value: phone, set: setPhone, error: errors.phone, type: "tel", placeholder: "98XXXXXXXX" },
              { label: "Email", value: email, set: setEmail, error: errors.email, type: "email", placeholder: "you@email.com" },
            ] as const
          ).map((f) => (
            <div key={f.label}>
              <input
                type={f.type}
                value={f.value}
                onChange={(e) => f.set(e.target.value)}
                placeholder={f.placeholder}
                aria-label={f.label}
                className={cn(
                  "w-full rounded-xl border bg-white/10 px-4 py-2.5 text-sm text-white outline-none transition-colors placeholder:text-white/40 focus:border-amber",
                  f.error ? "border-red-400" : "border-white/25",
                )}
              />
              {f.error && <p className="mt-1 text-xs font-medium text-amber">{f.error}</p>}
            </div>
          ))}
          <button
            type="submit"
            className="w-full rounded-xl bg-amber px-5 py-3 text-sm font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
          >
            Download Brochure
          </button>
        </form>
      )}
    </div>
  );
}

/** Quick facts mono card. */
function QuickFactsCard({ course }: { course: Course }) {
  const batch = batches.find((b) => b.courseSlug === course.slug);
  const rows: [string, string][] = [
    ["Duration", course.duration],
    ["Fee", course.feeLabel],
    ["Next batch", batch ? batch.startLabel.replace("Starts ", "") : "Monthly intake"],
    ["Seats left", batch ? `${batch.seatsLeft} of ${batch.seatsTotal}` : "Limited"],
    ["NSTB level", course.nstbLevel],
  ];
  return (
    <div className="rounded-2xl border border-border-soft bg-white p-6">
      <h3 className="font-heading text-base font-semibold text-ink">Quick facts</h3>
      <dl className="mt-4 space-y-3">
        {rows.map(([k, v]) => (
          <div key={k} className="flex items-start justify-between gap-4 border-b border-border-soft pb-3 last:border-0 last:pb-0">
            <dt className="font-mono text-[11px] uppercase tracking-[0.1em] text-muted">{k}</dt>
            <dd className="text-right text-sm font-medium text-ink">{v}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

/** Curriculum accordion — first module open by default, height animation. */
function CurriculumAccordion({ course }: { course: Course }) {
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  const hoursFor = (week: string) => {
    const nums = week.match(/\d+/g)?.map(Number) ?? [1];
    const weeks = nums.length > 1 ? nums[nums.length - 1] - nums[0] + 1 : 1;
    return weeks * 12;
  };
  return (
    <div className="space-y-3">
      {course.curriculum.map((mod, i) => {
        const open = openIdx === i;
        return (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -16 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.4, delay: i * 0.07, ease: "easeOut" }}
            className="overflow-hidden rounded-2xl border border-border-soft bg-white"
          >
            <button
              className="flex w-full items-center gap-4 px-5 py-4 text-left"
              onClick={() => setOpenIdx(open ? null : i)}
              aria-expanded={open}
            >
              <span className="shrink-0 rounded-full bg-amber-soft px-3 py-1 font-mono text-[11px] font-semibold uppercase tracking-wide text-[#9A6714]">
                Module {String(i + 1).padStart(2, "0")}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-base font-semibold text-ink">{mod.title}</span>
                <span className="block font-mono text-[11px] uppercase tracking-wide text-muted">{mod.week}</span>
              </span>
              <ChevronDown className={cn("h-5 w-5 shrink-0 text-brand transition-transform duration-300", open && "rotate-180")} />
            </button>
            <AnimatePresence initial={false}>
              {open && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                >
                  <div className="border-t border-border-soft px-5 py-4">
                    <ul className="space-y-2">
                      {mod.points.map((p, j) => (
                        <li key={j} className="flex items-start gap-2.5 text-[15px] text-muted">
                          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
                          {p}
                        </li>
                      ))}
                    </ul>
                    <p className="mt-3 font-mono text-[11px] uppercase tracking-wide text-muted">
                      ≈ {hoursFor(mod.week)} practical hours
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        );
      })}
    </div>
  );
}

/** Graceful state for unknown slugs. */
function CourseNotFound({ slug }: { slug?: string }) {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-3xl flex-col items-center justify-center px-5 py-24 text-center">
      <SEO
        title="Course Not Found | SkillShikshya Technical"
        description="The course you are looking for does not exist. Browse all 10 CTEVT-certified vocational courses in Kathmandu."
        path={`/courses/${slug ?? ""}/`}
      />
      <p className="font-mono text-xs uppercase tracking-[0.12em] text-muted">— COURSE NOT FOUND</p>
      <h1 className="mt-3 font-heading text-4xl font-bold text-forest">We couldn't find that course</h1>
      <p className="mt-3 max-w-md text-muted">
        The course <span className="font-mono text-sm text-ink">"{slug}"</span> isn't one of our
        current programs — but all 10 of our CTEVT-certified trade courses are one click away.
      </p>
      <div className="mt-7 flex flex-col gap-3 sm:flex-row">
        <Link to="/courses/" className="rounded-xl bg-brand px-6 py-3 font-semibold text-white transition-colors hover:bg-brand-dark">
          Browse all courses
        </Link>
        <Link to="/" className="rounded-xl border border-border-soft px-6 py-3 font-semibold text-ink transition-colors hover:border-brand/50">
          Go home
        </Link>
      </div>
    </div>
  );
}

/* ------------------------------ Main view ------------------------------ */

function CourseDetailView({ course }: { course: Course }) {
  const reduced = usePrefersReducedMotion();
  const pageRef = useRef<HTMLDivElement>(null);
  const batch = batches.find((b) => b.courseSlug === course.slug);
  const related = course.relatedSlugs
    .map((s) => courses.find((c) => c.slug === s))
    .filter((c): c is Course => Boolean(c))
    .slice(0, 3);

  const namePrefix = course.h1.replace(/ Course in Nepal$/i, "");
  const prefixWordCount = namePrefix.split(" ").length;
  const h1Words = course.h1.split(" ");

  const metaDescription = `${course.primaryKeywords[0].charAt(0).toUpperCase()}${course.primaryKeywords[0].slice(1)} — ${course.description} ${course.duration}, ${course.feeLabel} all-inclusive at our CTEVT-affiliated Kathmandu institute with NSTB skill-test prep & placement support.`;

  // Hero entrance timeline (design course-detail §1)
  useEffect(() => {
    const el = pageRef.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo("[data-fade]", { opacity: 0 }, { opacity: 1, duration: 0.5, stagger: 0.06 });
        gsap.set("[data-hl]", { "--hl-scale": 1 });
        return;
      }
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
      tl.fromTo("[data-crumb]", { opacity: 0 }, { opacity: 1, duration: 0.3 }, 0.05)
        .fromTo(
          "[data-word] > span",
          { yPercent: 110 },
          { yPercent: 0, duration: 0.65, stagger: 0.05 },
          0.15,
        )
        .fromTo("[data-hl]", { "--hl-scale": 0 }, { "--hl-scale": 1, duration: 0.4, ease: "power2.out" }, 0.85)
        .fromTo("[data-lead]", { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 0.9)
        .fromTo("[data-chip]", { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.4, stagger: 0.06, ease: "power3.out" }, 1.0)
        .fromTo(
          "[data-trust]",
          { opacity: 0, scale: 0.9 },
          { opacity: 1, scale: 1, duration: 0.4, stagger: 0.06, ease: "back.out(2)" },
          0.9,
        )
        .fromTo(
          "[data-hero-img]",
          { clipPath: "inset(100% 0% 0% 0%)" },
          { clipPath: "inset(0% 0% 0% 0%)", duration: 0.8, ease: "power3.out" },
          0.7,
        )
        .fromTo(
          "[data-side]",
          { opacity: 0, y: 24 },
          { opacity: 1, y: 0, duration: 0.5, stagger: 0.1, ease: "power3.out" },
          0.6,
        );
    }, el);
    return () => ctx.revert();
  }, [reduced, course.slug]);

  const goToForm = () =>
    scrollToTarget(window.matchMedia("(min-width: 1024px)").matches ? "#inquiry-form" : "#inquiry-form-mobile");

  const fade = reduced ? { "data-fade": true } : {};

  return (
    <div ref={pageRef}>
      <SEO
        title={`${course.h1} — CTEVT Certified Training | SkillShikshya Technical`}
        description={metaDescription}
        path={coursePath(course)}
        jsonLd={[
          courseJsonLd({ name: course.h1, description: course.description, slug: course.slug, categorySlug: course.categorySlug, fee: course.fee }),
          faqPageJsonLd(course.faqs),
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Courses", path: "/courses/" },
            { name: course.category, path: categoryPath(course.categorySlug) },
            { name: course.name, path: coursePath(course) },
          ]),
        ]}
      />

      {/* 1 — Course hero + trust bar */}
      <section className="bg-white" aria-label={course.name}>
        <div className="mx-auto max-w-7xl px-5 pt-10 md:px-8 md:pt-14">
          <div data-crumb {...fade}>
            <Breadcrumbs
              items={[
                { label: "Home", to: "/" },
                { label: "Courses", to: "/courses/" },
                { label: course.category, to: categoryPath(course.categorySlug) },
                { label: course.name },
              ]}
            />
          </div>
          <Link
            to={categoryPath(course.categorySlug)}
            data-crumb
            {...fade}
            className="mt-5 inline-block font-mono text-[12.5px] font-medium uppercase tracking-[0.12em] text-amber transition-colors hover:text-brand"
          >
            — {course.category}
          </Link>
          <h1 className="mt-3 max-w-4xl font-heading text-[30px] font-extrabold leading-[1.1] text-ink md:text-[44px]">
            {h1Words.map((w, i) => (
              <span key={i} data-word className="mr-[0.26em] inline-block overflow-hidden align-bottom last:mr-0">
                <span className="inline-block will-change-transform">
                  {i < prefixWordCount ? (
                    <span className="hl-underline" data-hl style={{ ["--hl-scale" as never]: reduced ? 1 : 0 }}>
                      {w}
                    </span>
                  ) : (
                    w
                  )}
                </span>
              </span>
            ))}
          </h1>
          <p data-lead {...fade} className="mt-4 max-w-2xl text-[17px] leading-[1.65] text-muted md:text-[19px]">
            {course.description} Hands-on {course.duration.toLowerCase()} program in New Baneshwar,
            Kathmandu — {course.nstbLevel.toLowerCase()}.
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-2.5">
            {course.badge && (
              <span data-chip {...fade}>
                <BadgeChip label={course.badge} />
              </span>
            )}
            <span data-chip {...fade} className="rounded-full border border-border-soft bg-mint px-4 py-1.5 font-mono text-xs font-medium uppercase tracking-[0.08em] text-ink">
              {course.duration} · {course.feeLabel} · {batch ? `Next batch ${batch.startLabel.replace("Starts ", "")}` : "New batches monthly"}
            </span>
          </div>

          {/* Trust bar — always above the fold */}
          <div className="mt-7 grid grid-cols-2 gap-3 rounded-2xl border border-border-soft bg-mint p-4 sm:grid-cols-3 md:p-5 lg:grid-cols-5">
            {[
              { icon: ShieldCheck, label: "CTEVT Affiliated" },
              { icon: Award, label: course.nstbLevel.startsWith("Maps to") ? "NSTB Level mapping" : "NSTB-aligned certificate" },
              { icon: Clock, label: course.duration },
              { icon: FileCheck, label: "Certificate included" },
              { icon: Briefcase, label: "Placement support" },
            ].map((t) => (
              <div key={t.label} data-trust {...fade} className="flex items-center gap-2.5 rounded-xl bg-white/70 px-3.5 py-3">
                <t.icon className="h-5 w-5 shrink-0 text-brand" />
                <span className="text-sm font-medium text-ink">{t.label}</span>
              </div>
            ))}
          </div>

          {/* Course image */}
          <div data-hero-img {...fade} className="mt-8 overflow-hidden rounded-2xl">
            <img
              src={course.image}
              alt={course.imageAlt}
              className="aspect-video w-full object-cover"
              loading="eager"
            />
          </div>
        </div>
      </section>

      {/* Body: main column + sticky sidebar */}
      <div className="mx-auto max-w-7xl px-5 py-14 md:px-8 lg:grid lg:grid-cols-[minmax(0,1fr)_360px] lg:gap-12">
        <div className="max-w-3xl space-y-14">
          {/* 2 — Overview */}
          <section aria-label="Overview">
            <Reveal stagger={0.1} y={20}>
              <div>
                <SectionEyebrow>— OVERVIEW</SectionEyebrow>
                <h2 className="mt-3 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[36px]">
                  What you'll learn in this course
                </h2>
                <p className="mt-4 text-[16px] leading-[1.7] text-muted">{course.overview}</p>
              </div>
              <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                {course.curriculum.slice(0, 6).map((m, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-[15px] font-medium text-ink">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-brand" />
                    {m.title}
                  </li>
                ))}
              </ul>
            </Reveal>
          </section>

          {/* 3 — Who this is for */}
          <section aria-label="Who this is for" className="rounded-2xl bg-mint p-6 md:p-8">
            <Reveal stagger={0.1} y={24}>
              <div>
                <SectionEyebrow>— WHO THIS IS FOR</SectionEyebrow>
                <h3 className="mt-3 font-heading text-2xl font-semibold text-ink">
                  Three paths out of this course
                </h3>
              </div>
              <div className="mt-6 grid gap-4 sm:grid-cols-3">
                {course.whoItsFor.map((t, i) => {
                  const Icon = trackIcons[i] ?? Briefcase;
                  return (
                    <div
                      key={t.title}
                      className="group rounded-2xl border border-border-soft bg-white p-5 transition-all duration-200 hover:-translate-y-1 hover:shadow-soft"
                    >
                      <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand/10 transition-transform duration-200 group-hover:rotate-[8deg]">
                        <Icon className="h-5 w-5 text-brand" />
                      </span>
                      <h4 className="mt-4 font-heading text-base font-semibold text-ink">{t.title}</h4>
                      <p className="mt-2 text-sm leading-relaxed text-muted">{t.description}</p>
                    </div>
                  );
                })}
              </div>
            </Reveal>
          </section>

          {/* 4 — Curriculum */}
          <section aria-label="Curriculum">
            <SectionEyebrow>— CURRICULUM</SectionEyebrow>
            <h2 className="mt-3 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[36px]">
              Course curriculum, week by week
            </h2>
            <div className="mt-6">
              <CurriculumAccordion course={course} />
            </div>
          </section>

          {/* 5 — Duration & fee */}
          <section aria-label="Duration and fee" className="rounded-2xl border border-border-soft bg-white p-6 md:p-8">
            <SectionEyebrow>— INVESTMENT</SectionEyebrow>
            <h2 className="mt-3 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[36px]">
              Fees and duration
            </h2>
            <p className="mt-5 font-heading text-[40px] font-extrabold leading-none text-forest">
              <FeeCountUp value={course.fee} />
            </p>
            <p className="mt-3 font-mono text-xs uppercase tracking-[0.1em] text-muted">
              {course.duration} · All materials included · Certificate exam fee included
            </p>
            <Reveal className="mt-6 grid gap-3 sm:grid-cols-3" stagger={0.08} y={16}>
              {[
                { title: "Full upfront −5%", desc: "Pay once at enrollment and save" },
                { title: "50/50 installment", desc: "Two payments, zero interest" },
                { title: "Scholarship available", desc: "Sponsored seats for qualifying students" },
              ].map((c) => (
                <Link
                  key={c.title}
                  to="/?scroll=fees"
                  className="rounded-xl border border-border-soft bg-mint/60 p-4 transition-colors hover:border-brand/40 hover:bg-mint"
                >
                  <p className="text-sm font-semibold text-ink">{c.title}</p>
                  <p className="mt-1 text-xs text-muted">{c.desc}</p>
                </Link>
              ))}
            </Reveal>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <button
                onClick={goToForm}
                className="rounded-xl bg-brand px-7 py-3.5 font-semibold text-white transition-all duration-150 hover:scale-[1.02] hover:bg-brand-dark active:scale-[0.98]"
              >
                Reserve Your Seat
              </button>
              <a
                href={`https://wa.me/${site.contact.whatsappNumber}?text=${encodeURIComponent(`Hi SkillShikshya! I want to ask about the fee for the ${course.name} course.`)}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-border-soft px-7 py-3.5 font-semibold text-ink transition-colors hover:border-brand/50"
              >
                <MessageCircle className="h-4 w-4 text-whatsapp" />
                Ask about fees on WhatsApp
              </a>
            </div>
          </section>

          {/* Mobile in-flow inquiry form (after section 5) */}
          <div className="lg:hidden">
            <InquiryForm courseSlug={course.slug} id="inquiry-form-mobile" />
          </div>

          {/* 6 — Eligibility */}
          <section aria-label="Eligibility" className="rounded-2xl bg-mint p-6 md:p-7">
            <Reveal stagger={0.1} y={20}>
              <div className="flex items-start gap-4">
                <motion.span
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ type: "spring", bounce: 0.5, delay: 0.15 }}
                  className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white"
                >
                  <GraduationCap className="h-6 w-6 text-brand" />
                </motion.span>
                <div>
                  <SectionEyebrow>— ELIGIBILITY</SectionEyebrow>
                  <h2 className="mt-3 font-heading text-2xl font-semibold text-ink">
                    Eligibility — who can join
                  </h2>
                  <p className="mt-2 text-[15px] leading-relaxed text-ink">
                    {course.eligibility}
                    {!/18\+/.test(course.eligibility) && " Age 16+ recommended."}
                  </p>
                </div>
              </div>
            </Reveal>
          </section>

          {/* 7 — Career outcomes */}
          <section aria-label="Career outcomes">
            <SectionEyebrow>— CAREER OUTCOMES</SectionEyebrow>
            <h2 className="mt-3 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[36px]">
              Career outcomes and salary in Nepal and abroad
            </h2>
            <div className="mt-6 grid gap-5 md:grid-cols-2">
              <motion.div
                initial={reduced ? { opacity: 0 } : { opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="rounded-2xl border border-border-soft bg-white p-6"
              >
                <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-muted">
                  Local earnings
                </p>
                <p className="mt-3 font-heading text-[26px] font-bold leading-snug text-forest">
                  {course.outcomes.localSalary.split(/\/month|;/)[0]}
                  <span className="text-base font-semibold text-muted">/month</span>
                </p>
                <p className="mt-2 text-sm text-muted">
                  {course.outcomes.localSalary}
                </p>
                <p className="mt-2 text-xs italic text-muted">
                  Kathmandu Valley average, Batch 2024–2026 graduate data.
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {course.outcomes.roles.map((r) => (
                    <span key={r} className="rounded-full bg-mint px-3 py-1 font-mono text-[11px] uppercase tracking-wide text-ink">
                      {r}
                    </span>
                  ))}
                </div>
              </motion.div>
              <motion.div
                initial={reduced ? { opacity: 0 } : { opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.5, ease: "easeOut", delay: 0.1 }}
                className="rounded-2xl border border-amber/40 bg-amber-soft/50 p-6"
              >
                <div className="flex items-center gap-2.5">
                  <Plane className="h-5 w-5 text-[#9A6714]" />
                  <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#9A6714]">
                    Abroad placement
                  </p>
                </div>
                <p className="mt-3 text-[15px] leading-relaxed text-ink">{course.outcomes.abroadNote}</p>
                <Link
                  to="/foreign-employment-preparation/"
                  className="group mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-brand"
                >
                  See foreign employment prep
                  <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                </Link>
              </motion.div>
            </div>
          </section>

          {/* 8 — Certificate & skill test */}
          <section aria-label="Certification" className="relative overflow-hidden rounded-2xl border border-border-soft bg-white p-6 pl-8 md:p-8 md:pl-10">
            <motion.span
              aria-hidden
              initial={{ scaleY: 0 }}
              whileInView={{ scaleY: 1 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="absolute left-0 top-0 h-full w-1 origin-top bg-forest"
            />
            <Reveal stagger={0.1} y={20}>
              <div>
                <SectionEyebrow>— CERTIFICATION</SectionEyebrow>
                <h3 className="mt-3 font-heading text-2xl font-semibold text-ink">
                  Certificate and NSTB skill test
                </h3>
                <p className="mt-3 text-[15px] leading-relaxed text-muted">
                  <span className="font-semibold text-ink">{course.nstbLevel}.</span> SkillShikshya
                  Technical is a CTEVT Registered Training Centre (Reg. No. 2018-KTM-0421), so your
                  completion certificate is nationally recognized and verifiable by employers. For
                  foreign employment, this is the credential manpower agencies and visa processes ask
                  for before deployment.
                </p>
                <Link
                  to="/skill-test-and-certification/"
                  className="group mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-brand"
                >
                  How CTEVT & NSTB certification works
                  <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                </Link>
              </div>
            </Reveal>
          </section>

          {/* 9 — FAQ */}
          <section aria-label="Frequently asked questions">
            <Reveal stagger={0.08} y={20}>
              <div>
                <SectionEyebrow>— QUESTIONS</SectionEyebrow>
                <h2 className="mt-3 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[36px]">
                  Frequently asked questions about this course
                </h2>
              </div>
              <FAQAccordion items={course.faqs} defaultOpenFirst />
            </Reveal>
          </section>
        </div>

        {/* 10 — Sticky sidebar (desktop) */}
        <aside className="mt-12 hidden lg:mt-0 lg:block">
          <div className="sticky top-24 space-y-5">
            <div data-side {...fade}>
              <InquiryForm courseSlug={course.slug} compact id="inquiry-form" />
            </div>
            <div data-side {...fade}>
              <BrochureCard course={course} />
            </div>
            <div data-side {...fade}>
              <QuickFactsCard course={course} />
            </div>
          </div>
        </aside>
      </div>

      {/* 11 — Related courses */}
      <section className="bg-mint" aria-label="Related courses">
        <div className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-20">
          <Reveal stagger={0.1} y={24}>
            <div>
              <SectionEyebrow>— KEEP EXPLORING</SectionEyebrow>
              <h2 className="mt-3 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[36px]">
                Related courses
              </h2>
            </div>
          </Reveal>
          <Reveal className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 md:gap-8" stagger={0.1}>
            {related.map((c) => (
              <CourseCard key={c.slug} course={c} />
            ))}
          </Reveal>
        </div>
      </section>
      {/* Pre-footer CTA + Footer rendered by Layout */}
    </div>
  );
}

export default function CourseDetail() {
  const { categorySlug, courseSlug } = useParams<{
    categorySlug: string;
    courseSlug: string;
  }>();
  const course = courses.find((c) => c.slug === courseSlug);
  if (!course) return <CourseNotFound slug={courseSlug} />;
  // Canonical enforcement: wrong/missing category prefix → redirect to nested URL
  if (course.categorySlug !== categorySlug)
    return <Navigate to={coursePath(course)} replace />;
  return <CourseDetailView key={course.slug} course={course} />;
}
