import SEO, { orgJsonLd, localBusinessJsonLd, webSiteJsonLd } from "@/components/SEO";
import Hero from "@/components/home/Hero";
import BatchSection from "@/components/home/BatchSection";
import CategoryTiles from "@/components/home/CategoryTiles";
import SalarySection from "@/components/home/SalarySection";
import WhyUs from "@/components/home/WhyUs";
import Partners from "@/components/home/Partners";
import Quiz from "@/components/home/Quiz";
import Instructors from "@/components/home/Instructors";
import RegistryTeaser from "@/components/home/RegistryTeaser";
import Testimonials from "@/components/home/Testimonials";
import Fees from "@/components/home/Fees";
import ForeignCTA from "@/components/home/ForeignCTA";

export default function Home() {
  return (
    <>
      <SEO
        title="Vocational Training Institute in Kathmandu, Nepal — SkillShikshya Technical | CTEVT & NSTB"
        description="CTEVT-affiliated vocational training institute in Kathmandu: 10 hands-on courses, NSTB skill-test prep, job placement support. Book free career counseling today."
        path="/"
        jsonLd={[orgJsonLd(), localBusinessJsonLd(), webSiteJsonLd()]}
      />
      {/* 1 — Hero */}
      <Hero />
      {/* 2 — Upcoming Batch Dates (dark banner) */}
      <BatchSection />
      {/* 3 — Pick Your Trade Field */}
      <CategoryTiles />
      {/* 4 — What You Can Earn After Training */}
      <SalarySection />
      {/* 5 — Built Around Getting Hired (pinned on desktop) */}
      <WhyUs />
      {/* 6 — Employer & Agency Partners */}
      <Partners />
      {/* 7 — Course-Finder Quiz */}
      <Quiz />
      {/* 8 — Instructors */}
      <Instructors />
      {/* 9 — Verified Graduate Registry (teaser) */}
      <RegistryTeaser />
      {/* 10 — What Our Graduates Say */}
      <Testimonials />
      {/* 11 — Fees & Payment Options */}
      <Fees />
      {/* 12 — Foreign-Employment CTA Banner */}
      <ForeignCTA />
      {/* 13 — Pre-footer CTA + Footer rendered by Layout */}
    </>
  );
}
