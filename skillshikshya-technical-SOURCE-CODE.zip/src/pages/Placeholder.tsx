import { Link } from "react-router";

/** Placeholder page shell — page agents replace these files with full implementations. */
export function Placeholder({ name }: { name: string }) {
  return (
    <div className="mx-auto flex min-h-[50vh] max-w-3xl flex-col items-center justify-center px-5 py-24 text-center">
      <p className="font-mono text-xs uppercase tracking-[0.12em] text-muted">— PLACEHOLDER</p>
      <h1 className="mt-3 font-heading text-4xl font-bold text-forest">{name}</h1>
      <p className="mt-3 text-muted">This page is being built. Head back to the homepage meanwhile.</p>
      <Link to="/" className="mt-6 rounded-xl bg-brand px-6 py-3 font-semibold text-white">
        Go home
      </Link>
    </div>
  );
}
