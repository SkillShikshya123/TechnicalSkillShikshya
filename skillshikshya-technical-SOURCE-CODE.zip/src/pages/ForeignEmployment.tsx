import { useEffect, useRef } from "react";
import { Link } from "react-router";
import { ShieldCheck, Globe2, Plane, FileCheck, Handshake } from "lucide-react";
import SEO, { breadcrumbJsonLd, faqPageJsonLd } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";
import SectionEyebrow from "@/components/SectionEyebrow";
import TrustBadgePill from "@/components/TrustBadgePill";
import CourseCard from "@/components/CourseCard";
import StepCard from "@/components/StepCard";
import FAQAccordion from "@/components/FAQAccordion";
import Reveal from "@/components/Reveal";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";
import { scrollToTarget } from "@/lib/scroll";
import { courseBySlug } from "@/data/courses";

const PAGE_PATH = "/foreign-employment-preparation/";

const FAQS = [
  {
    question: "How do I apply for the NSTB skill test in Nepal?",
    answer:
      "Submit the NSTB application form with your citizenship copy, passport-size photos, and either a training certificate or proof of at least one year of trade experience, plus the exam fee voucher. You can register at the NSTB office or a designated skill test centre — our counseling desk walks you through the paperwork and books you into the next exam session.",
  },
  {
    question: "What is the NSTB skill test fee?",
    answer:
      "NSTB exam fees are set by the board: Rs 500 for Level 1 and Rs 1,200 for Level 2, plus Rs 150 for the certificate and ID card. Concessional rates apply for women, Dalit, Janajati and candidates with disabilities. Our course fees cover your preparation and mock tests separately.",
  },
  {
    question: "Is the NSTB skill test certificate valid for foreign employment?",
    answer:
      "Yes. The NSTB skill test certificate is the government credential foreign employers, manpower agencies and embassy visa officers recognize — and it strengthens your labour permit (shram swikriti) application at the Department of Foreign Employment (DoFE). It is routinely verified for jobs in Qatar, Saudi Arabia, the UAE and Malaysia, and supports Japan SSW, Korea EPS-TOPIK and Israel G2G caregiver applications.",
  },
  {
    question: "How long does the whole process take from enrollment to certificate?",
    answer:
      "Most students complete trade training in 3 months (390 practical hours), then sit the next available NSTB exam session. From your first class to the card in your hand, plan for roughly 4–6 months depending on NSTB exam scheduling — after which GAMCA medical, pre-departure orientation and the DoFE labour permit typically add a few more weeks.",
  },
  {
    question: "Which countries require the NSTB skill test certificate?",
    answer:
      "Gulf states (Qatar, Saudi Arabia, UAE) and Malaysia routinely verify government skill certification during visa processing, and European destinations like Croatia, Romania and Poland increasingly do the same. Japan's SSW pathway and Korea's EPS-TOPIK run their own skill evaluations, and Israel's G2G caregiver program screens candidates — an NSTB Level 1/2 card strengthens every one of these applications.",
  },
  {
    question: "Can I take the skill test without formal training?",
    answer:
      "Yes — through the Recognition of Prior Learning (RPL) route, NSTB allows experienced workers to sit the practical exam directly. However, most first-time candidates benefit from structured preparation: our mock tests mirror the exact assessor format and timing, which significantly raises first-attempt pass rates.",
  },
  {
    question: "Do you help with manpower agency placement after certification?",
    answer:
      "Yes. We work with 30+ employer and manpower partners — including Gulf Manpower Pvt. and the Israel G2G Agency — and connect certified graduates to verified overseas openings in the Gulf, Malaysia, Europe, Israel, Japan and Korea.",
  },
];

const PROCESS_STEPS = [
  {
    number: "01",
    title: "Enroll in Trade Training",
    description: "Complete 390 hours of practical trade training in our Baneshwar workshop labs.",
  },
  {
    number: "02",
    title: "NSTB Skill Test Prep",
    description: "Practice with mock testing formats designed by National Skill Testing Board assessors.",
  },
  {
    number: "03",
    title: "Pass the NSTB Skill Test",
    description: "Earn your Level 1 or Level 2 National Skill Certificate — fees Rs 500 / Rs 1,200.",
  },
  {
    number: "04",
    title: "Labour Permit & Departure",
    description: "Use your certificate for the DoFE labour permit (shram swikriti), GAMCA medical and pre-departure orientation.",
  },
];

const ABROAD_COURSES: { slug: string; tags: string }[] = [
  { slug: "electrician-training", tags: "QATAR · UAE · SAUDI" },
  { slug: "carpentry-training", tags: "QATAR · UAE · CROATIA" },
  { slug: "elderly-caregiver-training", tags: "ISRAEL G2G · JAPAN" },
  { slug: "makeup-beautician-course", tags: "QATAR · UAE · MALAYSIA" },
];

const MARKETS = [
  {
    title: "Gulf States",
    countries: ["Qatar", "Saudi Arabia", "UAE"],
    note: "Highest volume of skilled-trade demand for Nepali workers; NSTB cards verified at visa stage.",
  },
  {
    title: "Malaysia",
    countries: ["Manufacturing & services"],
    note: "Long-standing destination where certified trades command skilled-category wages.",
  },
  {
    title: "Japan & Korea",
    countries: ["Japan SSW", "Korea EPS-TOPIK"],
    note: "Language + skill test pathways; caregiver, hospitality and construction tracks.",
  },
  {
    title: "Israel G2G Caregiver",
    countries: ["Government-to-government"],
    note: "Specialized home-caregiving roles via the Israel G2G program.",
  },
];

const DOCUMENTS = [
  "Citizenship certificate copy and passport-size photos",
  "Training certificate, or proof of 1+ year trade experience for the RPL route",
  "NSTB application form and exam fee voucher (L1 Rs 500 / L2 Rs 1,200)",
  "Valid passport for overseas applications",
  "GAMCA medical report for Gulf destinations",
  "DoFE labour permit (shram swikriti) via the FEIMS portal",
  "Pre-departure orientation certificate before final exit",
];

/* ---------- Section 1 — Kinetic hero ---------- */
function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo("[data-fe-fade]", { opacity: 0 }, { opacity: 1, duration: 0.5, stagger: 0.08 });
        return;
      }
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
      tl.fromTo(
        "[data-word] > span",
        { yPercent: 110 },
        { yPercent: 0, duration: 0.7, stagger: 0.06 },
        0.15,
      )
        .fromTo(
          "[data-hl]",
          { "--hl-scale": 0 },
          { "--hl-scale": 1, duration: 0.5, ease: "power2.out" },
          0.9,
        )
        .fromTo("[data-fe-lead]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5 }, 1.0)
        .fromTo("[data-fe-ctas]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5 }, 1.15)
        .fromTo(
          "[data-fe-pill]",
          { opacity: 0, scale: 0.8 },
          { opacity: 1, scale: 1, duration: 0.4, stagger: 0.07, ease: "back.out(2)" },
          1.2,
        )
        .fromTo(
          "[data-fe-img-panel]",
          { clipPath: "inset(0% 0% 0% 100%)" },
          { clipPath: "inset(0% 0% 0% 0%)", duration: 0.9, ease: "power3.out" },
          0.4,
        );
      // Slow image parallax on scroll
      gsap.to("[data-fe-img]", {
        y: -30,
        ease: "none",
        scrollTrigger: { trigger: el, start: "top top", end: "bottom top", scrub: true },
      });
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  const fade = reduced ? { "data-fe-fade": true } : {};

  const h1 = [
    { w: "NSTB" },
    { w: "Skill", hl: true },
    { w: "Test", hl: true },
    { w: "Training" },
    { w: "for" },
    { w: "Foreign" },
    { w: "Employment" },
  ];

  return (
    <section ref={ref} className="relative overflow-hidden bg-forest bg-stripes" aria-label="Foreign employment preparation">
      <div
        className="pointer-events-none absolute -right-40 -top-40 h-[560px] w-[560px] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(242,169,59,0.08) 0%, transparent 65%)" }}
      />
      <div className="mx-auto max-w-7xl px-5 pb-16 pt-12 md:px-8 md:pb-20 md:pt-16">
        <div className="grid items-center gap-12 lg:grid-cols-[55fr_45fr]">
          <div>
            <Breadcrumbs
              dark
              className={reduced ? undefined : "opacity-0"}
              {...fade}
              items={[{ label: "Home", to: "/" }, { label: "Foreign Employment Preparation" }]}
            />
            <p className="mt-6">
              <SectionEyebrow dark>— WORK ABROAD, CERTIFIED</SectionEyebrow>
            </p>
            <h1 className="mt-5 font-heading text-[34px] font-extrabold leading-[1.1] text-white md:text-[56px] md:leading-[1.05]">
              {h1.map(({ w, hl }, i) => (
                <span key={i} data-word className="mr-[0.28em] inline-block overflow-hidden align-bottom last:mr-0">
                  <span className="inline-block will-change-transform">
                    {hl ? (
                      <span
                        className="hl-underline"
                        data-hl
                        style={{ ["--hl-scale" as never]: reduced ? 1 : 0 }}
                      >
                        {w}
                      </span>
                    ) : (
                      w
                    )}
                  </span>
                </span>
              ))}
            </h1>
            <p data-fe-lead {...fade} className="mt-5 max-w-xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
              Targeting skilled jobs in Qatar, Saudi Arabia, the UAE, Malaysia, Japan (SSW), Korea
              (EPS-TOPIK) or Israel's G2G caregiver program? The NSTB skill test in Nepal turns your
              trade experience into the government skill test certificate for foreign employment that
              employers, manpower agencies and the Department of Foreign Employment (DoFE) ask for.
            </p>
            <div data-fe-ctas {...fade} className="mt-7 flex flex-col gap-4 sm:flex-row">
              <Link
                to="/contact-and-counseling/"
                className="rounded-xl bg-amber px-7 py-3.5 text-center font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
              >
                Book Free Counseling Session
              </Link>
              <button
                onClick={() => scrollToTarget("#abroad-courses")}
                className="rounded-xl border border-white/40 px-7 py-3.5 font-semibold text-white transition-colors hover:border-white hover:bg-white/5"
              >
                See abroad-ready courses
              </button>
            </div>
            <div className="mt-9 flex flex-wrap gap-2.5">
              {[
                { icon: ShieldCheck, label: "NSTB Level 1 & 2 Prep" },
                { icon: Globe2, label: "7+ Destination Countries" },
                { icon: Handshake, label: "G2G & EPS Pathways" },
              ].map((p) => (
                <span key={p.label} data-fe-pill {...fade}>
                  <TrustBadgePill icon={p.icon} label={p.label} dark />
                </span>
              ))}
            </div>
          </div>

          <div data-fe-img-panel {...fade} className="relative overflow-hidden rounded-2xl shadow-lift">
            <div data-fe-img className="h-full w-full scale-110">
              <img
                src="/foreign-employment.webp"
                alt="Nepali skilled worker with toolkit at airport, departing for overseas job"
                className="aspect-[16/10] w-full object-cover"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-forest/50 via-transparent to-transparent" />
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- Section 2 — Scroll-drawn process timeline ---------- */
function ProcessTimeline() {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo(
          "[data-step-card]",
          { opacity: 0 },
          {
            opacity: 1,
            duration: 0.4,
            stagger: 0.1,
            scrollTrigger: { trigger: el, start: "top 80%", once: true },
          },
        );
        return;
      }
      // Center line draws downward on scroll
      gsap.fromTo(
        "[data-tl-line]",
        { scaleY: 0 },
        {
          scaleY: 1,
          ease: "none",
          scrollTrigger: { trigger: el, start: "top 70%", end: "bottom 55%", scrub: true },
        },
      );
      gsap.utils.toArray<HTMLElement>("[data-step-row]").forEach((row, i) => {
        const fromLeft = row.getAttribute("data-side") === "left";
        const isDesktop = window.matchMedia("(min-width: 768px)").matches;
        const dot = row.querySelector("[data-node]");
        const card = row.querySelector("[data-step-card]");
        const num = row.querySelector<HTMLElement>("[data-step-card] span");
        // Card slides in from its side
        gsap.fromTo(
          card,
          { opacity: 0, x: isDesktop ? (fromLeft ? -40 : 40) : 40 },
          {
            opacity: 1,
            x: 0,
            duration: 0.5,
            ease: "power3.out",
            scrollTrigger: { trigger: row, start: "top 80%", once: true },
          },
        );
        // Node dot pops as the line reaches it
        gsap.fromTo(
          dot,
          { scale: 0 },
          {
            scale: 1,
            duration: 0.4,
            ease: "back.out(2.5)",
            scrollTrigger: { trigger: row, start: "top 78%", once: true },
          },
        );
        // Mono number tick 0 → step number
        if (num) {
          const counter = { v: 0 };
          gsap.to(counter, {
            v: i + 1,
            duration: 0.7,
            ease: "power2.out",
            snap: { v: 1 },
            onUpdate: () => {
              num.textContent = String(Math.round(counter.v)).padStart(2, "0");
            },
            scrollTrigger: { trigger: row, start: "top 80%", once: true },
          });
        }
      });
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <div ref={ref} className="relative mt-12">
      {/* Timeline line: left rail on mobile, center on desktop */}
      <div
        data-tl-line
        className="absolute bottom-6 left-[23px] top-6 w-0.5 origin-top bg-amber/70 md:left-1/2 md:-translate-x-1/2"
        aria-hidden="true"
      />
      <div className="space-y-8 md:space-y-0">
        {PROCESS_STEPS.map((s, i) => (
          <div
            key={s.number}
            data-step-row
            data-side={i % 2 === 0 ? "left" : "right"}
            className="relative grid items-center gap-6 py-2 pl-14 md:grid-cols-[1fr_72px_1fr] md:py-7 md:pl-0"
          >
            <div className="absolute left-4 top-1/2 -translate-y-1/2 md:static md:col-start-2 md:row-start-1 md:flex md:translate-y-0 md:justify-center">
              <span data-node className="block h-4 w-4 rounded-full bg-amber ring-4 ring-amber-soft" />
            </div>
            <div data-step-card className={i % 2 === 0 ? "md:col-start-1 md:row-start-1" : "md:col-start-3 md:row-start-1"}>
              <StepCard number={s.number} title={s.title} description={s.description} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Section 3 — Wage count-up card ---------- */
function WageCard() {
  const ref = useRef<HTMLDivElement>(null);
  const numRef = useRef<HTMLSpanElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) return;
      const counter = { v: 0 };
      gsap.to(counter, {
        v: 100,
        duration: 1.6,
        ease: "power2.out",
        onUpdate: () => {
          if (numRef.current) numRef.current.textContent = `50–${Math.round(counter.v)}%`;
        },
        scrollTrigger: { trigger: el, start: "top 82%", once: true },
      });
      gsap.fromTo(
        "[data-wage-glow]",
        { boxShadow: "0 0 0 0 rgba(242,169,59,0)" },
        {
          boxShadow: "0 0 0 6px rgba(242,169,59,0.18)",
          duration: 1.2,
          ease: "power2.out",
          scrollTrigger: { trigger: el, start: "top 82%", once: true },
        },
      );
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <div
      ref={ref}
      data-wage-glow
      className="rounded-2xl bg-forest bg-stripes p-8 text-white shadow-lift"
    >
      <p className="font-heading text-5xl font-bold text-amber md:text-[52px]">
        <span ref={numRef}>50–100%</span>
      </p>
      <p className="mt-1 font-mono text-xs uppercase tracking-[0.12em] text-forest-body">
        higher wages vs. general helper wages
      </p>
      <p className="mt-5 text-[15px] leading-relaxed text-forest-body">
        The NSTB skill test certificate is the primary proof of trade competency recognized by
        foreign governments and manpower companies. Certified workers qualify for higher-tier skilled
        wages — a certified electrician in the Gulf, for example, earns roughly AED 2,500–3,500 a
        month, while uncertified helpers are typically hired at half that rate or less.
      </p>
    </div>
  );
}

/* ---------- Section 4 — Destination tag type-in ---------- */
function TypingTags({ text }: { text: string }) {
  const ref = useRef<HTMLParagraphElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el || reduced) return;
    const chars = el.querySelectorAll("[data-char]");
    const ctx = gsap.context(() => {
      gsap.fromTo(
        chars,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.01,
          stagger: 0.02,
          scrollTrigger: { trigger: el, start: "top 90%", once: true },
        },
      );
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <p ref={ref} className="mt-3 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-brand">
      {text.split("").map((c, i) => (
        <span key={i} data-char className={reduced ? undefined : "opacity-0"}>
          {c}
        </span>
      ))}
    </p>
  );
}

/* ---------- Page ---------- */
export default function ForeignEmployment() {
  return (
    <>
      <SEO
        title="NSTB Skill Test Nepal — Skill Test Certificate for Foreign Employment | SkillShikshya"
        description="NSTB skill test training in Nepal (L1 Rs 500 / L2 Rs 1,200) for the skill test certificate for foreign employment in Qatar, Saudi Arabia, UAE, Malaysia, Japan SSW, Korea EPS & Israel G2G."
        path={PAGE_PATH}
        ogImage="/foreign-employment.webp"
        jsonLd={[
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Foreign Employment Preparation", path: PAGE_PATH },
          ]),
          faqPageJsonLd(FAQS),
        ]}
      />

      {/* 1 — Hero */}
      <Hero />

      {/* 2 — The NSTB Skill Test Process, Step by Step */}
      <section className="bg-white py-16 md:py-24" aria-label="Skill certification process">
        <div className="mx-auto max-w-6xl px-5 md:px-8">
          <Reveal className="max-w-2xl" stagger={0.12}>
            <SectionEyebrow>— THE PROCESS</SectionEyebrow>
            <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
              The NSTB Skill Test Process, Step by Step
            </h2>
            <p className="mt-4 text-[17px] leading-[1.65] text-muted md:text-[19px]">
              From your first workshop session to a government-verified credential — and the DoFE
              labour permit, GAMCA medical and pre-departure orientation that follow.
            </p>
          </Reveal>
          <ProcessTimeline />
        </div>
      </section>

      {/* 3 — Why the NSTB Skill Test Certificate Matters */}
      <section className="bg-mint py-16 md:py-24" aria-label="Why the NSTB certificate matters">
        <div className="mx-auto max-w-6xl px-5 md:px-8">
          <Reveal className="max-w-2xl" stagger={0.12}>
            <SectionEyebrow>— WHY IT MATTERS</SectionEyebrow>
            <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
              Why the NSTB Skill Test Certificate Matters Abroad
            </h2>
          </Reveal>
          <Reveal className="mt-10 grid gap-6 md:grid-cols-2 md:gap-8" stagger={0.15}>
            <WageCard />
            <div className="rounded-2xl border border-border-soft bg-white p-8 shadow-soft">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-mint">
                <FileCheck className="h-6 w-6 text-brand" />
              </div>
              <h3 className="mt-5 font-heading text-[22px] font-semibold text-ink">
                Visa & Embassy Verification
              </h3>
              <p className="mt-3 text-[15px] leading-relaxed text-muted">
                Qatar, Saudi Arabia, the UAE and Malaysia have established visa checks that verify
                skill certification, and European destinations like Romania, Poland and Croatia are
                adopting the same standard. An NSTB Level 1/2 qualification is the fastest way to
                pass them.
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* 4 — Our Abroad-Ready Courses */}
      <section id="abroad-courses" className="bg-white py-16 md:py-24" aria-label="Abroad-ready courses">
        <div className="mx-auto max-w-6xl px-5 md:px-8">
          <Reveal className="max-w-2xl" stagger={0.12}>
            <SectionEyebrow>— ABROAD-READY COURSES</SectionEyebrow>
            <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
              Skill test training mapped to overseas demand
            </h2>
          </Reveal>
          <Reveal className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4 md:gap-8" stagger={0.1}>
            {ABROAD_COURSES.map(({ slug, tags }) => {
              const course = courseBySlug(slug);
              if (!course) return null;
              return (
                <div key={slug} className="flex flex-col">
                  <CourseCard course={course} className="flex-1" />
                  <TypingTags text={tags} />
                </div>
              );
            })}
          </Reveal>
        </div>
      </section>

      {/* 5 — Destination Countries for NSTB-Certified Workers */}
      <section className="bg-mint py-16 md:py-24" aria-label="Destination countries">
        <div className="mx-auto max-w-6xl px-5 md:px-8">
          <Reveal className="max-w-2xl" stagger={0.12}>
            <SectionEyebrow>— DESTINATIONS</SectionEyebrow>
            <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
              Destination Countries for NSTB-Certified Workers
            </h2>
            <p className="mt-4 text-[17px] leading-[1.65] text-muted md:text-[19px]">
              Qatar, Saudi Arabia, the UAE, Malaysia, Japan, Korea and Israel each run their own
              screening — a government skill test certificate clears the common requirement in all of them.
            </p>
          </Reveal>
          <Reveal className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4 md:gap-8" stagger={0.1}>
            {MARKETS.map((m) => (
              <div
                key={m.title}
                className="group rounded-2xl border border-border-soft bg-white p-6 shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift"
              >
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-mint transition-transform duration-500 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:-rotate-[10deg]">
                  <Plane className="h-5 w-5 text-brand" />
                </span>
                <h3 className="mt-4 font-heading text-xl font-semibold text-ink">{m.title}</h3>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {m.countries.map((c, ci) => (
                    <span
                      key={c}
                      className="rounded-full bg-mint px-2.5 py-1 font-mono text-[11px] font-medium uppercase tracking-[0.08em] text-ink transition-colors group-hover:bg-amber-soft"
                      style={{ transitionDelay: `${ci * 90}ms` }}
                    >
                      {c}
                    </span>
                  ))}
                </div>
                <p className="mt-3 text-sm leading-relaxed text-muted">{m.note}</p>
              </div>
            ))}
          </Reveal>
        </div>
      </section>

      {/* 6 — Documents Checklist */}
      <section className="bg-white py-16 md:py-24" aria-label="Documents checklist">
        <div className="mx-auto max-w-6xl px-5 md:px-8">
          <Reveal className="max-w-2xl" stagger={0.12}>
            <SectionEyebrow>— DOCUMENTS CHECKLIST</SectionEyebrow>
            <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
              Documents You Need for the NSTB Skill Test and Departure
            </h2>
            <p className="mt-4 text-[17px] leading-[1.65] text-muted md:text-[19px]">
              Gather these before exam day — our counselors verify every item with you so nothing
              delays your labour permit or flight.
            </p>
          </Reveal>
          <Reveal className="mt-10" stagger={0.08}>
            <ul className="grid gap-4 sm:grid-cols-2">
              {DOCUMENTS.map((d) => (
                <li
                  key={d}
                  className="flex items-start gap-3 rounded-2xl border border-border-soft bg-mint/50 p-5 text-[15px] leading-relaxed text-ink shadow-soft"
                >
                  <FileCheck className="mt-0.5 h-5 w-5 shrink-0 text-brand" />
                  {d}
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </section>

      {/* 7 — FAQ */}
      <section className="bg-mint py-16 md:py-24" aria-label="Foreign employment FAQs">
        <div className="mx-auto max-w-3xl px-5 md:px-8">
          <Reveal className="text-center" stagger={0.12}>
            <SectionEyebrow>— QUESTIONS</SectionEyebrow>
            <h2 className="mt-4 font-heading text-[28px] font-bold leading-[1.15] text-ink md:text-[40px] md:leading-[1.1]">
              NSTB Skill Test & Foreign Employment FAQs
            </h2>
          </Reveal>
          <Reveal className="mt-10" stagger={0.08} y={24}>
            <FAQAccordion items={FAQS} />
          </Reveal>
        </div>
      </section>

      {/* 7 — Pre-footer CTA banner rendered by Layout */}
    </>
  );
}
