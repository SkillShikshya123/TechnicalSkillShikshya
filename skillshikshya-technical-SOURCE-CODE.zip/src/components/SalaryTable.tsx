import { salaryColumns, salaryRows, salaryDisclaimer } from "@/data/salary";
import { cn } from "@/lib/utils";

interface SalaryTableProps {
  className?: string;
  showDisclaimer?: boolean;
}

/** Responsive salary comparison table; stacked cards on mobile (design.md §5.5). */
export default function SalaryTable({ className, showDisclaimer = true }: SalaryTableProps) {
  return (
    <div className={className}>
      {/* Desktop table */}
      <div className="hidden overflow-hidden rounded-2xl border border-border-soft shadow-soft md:block">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-forest">
              <th className="px-5 py-4 font-mono text-xs font-medium uppercase tracking-[0.12em] text-white">
                Trade
              </th>
              {salaryColumns.map((c) => (
                <th key={c.key} className="px-5 py-4 font-mono text-xs font-medium uppercase tracking-[0.12em] text-white">
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {salaryRows.map((row, i) => (
              <tr key={row.trade} className={cn("salary-row", i % 2 === 0 ? "bg-white" : "bg-mint/60")}>
                <td className="px-5 py-4 font-heading text-[15px] font-semibold text-ink">{row.trade}</td>
                {salaryColumns.map((c) => (
                  <td
                    key={c.key}
                    className={cn(
                      "px-5 py-4 text-sm font-medium text-ink/80",
                      row.highlight === c.key && "bg-amber-soft/70 font-semibold text-ink",
                    )}
                  >
                    {row[c.key]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile stacked cards */}
      <div className="space-y-4 md:hidden">
        {salaryRows.map((row) => (
          <div key={row.trade} className="salary-row rounded-2xl border border-border-soft bg-white p-5 shadow-soft">
            <h3 className="font-heading text-lg font-semibold text-ink">{row.trade}</h3>
            <dl className="mt-3 space-y-2">
              {salaryColumns.map((c) => (
                <div
                  key={c.key}
                  className={cn(
                    "flex items-center justify-between rounded-lg px-3 py-2 text-sm",
                    row.highlight === c.key ? "bg-amber-soft/70" : "bg-mint/50",
                  )}
                >
                  <dt className="font-medium text-muted">{c.label}</dt>
                  <dd className="font-semibold text-ink">{row[c.key]}</dd>
                </div>
              ))}
            </dl>
          </div>
        ))}
      </div>

      {showDisclaimer && (
        <p className="mt-4 text-[13px] italic leading-relaxed text-muted">{salaryDisclaimer}</p>
      )}
    </div>
  );
}
