import { cn } from "@/lib/utils";

interface StepCardProps {
  number: string; // "01"
  title: string;
  description: string;
  dark?: boolean;
  className?: string;
}

/** Numbered step card with huge amber digit (design.md §5.5). */
export default function StepCard({ number, title, description, dark, className }: StepCardProps) {
  return (
    <div
      className={cn(
        "rounded-2xl border p-6 md:p-7",
        dark ? "border-white/15 bg-white/5" : "border-border-soft bg-white shadow-soft",
        className,
      )}
    >
      <span className="font-heading text-5xl font-extrabold leading-none text-amber">{number}</span>
      <h3 className={cn("mt-4 font-heading text-xl font-semibold", dark ? "text-white" : "text-ink")}>
        {title}
      </h3>
      <p className={cn("mt-2 text-[15px] leading-relaxed", dark ? "text-forest-body" : "text-muted")}>
        {description}
      </p>
    </div>
  );
}
