import { Link } from "react-router";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

export interface Crumb {
  label: string;
  to?: string;
}

interface BreadcrumbsProps {
  items: Crumb[];
  dark?: boolean;
  className?: string;
}

/** Breadcrumb nav for all subpages (Home / … / Current). */
export default function Breadcrumbs({ items, dark, className }: BreadcrumbsProps) {
  return (
    <nav aria-label="Breadcrumb" className={className}>
      <ol
        className={cn(
          "flex flex-wrap items-center gap-1.5 font-mono text-xs uppercase tracking-[0.08em]",
          dark ? "text-forest-muted" : "text-muted",
        )}
      >
        {items.map((crumb, i) => (
          <li key={i} className="flex items-center gap-1.5">
            {i > 0 && <ChevronRight className="h-3.5 w-3.5 opacity-60" />}
            {crumb.to && i < items.length - 1 ? (
              <Link to={crumb.to} className={cn("transition-colors", dark ? "hover:text-white" : "hover:text-forest")}>
                {crumb.label}
              </Link>
            ) : (
              <span className={cn(dark ? "text-amber" : "text-brand")}>{crumb.label}</span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}
