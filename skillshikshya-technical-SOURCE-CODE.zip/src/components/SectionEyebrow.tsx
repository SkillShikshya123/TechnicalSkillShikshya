import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface SectionEyebrowProps {
  children: React.ReactNode;
  /** Amber on dark sections, muted on light sections. */
  dark?: boolean;
  center?: boolean;
  className?: string;
}

/** IBM Plex Mono eyebrow label — "— LABEL" format (design.md §2). */
export default function SectionEyebrow({ children, dark, center, className }: SectionEyebrowProps) {
  return (
    <motion.p
      className={cn(
        "font-mono text-[12.5px] font-medium uppercase tracking-[0.12em]",
        dark ? "text-amber" : "text-muted",
        center && "text-center",
        className,
      )}
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.6 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
    >
      {children}
    </motion.p>
  );
}
