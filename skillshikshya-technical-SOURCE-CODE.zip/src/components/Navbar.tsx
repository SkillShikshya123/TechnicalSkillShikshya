import { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router";
import { Menu, X, Phone, MessageCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { site } from "@/data/site";
import { cn } from "@/lib/utils";

const links = [
  { to: "/courses/", label: "Courses" },
  { to: "/foreign-employment-preparation/", label: "Foreign Employment" },
  { to: "/skill-test-and-certification/", label: "Certification" },
  { to: "/success-stories/", label: "Success Stories" },
  { to: "/corporate-and-group-training/", label: "Corporate Training" },
  { to: "/about/", label: "About" },
  { to: "/blog/", label: "Blog" },
  { to: "/contact-and-counseling/", label: "Contact" },
];

const drawerLinks = [{ to: "/", label: "Home" }, ...links];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  return (
    <>
      <header
        className={cn(
          "sticky top-0 z-50 border-b border-border-soft bg-white/90 backdrop-blur transition-all duration-300",
          scrolled ? "shadow-soft" : "shadow-none",
        )}
      >
        <div
          className={cn(
            "mx-auto flex max-w-7xl items-center justify-between px-5 transition-all duration-300 md:px-8",
            scrolled ? "h-16" : "h-[72px]",
          )}
        >
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5" aria-label="SkillShikshya Technical home">
            <img src="/logo.svg" alt="" className="h-9 w-9" />
            <span className="leading-tight">
              <span className="block font-heading text-lg font-bold text-forest">
                SkillShikshya<span className="text-amber">.</span>
              </span>
              <span className="block font-mono text-[10px] font-medium uppercase tracking-[0.12em] text-amber">
                Technical
              </span>
            </span>
          </Link>

          {/* Desktop links */}
          <nav className="hidden items-center gap-6 xl:flex" aria-label="Primary">
            {links.slice(0, 6).map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                className={({ isActive }) =>
                  cn(
                    "group relative py-1 text-[15px] font-medium text-ink transition-colors hover:text-forest",
                    isActive && "text-forest",
                  )
                }
              >
                {({ isActive }) => (
                  <>
                    {l.label}
                    <span
                      className={cn(
                        "absolute -bottom-0.5 left-0 h-0.5 w-full origin-left rounded-full bg-amber transition-transform duration-300",
                        isActive ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100",
                      )}
                    />
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          {/* Right actions */}
          <div className="flex items-center gap-4">
            <a
              href={`tel:${site.contact.phoneLandline}`}
              className="hidden items-center gap-2 font-mono text-sm text-muted transition-colors hover:text-forest lg:flex"
            >
              <Phone className="h-4 w-4" />
              {site.contact.phoneLandline}
            </a>
            <Link
              to="/contact-and-counseling/"
              className="hidden rounded-xl bg-brand px-5 py-2.5 text-sm font-semibold text-white shadow-soft transition-all duration-150 hover:scale-[1.02] hover:bg-brand-dark active:scale-[0.98] sm:block"
            >
              Free Counseling
            </Link>
            <button
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-border-soft text-forest xl:hidden"
              onClick={() => setOpen(true)}
              aria-label="Open menu"
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile drawer */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-[60] bg-forest bg-stripes"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            role="dialog"
            aria-modal="true"
          >
            <div className="flex h-full flex-col px-6 py-5">
              <div className="flex items-center justify-between">
                <span className="font-heading text-lg font-bold text-white">
                  SkillShikshya<span className="text-amber">.</span>
                </span>
                <button
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/20 text-white"
                  onClick={() => setOpen(false)}
                  aria-label="Close menu"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <nav className="mt-10 flex flex-1 flex-col gap-1 overflow-y-auto" aria-label="Mobile">
                {drawerLinks.map((l, i) => (
                  <motion.div
                    key={l.to}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.05 * i, duration: 0.3 }}
                  >
                    <NavLink
                      to={l.to}
                      className={({ isActive }) =>
                        cn(
                          "block rounded-xl px-4 py-3 font-heading text-xl font-semibold text-white/90 transition-colors hover:bg-white/5 hover:text-white",
                          isActive && "text-amber",
                        )
                      }
                    >
                      {l.label}
                    </NavLink>
                  </motion.div>
                ))}
              </nav>
              <div className="flex flex-col gap-3 border-t border-white/10 pt-5">
                <Link
                  to="/contact-and-counseling/"
                  className="rounded-xl bg-amber px-5 py-3.5 text-center font-semibold text-forest"
                >
                  Free Counseling
                </Link>
                <a
                  href={site.contact.whatsapp}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-center gap-2 rounded-xl bg-whatsapp px-5 py-3.5 font-semibold text-white"
                >
                  <MessageCircle className="h-5 w-5" />
                  Chat on WhatsApp
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
