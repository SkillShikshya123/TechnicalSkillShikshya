import { cn } from "@/lib/utils";

interface BadgeChipProps {
  label: string;
  /** "solid" = amber bg forest text (on cards); "soft" = amber-soft bg amber-dark text (inline). */
  variant?: "solid" | "soft";
  className?: string;
}

/** Amber badge chip: Popular / Highly Popular / High Demand / Abroad Ready / Israel/Japan Ready. */
export default function BadgeChip({ label, variant = "solid", className }: BadgeChipProps) {
  return (
    <span
      className={cn(
        "inline-block rounded-full px-3 py-1 text-xs font-semibold",
        variant === "solid" ? "bg-amber text-forest" : "bg-amber-soft text-[#9A6714]",
        className,
      )}
    >
      {label}
    </span>
  );
}
