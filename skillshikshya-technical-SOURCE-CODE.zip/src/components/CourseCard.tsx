import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import { coursePath, type Course } from "@/data/courses";
import BadgeChip from "./BadgeChip";
import { cn } from "@/lib/utils";

interface CourseCardProps {
  course: Course;
  className?: string;
}

/** White course card with 4:3 image, badge chip, duration+fee row (design.md §5.5). */
export default function CourseCard({ course, className }: CourseCardProps) {
  return (
    <Link
      to={coursePath(course)}
      className={cn(
        "group flex flex-col overflow-hidden rounded-2xl border border-border-soft bg-white shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift",
        className,
      )}
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-forest">
        <img
          src={course.image}
          alt={course.imageAlt}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-forest/60 via-transparent to-transparent" />
        {course.badge && (
          <div className="absolute right-3 top-3">
            <BadgeChip label={course.badge} />
          </div>
        )}
      </div>
      <div className="flex flex-1 flex-col p-5">
        <p className="font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-muted">
          {course.category}
        </p>
        <h3 className="mt-1.5 font-heading text-xl font-semibold leading-snug text-ink">
          {course.name}
        </h3>
        <p className="mt-2 line-clamp-2 text-sm text-muted">{course.description}</p>
        <div className="mt-4 border-t border-border-soft pt-4">
          <p className="font-mono text-xs font-medium uppercase tracking-wide text-ink">
            {course.duration} · {course.feeLabel}
          </p>
          <span className="mt-2 inline-flex items-center gap-1.5 text-sm font-semibold text-brand">
            View Course Details
            <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
          </span>
        </div>
      </div>
    </Link>
  );
}
