import { useId } from "react";
import { cn } from "@/lib/utils";

interface FormFieldProps {
  label: string;
  type?: "text" | "tel" | "email" | "select" | "textarea";
  placeholder?: string;
  value: string;
  onChange: (value: string) => void;
  options?: { value: string; label: string }[];
  error?: string;
  required?: boolean;
  name?: string;
}

/** Label-above form field with focus ring + error state (design.md §5.5). */
export default function FormField({
  label,
  type = "text",
  placeholder,
  value,
  onChange,
  options,
  error,
  required,
  name,
}: FormFieldProps) {
  const id = useId();
  const baseCls = cn(
    "w-full rounded-xl border bg-white px-4 py-3 text-[15px] text-ink outline-none transition-all placeholder:text-muted/60",
    error
      ? "border-red-400 focus:border-red-500 focus:ring-2 focus:ring-red-200"
      : "border-border-soft focus:border-brand focus:ring-2 focus:ring-brand/25",
  );
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-ink">
        {label}
        {required && <span className="ml-0.5 text-amber">*</span>}
      </label>
      {type === "select" ? (
        <select id={id} name={name} value={value} onChange={(e) => onChange(e.target.value)} className={baseCls}>
          <option value="" disabled>
            {placeholder ?? "Select…"}
          </option>
          {options?.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      ) : type === "textarea" ? (
        <textarea
          id={id}
          name={name}
          rows={4}
          value={value}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
          className={baseCls}
        />
      ) : (
        <input
          id={id}
          name={name}
          type={type}
          value={value}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
          className={baseCls}
        />
      )}
      {error && <p className="mt-1.5 text-xs font-medium text-red-500">{error}</p>}
    </div>
  );
}
