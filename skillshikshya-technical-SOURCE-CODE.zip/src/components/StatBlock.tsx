import { useEffect, useRef, useState } from "react";
import { useInView } from "framer-motion";
import { prefersReducedMotion } from "@/lib/motion";
import { cn } from "@/lib/utils";

interface StatBlockProps {
  value: number;
  suffix?: string;
  label: string;
  dark?: boolean;
  /** Delay before count-up starts (seconds). */
  delay?: number;
  className?: string;
}

/** Big Sora number with count-up + mono label (design.md §5.5). */
export default function StatBlock({ value, suffix = "", label, dark, delay = 0, className }: StatBlockProps) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.6 });
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!inView) return;
    if (prefersReducedMotion()) {
      setDisplay(value);
      return;
    }
    let raf = 0;
    const dur = 1400;
    let start = 0;
    const timer = window.setTimeout(() => {
      const step = (t: number) => {
        if (!start) start = t;
        const p = Math.min(1, (t - start) / dur);
        const eased = 1 - Math.pow(1 - p, 3);
        setDisplay(Math.round(eased * value));
        if (p < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    }, delay * 1000);
    return () => {
      clearTimeout(timer);
      cancelAnimationFrame(raf);
    };
  }, [inView, value, delay]);

  return (
    <div ref={ref} className={cn("text-center md:text-left", className)}>
      <p className={cn("font-heading text-[44px] font-bold leading-none md:text-[52px]", dark ? "text-white" : "text-forest")}>
        {display.toLocaleString("en-US")}
        {suffix}
      </p>
      <p className={cn("mt-2 font-mono text-xs font-medium uppercase tracking-[0.12em]", dark ? "text-forest-muted" : "text-muted")}>
        {label}
      </p>
    </div>
  );
}
