import { Link } from "react-router";
import { Sparkles, Wrench, Coffee, HeartHandshake, ArrowRight } from "lucide-react";
import SectionEyebrow from "@/components/SectionEyebrow";
import Reveal from "@/components/Reveal";
import { categories } from "@/data/categories";

const icons = { Sparkles, Wrench, Coffee, HeartHandshake } as const;

export default function CategoryTiles() {
  return (
    <section className="bg-white" aria-label="Trade fields">
      <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        <div className="text-center">
          <SectionEyebrow center>— WHERE TO START</SectionEyebrow>
          <h2 className="mt-3 font-heading text-3xl font-bold text-ink md:text-[40px]">
            Vocational courses in Nepal — pick your trade field
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-[17px] leading-[1.65] text-muted md:text-[19px]">
            Four career tracks, ten hands-on vocational training programs. Every path ends with a
            CTEVT certificate employers actually recognize — and a route to a job or your own
            business.
          </p>
        </div>
        <Reveal className="mt-10 grid grid-cols-2 gap-6 lg:grid-cols-4" stagger={0.1} y={50}>
          {categories.map((c) => {
            const Icon = icons[c.icon];
            return (
              <Link
                key={c.slug}
                to={`/courses/${c.slug}/`}
                className="group overflow-hidden rounded-2xl border border-border-soft bg-white shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift"
              >
                <div className="relative aspect-[4/3] overflow-hidden bg-forest">
                  <img
                    src={c.image}
                    alt={`${c.name} training tools and environment`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.06]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-forest/70 via-forest/10 to-transparent" />
                </div>
                <div className="p-4 md:p-5">
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-mint text-brand">
                    <Icon className="h-5 w-5" />
                  </span>
                  <h3 className="relative mt-3 inline-block font-heading text-base font-semibold text-ink md:text-lg">
                    {c.name}
                    <span className="absolute -bottom-0.5 left-0 h-0.5 w-full origin-left scale-x-0 rounded-full bg-amber transition-transform duration-300 group-hover:scale-x-100" />
                  </h3>
                  <p className="mt-1 font-mono text-[11px] uppercase tracking-wide text-muted">
                    {c.courseCount} course{c.courseCount > 1 ? "s" : ""} · {c.fromPrice}
                  </p>
                  <p className="mt-2 hidden text-[13px] leading-relaxed text-muted md:block">
                    {c.shortLine}
                  </p>
                  <span className="mt-3 inline-flex items-center gap-1 text-[13px] font-semibold text-brand">
                    Explore
                    <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                  </span>
                </div>
              </Link>
            );
          })}
        </Reveal>
      </div>
    </section>
  );
}
