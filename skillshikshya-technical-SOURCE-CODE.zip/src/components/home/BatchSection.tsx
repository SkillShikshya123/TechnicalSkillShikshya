import { Link } from "react-router";
import SectionEyebrow from "@/components/SectionEyebrow";
import BatchCard from "@/components/BatchCard";
import Reveal from "@/components/Reveal";
import { batches, batchBannerEyebrow } from "@/data/batches";

export default function BatchSection() {
  return (
    <section id="batches" className="bg-forest-deep bg-stripes" aria-label="Upcoming batch dates">
      <div className="mx-auto max-w-6xl px-5 py-14 md:px-8">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div>
            <SectionEyebrow dark>{batchBannerEyebrow}</SectionEyebrow>
            <h2 className="mt-3 font-heading text-3xl font-bold text-white md:text-[40px]">
              Upcoming training batches in Kathmandu — seats fill fast
            </h2>
          </div>
          <Link
            to="/contact-and-counseling/"
            className="inline-block shrink-0 rounded-xl bg-amber px-6 py-3 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
          >
            Reserve Your Seat
          </Link>
        </div>
        <Reveal className="mt-9 grid gap-6 md:grid-cols-3" stagger={0.12}>
          {batches.map((b) => (
            <BatchCard key={b.id} batch={b} />
          ))}
        </Reveal>
      </div>
    </section>
  );
}
