import { useEffect, useLayoutEffect, useRef, useState } from "react";
import SectionEyebrow from "@/components/SectionEyebrow";
import StepCard from "@/components/StepCard";
import Reveal from "@/components/Reveal";
import { gsap, ScrollTrigger, usePrefersReducedMotion } from "@/lib/motion";

const steps = [
  {
    number: "01",
    title: "Active Trade Instructors",
    description: "Learn from currently working electricians, chefs, and beauticians — not retired academics.",
  },
  {
    number: "02",
    title: "80% Practical Labs",
    description: "Real tools, real workshop hours, real café simulators. You practice until it's muscle memory.",
  },
  {
    number: "03",
    title: "NSTB Skill-Test Prep",
    description: "Our TVET-standard curriculum maps directly to the NSTB skill test required for foreign employment visas.",
  },
  {
    number: "04",
    title: "90%+ Placement Rate",
    description: "An employer network of 30+ companies and manpower agencies hiring our graduates.",
  },
];

export default function WhyUs() {
  const sectionRef = useRef<HTMLElement>(null);
  // Lazy-init so the pinned layout exists in the FIRST commit — a false→true
  // flip after mount inserts the pin-spacer late and shifts every anchor target.
  const [isDesktop, setIsDesktop] = useState(
    () => typeof window !== "undefined" && window.matchMedia("(min-width: 1024px)").matches,
  );
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const onChange = () => setIsDesktop(mq.matches);
    onChange();
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  // Pinned scroll sequence (desktop only).
  // MUST be useLayoutEffect: ScrollTrigger pin:true reparents this <section>
  // into a pin-spacer div. Layout-effect cleanup (ctx.revert) runs BEFORE React
  // detaches the DOM on route unmount, restoring the original tree — a passive
  // useEffect cleanup would run too late and crash React with removeChild.
  useLayoutEffect(() => {
    if (!isDesktop || reduced) return;
    const el = sectionRef.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      const cards = gsap.utils.toArray<HTMLElement>("[data-step-card]");
      const progressBar = el.querySelector<HTMLElement>("[data-progress-bar]");
      const progressLabel = el.querySelector<HTMLElement>("[data-progress-label]");
      gsap.set(cards, { opacity: 0, y: 60 });
      gsap.set(cards[0], { opacity: 1, y: 0 });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: el,
          start: "top top",
          end: "+=200%",
          pin: true,
          scrub: 0.6,
          onUpdate: (self) => {
            const idx = Math.min(steps.length - 1, Math.floor(self.progress * steps.length));
            if (progressLabel) progressLabel.textContent = `0${idx + 1} / 04`;
          },
        },
      });
      cards.forEach((card, i) => {
        if (i === 0) return;
        tl.to(cards[i - 1], { opacity: 0, y: -40, duration: 0.5 }, i)
          .to(card, { opacity: 1, y: 0, duration: 0.5 }, i);
      });
      tl.to({}, { duration: 0.6 }); // settle at the end before unpin
      if (progressBar) {
        gsap.to(progressBar, {
          scaleX: 1,
          ease: "none",
          scrollTrigger: { trigger: el, start: "top top", end: "+=200%", scrub: 0.6 },
        });
      }
    }, el);
    return () => ctx.revert();
  }, [isDesktop, reduced]);

  return (
    <section ref={sectionRef} className="bg-white" aria-label="The SkillShikshya way">
      <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        {isDesktop && !reduced ? (
          <div className="grid gap-12 lg:grid-cols-2">
            <div>
              <SectionEyebrow>— THE SKILLSHIKSHYA WAY</SectionEyebrow>
              <h2 className="mt-3 font-heading text-3xl font-bold text-ink md:text-[40px] md:leading-[1.1]">
                Job-oriented training built around getting hired, not just attending class.
              </h2>
              <p className="mt-6 font-mono text-sm text-muted" data-progress-label>
                01 / 04
              </p>
              <div className="mt-3 h-1 w-40 overflow-hidden rounded-full bg-border-soft">
                <div data-progress-bar className="h-full w-full origin-left scale-x-0 rounded-full bg-amber" />
              </div>
            </div>
            <div className="relative min-h-[320px]">
              {steps.map((s) => (
                <div key={s.number} data-step-card className="absolute inset-x-0 top-0">
                  <StepCard number={s.number} title={s.title} description={s.description} />
                </div>
              ))}
            </div>
          </div>
        ) : (
          <>
            <div>
              <SectionEyebrow>— THE SKILLSHIKSHYA WAY</SectionEyebrow>
              <h2 className="mt-3 max-w-xl font-heading text-3xl font-bold text-ink md:text-[40px] md:leading-[1.1]">
                Job-oriented training built around getting hired, not just attending class.
              </h2>
            </div>
            <Reveal className="mt-10 grid gap-6 sm:grid-cols-2" stagger={0.1}>
              {steps.map((s) => (
                <StepCard key={s.number} number={s.number} title={s.title} description={s.description} />
              ))}
            </Reveal>
          </>
        )}
      </div>
    </section>
  );
}

export { ScrollTrigger };
