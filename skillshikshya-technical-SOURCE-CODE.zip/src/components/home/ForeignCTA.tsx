import { useEffect, useRef } from "react";
import { Link } from "react-router";
import SectionEyebrow from "@/components/SectionEyebrow";
import Reveal from "@/components/Reveal";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";

export default function ForeignCTA() {
  const ref = useRef<HTMLElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el || reduced) return;
    const ctx = gsap.context(() => {
      gsap.fromTo(
        "[data-foreign-img]",
        { clipPath: "inset(0 100% 0 0)" },
        {
          clipPath: "inset(0 0% 0 0)",
          duration: 0.9,
          ease: "power3.out",
          scrollTrigger: { trigger: el, start: "top 80%", once: true },
        },
      );
      gsap.to("[data-foreign-img] img", {
        y: -20,
        ease: "none",
        scrollTrigger: { trigger: el, start: "top bottom", end: "bottom top", scrub: true },
      });
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <section ref={ref} className="relative overflow-hidden bg-forest bg-stripes" aria-label="Work abroad">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-5 py-16 md:px-8 md:py-24 lg:grid-cols-2">
        <Reveal y={24} stagger={0.1}>
          <div>
            <SectionEyebrow dark>— WORK ABROAD</SectionEyebrow>
            <h2 className="mt-3 font-heading text-3xl font-bold text-white md:text-[40px] md:leading-[1.1]">
              Planning to work abroad?
            </h2>
            <p className="mt-4 max-w-lg text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
              Get NSTB certified before you apply for skilled jobs in the Gulf, Malaysia, Croatia, or
              Japan. Certified workers earn 50–100% more than helpers.
            </p>
            <div className="mt-8 flex flex-col gap-4 sm:flex-row">
              <Link
                to="/foreign-employment-preparation/"
                className="rounded-xl bg-amber px-7 py-3.5 text-center font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
              >
                See Foreign Employment Prep
              </Link>
              <Link
                to="/contact-and-counseling/"
                className="rounded-xl border border-white/40 px-7 py-3.5 text-center font-semibold text-white transition-colors hover:border-white hover:bg-white/5"
              >
                Talk to a counselor
              </Link>
            </div>
          </div>
        </Reveal>
        <div data-foreign-img className="relative hidden overflow-hidden rounded-2xl lg:block">
          <img
            src="/foreign-employment.webp"
            alt="Nepali skilled worker with toolkit at airport departure, ready for overseas employment"
            loading="lazy"
            className="aspect-video w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-forest/70 via-transparent to-transparent" />
        </div>
      </div>
    </section>
  );
}
