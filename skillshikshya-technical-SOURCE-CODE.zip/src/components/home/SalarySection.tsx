import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import SectionEyebrow from "@/components/SectionEyebrow";
import SalaryTable from "@/components/SalaryTable";
import Reveal from "@/components/Reveal";

export default function SalarySection() {
  return (
    <section className="bg-mint" aria-label="Career outcomes and salaries">
      <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <SectionEyebrow>— CAREER OUTCOMES</SectionEyebrow>
            <h2 className="mt-3 font-heading text-3xl font-bold text-ink md:text-[40px]">
              Salary after vocational training — in Nepal and abroad
            </h2>
            <p className="mt-4 max-w-2xl text-[17px] leading-[1.65] text-muted md:text-[19px]">
              Real salary data from employers and our Batch 2024–2026 graduates — what certified
              tradespeople earn in Nepal and abroad.
            </p>
          </div>
          <Link
            to="/foreign-employment-preparation/"
            className="inline-flex shrink-0 items-center gap-1.5 font-semibold text-brand transition-colors hover:text-brand-dark"
          >
            See foreign employment pathways
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <Reveal className="mt-10" stagger={0} y={24}>
          <SalaryTable />
        </Reveal>
      </div>
    </section>
  );
}
