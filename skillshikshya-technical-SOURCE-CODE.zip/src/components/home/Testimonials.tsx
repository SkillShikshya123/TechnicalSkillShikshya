import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import SectionEyebrow from "@/components/SectionEyebrow";
import Reveal from "@/components/Reveal";
import TestimonialCard from "@/components/TestimonialCard";
import { homeTestimonials } from "@/data/testimonials";

export default function Testimonials() {
  return (
    <section className="bg-mint" aria-label="Graduate testimonials">
      <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <SectionEyebrow>— SUCCESS STORIES</SectionEyebrow>
            <h2 className="mt-3 font-heading text-3xl font-bold text-ink md:text-[40px]">
              What our graduates say
            </h2>
          </div>
          <Link
            to="/success-stories/"
            className="inline-flex shrink-0 items-center gap-1.5 font-semibold text-brand transition-colors hover:text-brand-dark"
          >
            Read all stories
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <Reveal className="mt-10 grid gap-6 md:grid-cols-3" stagger={0.12}>
          {homeTestimonials.map((t) => (
            <TestimonialCard key={t.id} testimonial={t} />
          ))}
        </Reveal>
      </div>
    </section>
  );
}
