import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import { ShieldCheck, Award, Users, CalendarCheck, CheckCircle2, MessageCircle } from "lucide-react";
import TrustBadgePill from "@/components/TrustBadgePill";
import StatBlock from "@/components/StatBlock";
import BadgeChip from "@/components/BadgeChip";
import FormField from "@/components/FormField";
import { gsap, usePrefersReducedMotion } from "@/lib/motion";
import { scrollToTarget } from "@/lib/scroll";
import { site } from "@/data/site";
import { courses } from "@/data/courses";
import { nextBatchLabel } from "@/data/batches";

const H1_WORDS = ["Learn", "a", "skill.", "Get", "certified.", "Get", "hired."];

function CounselingForm() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [course, setCourse] = useState("");
  const [errors, setErrors] = useState<{ name?: string; phone?: string; course?: string }>({});
  const [submitted, setSubmitted] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs: typeof errors = {};
    if (!name.trim()) errs.name = "Please enter your full name";
    if (!/^(9\d{9}|0\d{8,9}|\d{7,10})$/.test(phone.replace(/[\s-]/g, "")))
      errs.phone = "Enter a valid Nepali phone number (e.g. 98XXXXXXXX)";
    if (!course) errs.course = "Please choose a course of interest";
    setErrors(errs);
    if (Object.keys(errs).length === 0) setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="flex flex-col items-center py-8 text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", bounce: 0.5 }}
        >
          <CheckCircle2 className="h-14 w-14 text-brand" />
        </motion.div>
        <h3 className="mt-4 font-heading text-lg font-semibold text-ink">Request received!</h3>
        <p className="mt-2 text-sm text-muted">
          Our counselor will call you within 1 hour on working days.
        </p>
        <a
          href={site.contact.whatsapp}
          target="_blank"
          rel="noreferrer"
          className="mt-5 inline-flex items-center gap-2 rounded-xl bg-whatsapp px-5 py-2.5 text-sm font-semibold text-white"
        >
          <MessageCircle className="h-4 w-4" />
          Chat instantly on WhatsApp
        </a>
      </div>
    );
  }

  return (
    <form onSubmit={submit} noValidate className="mt-5 space-y-4">
      <FormField label="Full name" value={name} onChange={setName} placeholder="Your full name" error={errors.name} required name="name" />
      <FormField label="Phone number" type="tel" value={phone} onChange={setPhone} placeholder="98XXXXXXXX" error={errors.phone} required name="phone" />
      <FormField
        label="Course of interest"
        type="select"
        value={course}
        onChange={setCourse}
        placeholder="Select a course"
        options={[
          ...courses.map((c) => ({ value: c.slug, label: c.name })),
          { value: "not-sure", label: "Not sure yet" },
        ]}
        error={errors.course}
        required
        name="course"
      />
      <button
        type="submit"
        className="w-full rounded-xl bg-amber px-6 py-3.5 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
      >
        Request Free Counseling
      </button>
      <p className="text-center text-xs text-muted">We respond within 1 hour on working days</p>
    </form>
  );
}

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo("[data-hero-fade]", { opacity: 0 }, { opacity: 1, duration: 0.5, stagger: 0.08 });
        return;
      }
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
      tl.fromTo(
        "[data-word] > span",
        { yPercent: 110 },
        { yPercent: 0, duration: 0.7, stagger: 0.06 },
        0.15,
      )
        .fromTo(
          "[data-hl]",
          { "--hl-scale": 0 },
          { "--hl-scale": 1, duration: 0.5, ease: "power2.out" },
          0.9,
        )
        .fromTo("[data-lead]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5 }, 1.0)
        .fromTo("[data-ctas]", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5 }, 1.15)
        .fromTo(
          "[data-pill]",
          { opacity: 0, scale: 0.8 },
          { opacity: 1, scale: 1, duration: 0.4, stagger: 0.07, ease: "back.out(2)" },
          1.2,
        )
        .fromTo(
          "[data-form-card]",
          { opacity: 0, x: 60 },
          { opacity: 1, x: 0, duration: 0.7, ease: "power3.out" },
          0.4,
        )
        .fromTo("[data-accred]", { opacity: 0 }, { opacity: 1, duration: 0.6 }, 1.6);
      // Hero image parallax
      gsap.to("[data-hero-img]", {
        y: -40,
        ease: "none",
        scrollTrigger: { trigger: el, start: "top top", end: "bottom top", scrub: true },
      });
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  return (
    <section
      ref={sectionRef}
      className="relative overflow-hidden bg-forest bg-stripes"
      aria-label="Introduction"
    >
      {/* amber radial glow top-right */}
      <div
        className="pointer-events-none absolute -right-40 -top-40 h-[560px] w-[560px] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(242,169,59,0.08) 0%, transparent 65%)" }}
      />
      <div className="mx-auto max-w-7xl px-5 pb-16 pt-14 md:px-8 md:pt-20">
        <div className="grid items-center gap-12 lg:grid-cols-[55fr_45fr]">
          {/* Left column */}
          <div>
            <div className="flex flex-wrap gap-2.5">
              {[
                { icon: ShieldCheck, label: "CTEVT Affiliated" },
                { icon: Award, label: "NSTB Level 1 & 2" },
                { icon: Users, label: "2,000+ Placed" },
                { icon: CalendarCheck, label: "Since 2018" },
              ].map((p) => (
                <span key={p.label} data-pill className={reduced ? undefined : "opacity-0"} data-hero-fade={reduced ? true : undefined}>
                  <TrustBadgePill icon={p.icon} label={p.label} dark />
                </span>
              ))}
            </div>

            <h1 className="mt-7 font-heading text-[34px] font-extrabold leading-[1.1] text-white md:text-[56px] md:leading-[1.05]">
              {H1_WORDS.map((w, i) => (
                <span key={i} data-word className="mr-[0.28em] inline-block overflow-hidden align-bottom last:mr-0">
                  <span className="inline-block will-change-transform">
                    {w === "hired." ? (
                      <span className="hl-underline text-amber" data-hl style={{ ["--hl-scale" as never]: reduced ? 1 : 0 }}>
                        {w}
                      </span>
                    ) : (
                      w
                    )}
                  </span>
                </span>
              ))}
              <span className="mt-4 block font-heading text-lg font-bold leading-snug text-amber md:text-xl">
                Kathmandu's hands-on vocational training institute — CTEVT affiliated, NSTB skill-test certified.
              </span>
            </h1>

            <p data-lead data-hero-fade={reduced ? true : undefined} className="mt-5 max-w-xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
              A technical training center in Kathmandu for hands-on practical training in electrical
              work, beauty, hospitality and care services — TVET-standard courses with CTEVT &
              NSTB-recognized certification, job placement support, and a 90%+ placement rate since
              2018. From short-term courses after SEE to full trade programs, every path ends in a
              job or your own self-employment.
            </p>

            <div data-ctas data-hero-fade={reduced ? true : undefined} className="mt-7 flex flex-col gap-4 sm:flex-row">
              <button
                onClick={() => scrollToTarget("#course-finder")}
                className="rounded-xl bg-amber px-7 py-3.5 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
              >
                Find your course
              </button>
              <Link
                to="/courses/"
                className="rounded-xl border border-white/40 px-7 py-3.5 text-center font-semibold text-white transition-colors hover:border-white hover:bg-white/5"
              >
                Browse all 10 courses
              </Link>
            </div>

            <div className="mt-10 grid grid-cols-2 gap-6 md:grid-cols-4 md:divide-x md:divide-white/15">
              {site.stats.map((s) => (
                <StatBlock key={s.label} value={s.value} suffix={s.suffix} label={s.label} dark className="md:pl-6 md:first:pl-0" />
              ))}
            </div>
          </div>

          {/* Right column: image panel + counseling card */}
          <div className="relative">
            <div
              data-hero-img
              className="absolute -top-10 right-0 hidden h-[calc(100%+80px)] w-full overflow-hidden rounded-2xl opacity-25 lg:block"
              aria-hidden="true"
            >
              <img
                src="/hero-workshop.webp"
                alt="Students practicing electrical wiring and carpentry in a Kathmandu training workshop"
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-forest via-forest/40 to-transparent" />
            </div>
            <div data-form-card className="relative rounded-2xl bg-white p-7 shadow-lift">
              <BadgeChip label={nextBatchLabel} variant="soft" className="mb-4" />
              <h2 className="font-heading text-xl font-semibold text-ink">Get Free Career Counseling</h2>
              <AnimatePresence mode="wait">
                <CounselingForm key="form" />
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Accreditation strip */}
        <div data-accred className="mt-14 border-t border-white/10 pt-7">
          <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-forest-muted">
            Officially accredited by
          </p>
          <div className="mt-4 flex flex-col gap-5 md:flex-row md:items-center md:gap-0 md:divide-x md:divide-white/15">
            {site.accreditations.map((a) => (
              <div key={a.name} className="md:px-6 md:first:pl-0">
                <p className="font-heading text-base font-semibold text-white">{a.name}</p>
                <p className="text-sm text-forest-muted">{a.descriptor}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
