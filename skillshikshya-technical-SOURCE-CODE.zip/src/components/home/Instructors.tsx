import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import SectionEyebrow from "@/components/SectionEyebrow";
import Reveal from "@/components/Reveal";
import BadgeChip from "@/components/BadgeChip";
import { instructors } from "@/data/instructors";

export default function Instructors() {
  return (
    <section className="bg-white" aria-label="Instructors">
      <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <SectionEyebrow>— LEARN FROM PRACTITIONERS</SectionEyebrow>
            <h2 className="mt-3 font-heading text-3xl font-bold text-ink md:text-[40px]">
              Your instructors — active trade professionals
            </h2>
            <p className="mt-4 max-w-2xl text-[17px] leading-[1.65] text-muted md:text-[19px]">
              Every instructor currently works in their trade. You learn today's tools, today's standards.
            </p>
          </div>
          <Link
            to="/about/"
            className="inline-flex shrink-0 items-center gap-1.5 font-semibold text-brand transition-colors hover:text-brand-dark"
          >
            Meet the full team
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <Reveal className="mt-10 grid gap-6 md:grid-cols-3" stagger={0.12}>
          {instructors.map((t) => (
            <div key={t.id} className="group">
              <div className="relative overflow-hidden rounded-2xl">
                <img
                  src={t.image}
                  alt={`${t.name}, ${t.role} instructor at SkillShikshya Technical`}
                  loading="lazy"
                  className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-forest/90 to-transparent p-4 pt-12">
                  <p className="translate-y-2 text-sm text-forest-body opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                    {t.credential}
                  </p>
                </div>
              </div>
              <div className="mt-4 flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-heading text-lg font-semibold text-ink">{t.name}</h3>
                  <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-amber">
                    {t.role}
                  </p>
                </div>
                <BadgeChip label={`${t.yearsExp} YRS EXP`} variant="soft" />
              </div>
              <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted">{t.bio}</p>
            </div>
          ))}
        </Reveal>
      </div>
    </section>
  );
}
