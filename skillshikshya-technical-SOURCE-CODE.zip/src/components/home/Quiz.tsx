import { useState } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import { Plane, Briefcase, Store, ArrowLeft, ArrowRight, RotateCcw, CheckCircle2 } from "lucide-react";
import SectionEyebrow from "@/components/SectionEyebrow";
import Reveal from "@/components/Reveal";
import BadgeChip from "@/components/BadgeChip";
import { quizQuestions, recommendCourse, quizReason, type QuizAnswers } from "@/data/quiz";
import { coursePath, type Course } from "@/data/courses";

const qIcons = { Plane, Briefcase, Store } as const;

export default function Quiz() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Partial<QuizAnswers>>({});
  const [result, setResult] = useState<Course | null>(null);

  const question = quizQuestions[step];

  const choose = (qid: string, oid: string) => {
    const next = { ...answers, [qid]: oid } as QuizAnswers;
    setAnswers(next);
    if (step < quizQuestions.length - 1) {
      setStep(step + 1);
    } else {
      setResult(recommendCourse(next));
    }
  };

  const reset = () => {
    setStep(0);
    setAnswers({});
    setResult(null);
  };

  return (
    <section id="course-finder" className="bg-mint" aria-label="Course finder quiz">
      <div className="mx-auto max-w-4xl px-5 py-16 md:px-8 md:py-24">
        <div className="text-center">
          <SectionEyebrow center>— FIND YOUR PATH</SectionEyebrow>
          <h2 className="mt-3 font-heading text-3xl font-bold text-ink md:text-[40px]">
            Find the perfect course in 60 seconds
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-[17px] leading-[1.65] text-muted md:text-[19px]">
            Answer 3 quick questions — we'll point you to the trade that fits your goals.
          </p>
        </div>

        <Reveal className="mt-10" y={30} stagger={0}>
          <div className="rounded-2xl bg-white p-6 shadow-soft md:p-8">
            {/* Progress header */}
            <div className="flex items-center justify-between">
              <p className="font-mono text-xs font-medium uppercase tracking-[0.12em] text-muted">
                {result ? "Your recommendation" : `Step ${step + 1} of 3`}
              </p>
              {!result && step > 0 && (
                <button
                  onClick={() => setStep(step - 1)}
                  className="inline-flex items-center gap-1 text-sm font-medium text-brand hover:text-brand-dark"
                >
                  <ArrowLeft className="h-4 w-4" /> Back
                </button>
              )}
            </div>
            <div className="mt-3 flex gap-2">
              {[0, 1, 2].map((i) => (
                <div key={i} className="h-1.5 flex-1 overflow-hidden rounded-full bg-border-soft">
                  <motion.div
                    className="h-full rounded-full bg-amber"
                    initial={false}
                    animate={{ scaleX: result || step >= i ? 1 : 0 }}
                    style={{ originX: 0 }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
              ))}
            </div>

            <div className="mt-7">
              <AnimatePresence mode="wait">
                {result ? (
                  <motion.div
                    key="result"
                    initial={{ opacity: 0, scale: 0.92, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, x: -30 }}
                    transition={{ type: "spring", bounce: 0.35, duration: 0.6 }}
                  >
                    <div className="flex flex-col gap-6 sm:flex-row">
                      <div className="relative w-full shrink-0 overflow-hidden rounded-2xl sm:w-56">
                        <img src={result.image} alt={result.imageAlt} className="aspect-[4/3] h-full w-full object-cover" />
                        {result.badge && (
                          <div className="absolute right-2 top-2">
                            <BadgeChip label={result.badge} />
                          </div>
                        )}
                      </div>
                      <div>
                        <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-muted">
                          {result.category}
                        </p>
                        <h3 className="mt-1 font-heading text-2xl font-semibold text-ink">{result.name}</h3>
                        <p className="mt-2 flex items-start gap-2 text-sm leading-relaxed text-muted">
                          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
                          {quizReason(answers as QuizAnswers, result)}
                        </p>
                        <div className="mt-5 flex flex-col gap-3 sm:flex-row">
                          <Link
                            to={`/courses/${result.categorySlug}/`}
                            className="rounded-xl bg-brand px-6 py-3 text-center text-sm font-semibold text-white transition-colors hover:bg-brand-dark"
                          >
                            Explore {result.category} Courses
                          </Link>
                          <Link
                            to={coursePath(result)}
                            className="rounded-xl border border-brand px-6 py-3 text-center text-sm font-semibold text-brand transition-colors hover:bg-mint"
                          >
                            View {result.name} Course
                          </Link>
                        </div>
                        <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2">
                          <Link
                            to="/contact-and-counseling/"
                            className="group inline-flex items-center gap-1 text-sm font-semibold text-brand hover:text-brand-dark"
                          >
                            Get Free Counseling
                            <ArrowRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-1" />
                          </Link>
                          <button
                            onClick={reset}
                            className="inline-flex items-center gap-1.5 text-sm font-medium text-muted hover:text-ink"
                          >
                            <RotateCcw className="h-3.5 w-3.5" /> Start over
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key={question.id}
                    initial={{ opacity: 0, x: 30 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -30 }}
                    transition={{ duration: 0.25 }}
                  >
                    <h3 className="font-heading text-xl font-semibold text-ink">{question.title}</h3>
                    <div
                      className={
                        question.id === "interest"
                          ? "mt-5 grid gap-3 sm:grid-cols-2"
                          : "mt-5 grid gap-3 sm:grid-cols-3"
                      }
                    >
                      {question.options.map((opt, i) => {
                        const Icon = opt.icon ? qIcons[opt.icon] : null;
                        return (
                          <motion.button
                            key={opt.id}
                            initial={{ opacity: 0, x: 30 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.07 * i, duration: 0.3 }}
                            whileTap={{ scale: 0.97 }}
                            onClick={() => choose(question.id, opt.id)}
                            className="flex flex-col items-start gap-2 rounded-2xl border border-border-soft bg-white p-4 text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-brand hover:shadow-soft"
                          >
                            {Icon && (
                              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-mint text-brand">
                                <Icon className="h-5 w-5" />
                              </span>
                            )}
                            <span className="text-[15px] font-semibold text-ink">{opt.label}</span>
                          </motion.button>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
