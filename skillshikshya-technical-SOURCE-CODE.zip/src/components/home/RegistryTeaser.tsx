import { useState } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, AlertCircle, ArrowRight } from "lucide-react";
import SectionEyebrow from "@/components/SectionEyebrow";
import Reveal from "@/components/Reveal";
import { lookupGraduate, graduates, type GraduateRecord } from "@/data/registry";

/** Shared registry lookup card — identical logic used on /graduate-registry/ (home.md §9). */
export function RegistryLookup() {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState<GraduateRecord | null | "not-found">(null);

  const verify = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!query.trim()) return;
    setResult(lookupGraduate(query) ?? "not-found");
  };

  return (
    <div className="rounded-2xl bg-white p-6 shadow-lift">
      <form onSubmit={verify}>
        <label htmlFor="cert-id" className="mb-1.5 block text-sm font-medium text-ink">
          Certificate ID
        </label>
        <div className="flex gap-3">
          <input
            id="cert-id"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g. SS-2026-001"
            className="w-full rounded-xl border border-border-soft bg-white px-4 py-3 font-mono text-[15px] text-ink outline-none transition-all placeholder:text-muted/60 focus:border-brand focus:ring-2 focus:ring-brand/25"
          />
          <button
            type="submit"
            className="shrink-0 rounded-xl bg-brand px-6 py-3 font-semibold text-white transition-colors hover:bg-brand-dark"
          >
            Verify
          </button>
        </div>
      </form>
      <div className="mt-3 flex flex-wrap gap-2">
        {graduates.slice(0, 2).map((g) => (
          <button
            key={g.certificateId}
            onClick={() => setQuery(g.certificateId)}
            className="rounded-full border border-border-soft bg-mint px-3 py-1 font-mono text-xs text-ink transition-colors hover:border-brand/50"
          >
            {g.certificateId}
          </button>
        ))}
      </div>

      <AnimatePresence>
        {result && (
          <motion.div
            key={result === "not-found" ? "nf" : result.certificateId}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ type: "spring", bounce: 0.3, duration: 0.5 }}
            className="mt-5"
          >
            {result === "not-found" ? (
              <div className="flex items-start gap-3 rounded-xl bg-amber-soft p-4">
                <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-[#9A6714]" />
                <p className="text-sm text-ink">
                  Certificate not found — double-check the ID or contact our office.
                </p>
              </div>
            ) : (
              <div className="rounded-xl border border-brand/25 bg-mint p-4">
                <p className="flex items-center gap-2 text-sm font-semibold text-brand">
                  <CheckCircle2 className="h-5 w-5" />
                  {result.status}
                </p>
                <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                  <dt className="text-muted">Name</dt>
                  <dd className="font-semibold text-ink">{result.name}</dd>
                  <dt className="text-muted">Trade</dt>
                  <dd className="font-semibold text-ink">{result.trade}</dd>
                  <dt className="text-muted">NSTB Level</dt>
                  <dd className="font-semibold text-ink">{result.nstbLevel}</dd>
                  <dt className="text-muted">Placement</dt>
                  <dd className="font-semibold text-ink">{result.placement}</dd>
                </dl>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function RegistryTeaser() {
  return (
    <section className="bg-forest bg-stripes" aria-label="Verified graduate registry">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-16 md:px-8 md:py-24 lg:grid-cols-2">
        <Reveal y={24} stagger={0.1}>
          <div>
            <SectionEyebrow dark>— TRUST, VERIFIED</SectionEyebrow>
            <h2 className="mt-3 font-heading text-3xl font-bold text-white md:text-[40px] md:leading-[1.1]">
              Check a graduate's certificate in seconds
            </h2>
            <p className="mt-4 max-w-lg text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
              Employers and manpower agencies can verify any SkillShikshya graduate by certificate ID.
            </p>
            <Link
              to="/graduate-registry/"
              className="mt-6 inline-flex items-center gap-1.5 font-semibold text-white transition-colors hover:text-amber"
            >
              Open the full registry
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
        <Reveal y={0} stagger={0}>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <RegistryLookup />
          </motion.div>
        </Reveal>
      </div>
    </section>
  );
}
