import { useState } from "react";
import { motion } from "framer-motion";
import Reveal from "@/components/Reveal";
import { site } from "@/data/site";
import { usePrefersReducedMotion } from "@/lib/motion";

export default function Partners() {
  const reduced = usePrefersReducedMotion();
  const [paused, setPaused] = useState(false);
  const row = [...site.partners, ...site.partners];

  return (
    <section className="border-y border-border-soft bg-white" aria-label="Employer and agency partners">
      <div className="mx-auto max-w-6xl overflow-hidden px-5 py-12 md:px-8">
        <p className="text-center font-mono text-xs font-medium uppercase tracking-[0.12em] text-muted">
          Employer & Agency Partners
        </p>
        {reduced ? (
          <Reveal className="mt-7 flex flex-wrap items-center justify-center gap-4" stagger={0.06} y={16}>
            {site.partners.map((p) => (
              <PartnerPill key={p.name} name={p.name} note={p.note} />
            ))}
          </Reveal>
        ) : (
          <div
            className="group relative mt-7"
            onMouseEnter={() => setPaused(true)}
            onMouseLeave={() => setPaused(false)}
          >
            <motion.div
              className="flex w-max items-center gap-4"
              animate={{ x: paused ? undefined : ["0%", "-50%"] }}
              transition={paused ? {} : { duration: 20, repeat: Infinity, ease: "linear" }}
            >
              {row.map((p, i) => (
                <PartnerPill key={`${p.name}-${i}`} name={p.name} note={p.note} />
              ))}
            </motion.div>
          </div>
        )}
      </div>
    </section>
  );
}

function PartnerPill({ name, note }: { name: string; note: string }) {
  const [showTip, setShowTip] = useState(false);
  return (
    <div
      className="relative shrink-0"
      onMouseEnter={() => setShowTip(true)}
      onMouseLeave={() => setShowTip(false)}
    >
      <span className="flex items-center gap-2.5 rounded-full border border-border-soft bg-white px-5 py-2.5 font-heading text-[15px] font-semibold text-forest shadow-soft">
        <span className="h-2 w-2 rounded-full bg-amber" />
        {name}
      </span>
      {showTip && (
        <motion.span
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.15 }}
          className="absolute -top-11 left-1/2 z-10 w-max -translate-x-1/2 rounded-lg bg-forest px-3 py-1.5 text-xs text-white shadow-lift"
        >
          {note}
        </motion.span>
      )}
    </div>
  );
}
