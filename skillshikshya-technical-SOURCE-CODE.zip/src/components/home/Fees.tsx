import { Link } from "react-router";
import { CheckCircle2 } from "lucide-react";
import SectionEyebrow from "@/components/SectionEyebrow";
import Reveal from "@/components/Reveal";
import BadgeChip from "@/components/BadgeChip";
import { cn } from "@/lib/utils";

const plans = [
  {
    name: "Full Upfront Payment",
    chip: "5% OFF",
    description: "Pay once and save. Covers all lab materials and your certification exam fee.",
    points: ["5% discount", "All materials included", "Priority seat booking"],
    featured: false,
  },
  {
    name: "50/50 Installment",
    chip: "MOST POPULAR",
    description: "Pay 50% at enrollment, 50% after week 4.",
    points: ["No interest", "No paperwork", "No credit check"],
    featured: true,
  },
  {
    name: "Scholarship / Waiver",
    chip: "UP TO FREE",
    description: "Government-sponsored or NGO-matched training slots.",
    points: ["Income assessment required", "Limited seats per batch", "Ask our counselors"],
    featured: false,
  },
];

export default function Fees() {
  return (
    <section id="fees" className="bg-white" aria-label="Fees and payment options">
      <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        <div className="text-center">
          <SectionEyebrow center>— FEES & PAYMENT</SectionEyebrow>
          <h2 className="mt-3 font-heading text-3xl font-bold text-ink md:text-[40px]">
            Course fees & payment options that don't block your future
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-[17px] leading-[1.65] text-muted md:text-[19px]">
            Transparent course fees, flexible installment plans, and sponsored seats for those who
            qualify — no hidden charges, ever.
          </p>
        </div>
        <Reveal className="mt-10 grid gap-6 md:grid-cols-3 md:items-stretch" stagger={0.1}>
          {plans.map((p) => (
            <div
              key={p.name}
              className={cn(
                "flex flex-col rounded-2xl border p-6 md:p-7",
                p.featured
                  ? "border-brand bg-white shadow-lift md:-my-2 md:scale-[1.02]"
                  : "border-border-soft bg-white shadow-soft",
              )}
            >
              <BadgeChip label={p.chip} variant="soft" className="self-start" />
              <h3 className="mt-4 font-heading text-xl font-semibold text-ink">{p.name}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{p.description}</p>
              <ul className="mt-5 flex-1 space-y-2.5">
                {p.points.map((pt) => (
                  <li key={pt} className="flex items-center gap-2.5 text-sm font-medium text-ink">
                    <CheckCircle2 className="h-5 w-5 shrink-0 text-brand" />
                    {pt}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </Reveal>
        <p className="mt-8 text-center text-sm text-muted">
          Course fees from Rs 8,000–25,000 —{" "}
          <Link to="/courses/" className="font-semibold text-brand hover:text-brand-dark">
            see individual course pages →
          </Link>
        </p>
      </div>
    </section>
  );
}
