import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

export interface FAQItem {
  question: string;
  answer: string;
}

interface FAQAccordionProps {
  items: FAQItem[];
  /** First item open by default (design.md §4). */
  defaultOpenFirst?: boolean;
  className?: string;
}

/** FAQ accordion — fully rendered in DOM for SEO crawlability. */
export default function FAQAccordion({ items, defaultOpenFirst = true, className }: FAQAccordionProps) {
  const [openIdx, setOpenIdx] = useState<number | null>(defaultOpenFirst ? 0 : null);

  return (
    <div className={cn("space-y-3", className)}>
      {items.map((item, i) => {
        const open = openIdx === i;
        return (
          <div key={i} className="overflow-hidden rounded-2xl border border-border-soft bg-white">
            <button
              className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
              onClick={() => setOpenIdx(open ? null : i)}
              aria-expanded={open}
            >
              <span className="font-sans text-base font-semibold text-ink">{item.question}</span>
              <ChevronDown
                className={cn("h-5 w-5 shrink-0 text-brand transition-transform duration-300", open && "rotate-180")}
              />
            </button>
            <AnimatePresence initial={false}>
              {open && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                >
                  <p className="px-5 pb-5 text-[15px] leading-relaxed text-muted">{item.answer}</p>
                </motion.div>
              )}
            </AnimatePresence>
            {/* SEO-crawlable answer (always in DOM for crawlers, visually hidden when closed) */}
            {!open && <p className="sr-only">{item.answer}</p>}
          </div>
        );
      })}
    </div>
  );
}
