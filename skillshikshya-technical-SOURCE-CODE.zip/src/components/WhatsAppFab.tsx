import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { site } from "@/data/site";
import { usePrefersReducedMotion } from "@/lib/motion";

export default function WhatsAppFab() {
  const [show, setShow] = useState(false);
  const [hover, setHover] = useState(false);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const t = setTimeout(() => setShow(true), 1200);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3">
      {hover && (
        <motion.div
          initial={{ opacity: 0, x: 12 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.2 }}
          className="rounded-xl bg-forest px-4 py-2.5 text-sm font-medium text-white shadow-lift"
        >
          Chat with us — replies within minutes
        </motion.div>
      )}
      <motion.a
        href={site.contact.whatsapp}
        target="_blank"
        rel="noreferrer"
        aria-label="Chat with SkillShikshya on WhatsApp"
        className="relative flex h-14 w-14 items-center justify-center rounded-full bg-whatsapp text-white shadow-glow"
        initial={false}
        animate={show ? { scale: 1 } : { scale: 0 }}
        transition={reduced ? { duration: 0.15 } : { type: "spring", bounce: 0.5 }}
        onHoverStart={() => setHover(true)}
        onHoverEnd={() => setHover(false)}
        whileHover={{ scale: 1.06 }}
        whileTap={{ scale: 0.95 }}
      >
        {!reduced && (
          <motion.span
            className="absolute inset-0 rounded-full border-2 border-whatsapp"
            animate={{ scale: [1, 1.35], opacity: [0.7, 0] }}
            transition={{ duration: 1.4, repeat: Infinity, repeatDelay: 3.6, ease: "easeOut" }}
          />
        )}
        <MessageCircle className="h-7 w-7" fill="currentColor" />
      </motion.a>
    </div>
  );
}
