import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface TrustBadgePillProps {
  icon: LucideIcon;
  label: string;
  /** Mint-on-dark variant for heroes (design.md home §1). */
  dark?: boolean;
  className?: string;
}

/** Rounded trust pill: icon + label. Light = mint surface; dark = glass on forest. */
export default function TrustBadgePill({ icon: Icon, label, dark, className }: TrustBadgePillProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-all duration-200 hover:-translate-y-0.5",
        dark
          ? "border border-white/20 bg-white/5 text-white hover:border-white/40"
          : "border border-brand/25 bg-mint text-ink hover:border-brand/50",
        className,
      )}
    >
      <Icon className={cn("h-4 w-4", dark ? "text-amber" : "text-brand")} />
      {label}
    </span>
  );
}
