import { Link } from "react-router";
import { MapPin, Phone, Mail, Clock, MessageCircle } from "lucide-react";
import { site } from "@/data/site";
import { categories } from "@/data/categories";

export default function Footer() {
  return (
    <footer className="bg-forest bg-stripes text-forest-body">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 md:grid-cols-2 md:px-8 lg:grid-cols-4">
        {/* Brand */}
        <div>
          <div className="flex items-center gap-2.5">
            <img src="/logo.svg" alt="" className="h-9 w-9" />
            <span className="leading-tight">
              <span className="block font-heading text-lg font-bold text-white">
                SkillShikshya<span className="text-amber">.</span>
              </span>
              <span className="block font-mono text-[10px] font-medium uppercase tracking-[0.12em] text-amber">
                Technical
              </span>
            </span>
          </div>
          <p className="mt-4 text-sm leading-relaxed">{site.description}</p>
          <p className="mt-4 font-mono text-[11px] uppercase tracking-[0.12em] text-forest-muted">
            {site.registration}
          </p>
        </div>

        {/* Course categories */}
        <nav aria-label="Course categories">
          <h3 className="font-mono text-xs font-medium uppercase tracking-[0.12em] text-amber">
            Course Categories
          </h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            {categories.map((c) => (
              <li key={c.slug}>
                <Link to={`/courses/${c.slug}/`} className="transition-colors hover:text-white">
                  {c.name}
                </Link>
              </li>
            ))}
            <li>
              <Link to="/courses/" className="font-semibold text-white transition-colors hover:text-amber">
                All 10 Courses →
              </Link>
            </li>
          </ul>
        </nav>

        {/* Institute */}
        <nav aria-label="Institute">
          <h3 className="font-mono text-xs font-medium uppercase tracking-[0.12em] text-amber">
            Institute
          </h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            <li><Link to="/about/" className="transition-colors hover:text-white">About</Link></li>
            <li><Link to="/success-stories/" className="transition-colors hover:text-white">Success Stories</Link></li>
            <li><Link to="/graduate-registry/" className="transition-colors hover:text-white">Graduate Registry</Link></li>
            <li><Link to="/corporate-and-group-training/" className="transition-colors hover:text-white">Corporate Training</Link></li>
            <li><Link to="/skill-test-and-certification/" className="transition-colors hover:text-white">Certification Guide</Link></li>
            <li><Link to="/blog/" className="transition-colors hover:text-white">Blog</Link></li>
            <li><Link to="/contact-and-counseling/" className="transition-colors hover:text-white">Contact & Counseling</Link></li>
          </ul>
        </nav>

        {/* Contact */}
        <div>
          <h3 className="font-mono text-xs font-medium uppercase tracking-[0.12em] text-amber">
            Contact
          </h3>
          <ul className="mt-4 space-y-3 text-sm">
            <li className="flex items-start gap-2.5">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-amber" />
              {site.contact.address}
            </li>
            <li className="flex items-center gap-2.5">
              <Phone className="h-4 w-4 shrink-0 text-amber" />
              <a href={`tel:${site.contact.phoneLandline}`} className="hover:text-white">
                {site.contact.phoneLandline}
              </a>
              <span>/</span>
              <a href={`tel:${site.contact.phoneMobile}`} className="hover:text-white">
                {site.contact.phoneMobile}
              </a>
            </li>
            <li className="flex items-center gap-2.5">
              <Mail className="h-4 w-4 shrink-0 text-amber" />
              <a href={`mailto:${site.contact.email}`} className="hover:text-white">
                {site.contact.email}
              </a>
            </li>
            <li className="flex items-center gap-2.5">
              <Clock className="h-4 w-4 shrink-0 text-amber" />
              {site.contact.hours}
            </li>
          </ul>
          <a
            href={site.contact.whatsapp}
            target="_blank"
            rel="noreferrer"
            className="mt-5 inline-flex items-center gap-2 rounded-xl bg-whatsapp px-4 py-2.5 text-sm font-semibold text-white transition-transform hover:scale-[1.02]"
          >
            <MessageCircle className="h-4 w-4" />
            Chat on WhatsApp
          </a>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-5 py-5 text-xs text-forest-muted md:flex-row md:px-8">
          <p>© 2026 SkillShikshya Technical · New Baneshwar, Kathmandu</p>
          <div className="flex gap-5">
            <Link to="/about/" className="hover:text-white">Privacy</Link>
            <Link to="/courses/" className="hover:text-white">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
