import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, MessageCircle, ArrowRight, ArrowLeft } from "lucide-react";
import FormField from "@/components/FormField";
import { courses } from "@/data/courses";
import { batches } from "@/data/batches";
import { site } from "@/data/site";
import { cn } from "@/lib/utils";

/** Nepali-tolerant phone: 98XXXXXXXX, +977 98XXXXXXXX, landline 01-XXXXXXX. */
const PHONE_RE = /^(?:\+?977[-\s]?)?(9\d{9}|0?1\d{7}|\d{7,10})$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export interface InquiryData {
  name: string;
  phone: string;
  email: string;
  courseSlug: string;
  batchId: string;
  contactTime: "morning" | "day" | "evening" | "";
}

interface InquiryFormProps {
  courseSlug?: string;
  compact?: boolean;
  id?: string;
}

const STEP_TITLES = ["Your contact details", "Course interest", "Batch & contact time"];
const CONTACT_TIMES = [
  { value: "morning", label: "Morning (8–11am)" },
  { value: "day", label: "Day (11am–3pm)" },
  { value: "evening", label: "Evening (3–6pm)" },
] as const;

/**
 * Lincoln Tech-style multi-step inquiry form — one question group per step to
 * reduce abandonment vs a single long form. Frontend-only for now: swap the
 * body of `onSubmit` for a fetch() call when the backend lands.
 */
export default function InquiryForm({ courseSlug, compact = false, id }: InquiryFormProps) {
  const [step, setStep] = useState(0);
  const [direction, setDirection] = useState(1);
  const [data, setData] = useState<InquiryData>({
    name: "",
    phone: "",
    email: "",
    courseSlug: courseSlug ?? "",
    batchId: "",
    contactTime: "",
  });
  const [errors, setErrors] = useState<Partial<Record<keyof InquiryData, string>>>({});
  const [submitted, setSubmitted] = useState(false);

  const course = courses.find((c) => c.slug === (data.courseSlug || courseSlug));

  const set = <K extends keyof InquiryData>(key: K, value: InquiryData[K]) => {
    setData((d) => ({ ...d, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  };

  /** Single submit handler — drop a fetch() in here when the API is ready. */
  const onSubmit = async (payload: InquiryData) => {
    // TODO(backend): await fetch("/api/inquiries", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    void payload;
    setSubmitted(true);
  };

  const availableBatches = useMemo(
    () => batches.filter((b) => b.courseSlug === data.courseSlug),
    [data.courseSlug],
  );

  const validateStep = (s: number): boolean => {
    const errs: typeof errors = {};
    if (s === 0) {
      if (!data.name.trim()) errs.name = "Please enter your full name";
      if (!PHONE_RE.test(data.phone.replace(/[\s-]/g, "")))
        errs.phone = "Enter a valid Nepali phone number (e.g. 98XXXXXXXX)";
      if (data.email.trim() && !EMAIL_RE.test(data.email.trim()))
        errs.email = "Enter a valid email address";
    } else if (s === 1) {
      if (!data.courseSlug) errs.courseSlug = "Please choose a course";
    } else {
      if (!data.batchId) errs.batchId = "Please choose a preferred batch";
      if (!data.contactTime) errs.contactTime = "When should we call you?";
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const next = () => {
    if (!validateStep(step)) return;
    setDirection(1);
    setStep((s) => Math.min(s + 1, 2));
  };
  const back = () => {
    setDirection(-1);
    setStep((s) => Math.max(s - 1, 0));
  };
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateStep(2)) void onSubmit(data);
  };

  const whatsappUrl = `https://wa.me/${site.contact.whatsappNumber}?text=${encodeURIComponent(
    `Hi SkillShikshya! I'm ${data.name || "a prospective student"} — I just submitted an inquiry about the ${course?.name ?? "course"} course. Please call me back.`,
  )}`;

  const batchOptions =
    availableBatches.length > 0
      ? availableBatches.map((b) => ({
          value: b.id,
          label: `${b.startLabel} · ${b.note} (${b.seatsLeft} seats left)`,
        }))
      : [
          {
            value: "next-intake",
            label: "Next monthly intake — we'll confirm the exact date",
          },
        ];

  return (
    <div
      id={id}
      className={cn(
        "scroll-mt-24 rounded-2xl border border-border-soft bg-white shadow-soft",
        compact ? "p-5" : "p-6 md:p-8",
      )}
    >
      <h3 className={cn("font-heading font-semibold text-ink", compact ? "text-lg" : "text-xl")}>
        Ask about this course
      </h3>
      {course && (
        <p className="mt-1 font-mono text-[11px] uppercase tracking-[0.1em] text-muted">
          {course.name} · {course.duration}
        </p>
      )}

      {submitted ? (
        <div className="flex flex-col items-center py-8 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", bounce: 0.5 }}
          >
            <CheckCircle2 className="h-14 w-14 text-brand" />
          </motion.div>
          <h4 className="mt-4 font-heading text-base font-semibold text-ink">
            Thank you — request received!
          </h4>
          <p className="mt-2 max-w-xs text-sm text-muted">
            A counselor will call you within 24 hours{data.contactTime ? ` (${data.contactTime})` : ""}.
          </p>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noreferrer"
            className="mt-5 inline-flex items-center gap-2 rounded-xl bg-whatsapp px-5 py-2.5 text-sm font-semibold text-white transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
          >
            <MessageCircle className="h-4 w-4" />
            Chat instantly on WhatsApp
          </a>
        </div>
      ) : (
        <form onSubmit={submit} noValidate className="mt-5">
          {/* Progress indicator */}
          <div className="mb-5">
            <div className="flex items-center justify-between">
              <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-muted">
                Step {step + 1} of 3
              </p>
              <p className="text-xs font-medium text-ink">{STEP_TITLES[step]}</p>
            </div>
            <div
              className="mt-2 h-1.5 overflow-hidden rounded-full bg-amber-soft"
              role="progressbar"
              aria-valuenow={step + 1}
              aria-valuemin={1}
              aria-valuemax={3}
            >
              <motion.div
                className="h-full rounded-full bg-amber"
                initial={false}
                animate={{ width: `${((step + 1) / 3) * 100}%` }}
                transition={{ duration: 0.35, ease: "easeOut" }}
              />
            </div>
          </div>

          {/* Animated step panels */}
          <AnimatePresence mode="wait" initial={false} custom={direction}>
            <motion.div
              key={step}
              custom={direction}
              initial={{ opacity: 0, x: 20 * direction }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 * direction }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className={cn("space-y-4", compact && "space-y-3.5")}
            >
              {step === 0 && (
                <>
                  <FormField
                    label="Full name"
                    name="name"
                    value={data.name}
                    onChange={(v) => set("name", v)}
                    placeholder="Your full name"
                    error={errors.name}
                    required
                  />
                  <FormField
                    label="Phone number"
                    type="tel"
                    name="phone"
                    value={data.phone}
                    onChange={(v) => set("phone", v)}
                    placeholder="98XXXXXXXX or +977 98XXXXXXXX"
                    error={errors.phone}
                    required
                  />
                  <FormField
                    label="Email (optional)"
                    type="email"
                    name="email"
                    value={data.email}
                    onChange={(v) => set("email", v)}
                    placeholder="you@email.com"
                    error={errors.email}
                  />
                </>
              )}

              {step === 1 && (
                <FormField
                  label="Which course are you interested in?"
                  type="select"
                  name="course"
                  value={data.courseSlug}
                  onChange={(v) => {
                    set("courseSlug", v);
                    set("batchId", "");
                  }}
                  placeholder="Select a course"
                  options={courses.map((c) => ({ value: c.slug, label: `${c.name} (${c.duration})` }))}
                  error={errors.courseSlug}
                  required
                />
              )}

              {step === 2 && (
                <>
                  <FormField
                    label="Preferred batch"
                    type="select"
                    name="batch"
                    value={data.batchId}
                    onChange={(v) => set("batchId", v)}
                    placeholder="Select a batch"
                    options={batchOptions}
                    error={errors.batchId}
                    required
                  />
                  <fieldset>
                    <legend className="mb-1.5 block text-sm font-medium text-ink">
                      Best time to call you<span className="ml-0.5 text-amber">*</span>
                    </legend>
                    <div className="flex flex-wrap gap-2">
                      {CONTACT_TIMES.map((t) => (
                        <button
                          key={t.value}
                          type="button"
                          onClick={() => set("contactTime", t.value)}
                          aria-pressed={data.contactTime === t.value}
                          className={cn(
                            "rounded-full border px-4 py-2 text-sm font-medium transition-colors duration-200",
                            data.contactTime === t.value
                              ? "border-brand bg-brand text-white"
                              : "border-border-soft bg-white text-ink hover:border-brand/50",
                          )}
                        >
                          {t.label}
                        </button>
                      ))}
                    </div>
                    {errors.contactTime && (
                      <p className="mt-1.5 text-xs font-medium text-red-500">{errors.contactTime}</p>
                    )}
                  </fieldset>
                </>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Back / Next / Submit */}
          <div className={cn("mt-6 flex gap-3", step === 0 && "flex-col")}>
            {step > 0 && (
              <button
                type="button"
                onClick={back}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-border-soft px-6 py-3 font-semibold text-ink transition-colors hover:border-brand/50"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </button>
            )}
            {step < 2 ? (
              <button
                type="button"
                onClick={next}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-brand px-6 py-3.5 font-semibold text-white transition-all duration-150 hover:scale-[1.02] hover:bg-brand-dark active:scale-[0.98]"
              >
                Continue
                <ArrowRight className="h-4 w-4" />
              </button>
            ) : (
              <button
                type="submit"
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-brand px-6 py-3.5 font-semibold text-white transition-all duration-150 hover:scale-[1.02] hover:bg-brand-dark active:scale-[0.98]"
              >
                Request Free Counseling
              </button>
            )}
          </div>
          <p className="mt-3 text-center text-xs text-muted">
            We respond within 1 hour on working days
          </p>
        </form>
      )}
    </div>
  );
}
