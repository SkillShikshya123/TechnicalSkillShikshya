import { useEffect } from "react";
import { site } from "@/data/site";

export interface JsonLd {
  [key: string]: unknown;
}

interface SEOProps {
  title: string;
  description: string;
  /** Canonical path, e.g. "/courses/construction-and-electrical/electrician-training/" */
  path?: string;
  ogImage?: string;
  ogType?: string;
  /** One or more JSON-LD objects (Organization, Course, FAQPage, BlogPosting, ...) */
  jsonLd?: JsonLd | JsonLd[];
}

function upsertMeta(attr: "name" | "property", key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

let jsonLdScript: HTMLScriptElement | null = null;

/** Per-route SEO: document.title, meta description, canonical, OG tags, JSON-LD. */
export default function SEO({ title, description, path, ogImage, ogType = "website", jsonLd }: SEOProps) {
  useEffect(() => {
    document.title = title;
    upsertMeta("name", "description", description);
    const canonicalPath = path ?? window.location.pathname;
    const canonicalUrl = `${site.url}${canonicalPath}`;
    let link = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!link) {
      link = document.createElement("link");
      link.setAttribute("rel", "canonical");
      document.head.appendChild(link);
    }
    link.setAttribute("href", canonicalUrl);
    const image = `${site.url}${ogImage ?? site.ogImage}`;
    upsertMeta("property", "og:title", title);
    upsertMeta("property", "og:description", description);
    upsertMeta("property", "og:url", canonicalUrl);
    upsertMeta("property", "og:image", image);
    upsertMeta("property", "og:type", ogType);
    upsertMeta("property", "og:site_name", site.name);
    upsertMeta("name", "twitter:card", "summary_large_image");
    upsertMeta("name", "twitter:title", title);
    upsertMeta("name", "twitter:description", description);
    upsertMeta("name", "twitter:image", image);

    if (jsonLd) {
      if (!jsonLdScript) {
        jsonLdScript = document.createElement("script");
        jsonLdScript.setAttribute("type", "application/ld+json");
        document.head.appendChild(jsonLdScript);
      }
      jsonLdScript.textContent = JSON.stringify(Array.isArray(jsonLd) ? jsonLd : [jsonLd]);
    } else if (jsonLdScript) {
      jsonLdScript.remove();
      jsonLdScript = null;
    }
  }, [title, description, path, ogImage, ogType, jsonLd]);
  return null;
}

/* ---------- JSON-LD builders (parameterized per page type) ---------- */

export const orgJsonLd = (): JsonLd => ({
  "@context": "https://schema.org",
  "@type": "Organization",
  name: site.name,
  url: site.url,
  logo: `${site.url}/logo.svg`,
  email: site.contact.email,
  telephone: site.contact.phoneLandline,
  address: {
    "@type": "PostalAddress",
    streetAddress: "New Baneshwar, Opposite Civil Hospital",
    addressLocality: "Kathmandu",
    addressCountry: "NP",
  },
});

export const localBusinessJsonLd = (): JsonLd => ({
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: site.name,
  image: `${site.url}${site.ogImage}`,
  url: site.url,
  telephone: site.contact.phoneLandline,
  email: site.contact.email,
  priceRange: "NPR 8,000–25,000",
  openingHours: "Su-Fr 09:00-17:00",
  address: {
    "@type": "PostalAddress",
    streetAddress: "New Baneshwar, Opposite Civil Hospital",
    addressLocality: "Kathmandu",
    addressCountry: "NP",
  },
});

export const webSiteJsonLd = (): JsonLd => ({
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: site.name,
  url: site.url,
});

export const breadcrumbJsonLd = (items: { name: string; path: string }[]): JsonLd => ({
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: items.map((it, i) => ({
    "@type": "ListItem",
    position: i + 1,
    name: it.name,
    item: `${site.url}${it.path}`,
  })),
});

export const courseJsonLd = (c: {
  name: string;
  description: string;
  slug: string;
  categorySlug: string;
  fee: number;
}): JsonLd => ({
  "@context": "https://schema.org",
  "@type": "Course",
  name: c.name,
  description: c.description,
  url: `${site.url}/courses/${c.categorySlug}/${c.slug}/`,
  provider: {
    "@type": "Organization",
    name: site.name,
    sameAs: site.url,
  },
  offers: {
    "@type": "Offer",
    price: c.fee,
    priceCurrency: "NPR",
    availability: "https://schema.org/InStock",
  },
});

export const faqPageJsonLd = (faqs: { question: string; answer: string }[]): JsonLd => ({
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((f) => ({
    "@type": "Question",
    name: f.question,
    acceptedAnswer: { "@type": "Answer", text: f.answer },
  })),
});

export const itemListJsonLd = (items: { name: string; path: string }[]): JsonLd => ({
  "@context": "https://schema.org",
  "@type": "ItemList",
  itemListElement: items.map((it, i) => ({
    "@type": "ListItem",
    position: i + 1,
    name: it.name,
    url: `${site.url}${it.path}`,
  })),
});

export const blogPostingJsonLd = (p: {
  title: string;
  excerpt: string;
  dateISO: string;
  slug: string;
  cover: string;
}): JsonLd => ({
  "@context": "https://schema.org",
  "@type": "BlogPosting",
  headline: p.title,
  description: p.excerpt,
  datePublished: p.dateISO,
  image: `${site.url}${p.cover}`,
  author: { "@type": "Organization", name: `${site.name} Counseling Team` },
  publisher: { "@type": "Organization", name: site.name, logo: { "@type": "ImageObject", url: `${site.url}/logo.svg` } },
  mainEntityOfPage: `${site.url}/blog/${p.slug}/`,
});

export const contactPageJsonLd = (): JsonLd => ({
  "@context": "https://schema.org",
  "@type": "ContactPage",
  name: `Contact ${site.name}`,
  url: `${site.url}/contact-and-counseling/`,
});

export const aboutPageJsonLd = (): JsonLd => ({
  "@context": "https://schema.org",
  "@type": "AboutPage",
  name: `About ${site.name}`,
  url: `${site.url}/about/`,
});

export const reviewJsonLd = (reviews: { author: string; body: string; rating: number }[]): JsonLd[] =>
  reviews.map((r) => ({
    "@context": "https://schema.org",
    "@type": "Review",
    author: { "@type": "Person", name: r.author },
    reviewBody: r.body,
    reviewRating: { "@type": "Rating", ratingValue: r.rating, bestRating: 5 },
    itemReviewed: { "@type": "Organization", name: site.name },
  }));
