import { useEffect, useRef } from "react";
import { gsap, ScrollTrigger, usePrefersReducedMotion } from "@/lib/motion";

/**
 * Scroll-reveal wrapper (GSAP): children rise y 40→0, opacity 0→1,
 * staggered, once, trigger top 85% (design.md §4 global entrance language).
 */
interface RevealProps {
  children: React.ReactNode;
  className?: string;
  /** Stagger between direct children (seconds). */
  stagger?: number;
  y?: number;
  delay?: number;
}

export default function Reveal({ children, className, stagger = 0.1, y = 40, delay = 0 }: RevealProps) {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const targets = Array.from(el.children);
    if (!targets.length) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.fromTo(
          targets,
          { opacity: 0 },
          {
            opacity: 1,
            duration: 0.4,
            stagger: 0.06,
            delay,
            scrollTrigger: { trigger: el, start: "top 85%", once: true },
          },
        );
      } else {
        gsap.fromTo(
          targets,
          { opacity: 0, y },
          {
            opacity: 1,
            y: 0,
            duration: 0.55,
            ease: "power3.out",
            stagger,
            delay,
            scrollTrigger: { trigger: el, start: "top 85%", once: true },
          },
        );
      }
    }, el);
    return () => ctx.revert();
  }, [reduced, stagger, y, delay]);

  return (
    <div ref={ref} className={className}>
      {children}
    </div>
  );
}

export { ScrollTrigger };
