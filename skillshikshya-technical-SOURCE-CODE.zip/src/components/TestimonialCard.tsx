import { Star } from "lucide-react";
import type { Testimonial } from "@/data/testimonials";
import { cn } from "@/lib/utils";

interface TestimonialCardProps {
  testimonial: Testimonial;
  className?: string;
}

function initials(name: string) {
  return name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

/** Testimonial card: 5 amber stars, quote, name + trade · location (design.md §5.5). */
export default function TestimonialCard({ testimonial, className }: TestimonialCardProps) {
  return (
    <figure
      className={cn(
        "flex flex-col rounded-2xl border border-border-soft bg-white p-6 shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift",
        className,
      )}
    >
      <div className="flex gap-1" aria-label={`${testimonial.stars} out of 5 stars`}>
        {Array.from({ length: testimonial.stars }).map((_, i) => (
          <Star key={i} className="h-4 w-4 fill-amber text-amber" />
        ))}
      </div>
      <blockquote className="mt-4 flex-1 text-[17px] italic leading-relaxed text-ink">
        "{testimonial.quote}"
      </blockquote>
      <figcaption className="mt-5 flex items-center gap-3 border-t border-border-soft pt-4">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-soft font-heading text-sm font-bold text-brand">
          {initials(testimonial.name)}
        </span>
        <span>
          <span className="block font-heading text-[15px] font-semibold text-ink">{testimonial.name}</span>
          <span className="block font-mono text-[11px] uppercase tracking-wide text-muted">
            {testimonial.course} · {testimonial.location}
          </span>
        </span>
      </figcaption>
    </figure>
  );
}
