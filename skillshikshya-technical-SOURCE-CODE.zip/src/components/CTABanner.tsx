import { Link } from "react-router";
import { Phone } from "lucide-react";
import { motion } from "framer-motion";
import SectionEyebrow from "./SectionEyebrow";
import { site } from "@/data/site";
import { usePrefersReducedMotion } from "@/lib/motion";

interface CTABannerProps {
  headline?: string;
  lead?: string;
  eyebrow?: string;
  primaryLabel?: string;
  primaryHref?: string;
}

/** Dark pre-footer CTA banner shown on every page except contact (design.md §5.3). */
export default function CTABanner({
  headline = "Not sure which course fits you?",
  lead = "Talk to a career counselor for free — we'll map your goals to the right trade, batch, and budget.",
  eyebrow = "— TAKE THE FIRST STEP",
  primaryLabel = "Get Free Career Counseling",
  primaryHref = "/contact-and-counseling/",
}: CTABannerProps) {
  const reduced = usePrefersReducedMotion();
  return (
    <section className="bg-forest bg-stripes">
      <motion.div
        className="mx-auto max-w-4xl px-5 py-16 text-center md:px-8 md:py-24"
        initial={reduced ? { opacity: 0 } : { opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      >
        <SectionEyebrow dark>{eyebrow}</SectionEyebrow>
        <h2 className="mt-4 font-heading text-3xl font-bold text-white md:text-[40px] md:leading-[1.1]">
          {headline}
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-[17px] leading-[1.65] text-forest-body md:text-[19px]">
          {lead}
        </p>
        <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <motion.div
            animate={reduced ? {} : { boxShadow: ["0 0 0 0 rgba(242,169,59,0.45)", "0 0 0 14px rgba(242,169,59,0)"] }}
            transition={{ duration: 2.4, repeat: Infinity }}
            className="rounded-xl"
          >
            <Link
              to={primaryHref}
              className="block rounded-xl bg-amber px-7 py-3.5 font-semibold text-forest transition-transform duration-150 hover:scale-[1.02] active:scale-[0.98]"
            >
              {primaryLabel}
            </Link>
          </motion.div>
          <a
            href={`tel:${site.contact.phoneLandline}`}
            className="flex items-center gap-2 rounded-xl border border-white/40 px-7 py-3.5 font-semibold text-white transition-colors hover:border-white hover:bg-white/5"
          >
            <Phone className="h-4 w-4" />
            Call {site.contact.phoneLandline}
          </a>
        </div>
      </motion.div>
    </section>
  );
}
