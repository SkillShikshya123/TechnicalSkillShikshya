import { Link } from "react-router";
import { CalendarDays, Clock, Info } from "lucide-react";
import { motion } from "framer-motion";
import type { Batch } from "@/data/batches";
import { courseBySlug, coursePath } from "@/data/courses";
import { usePrefersReducedMotion } from "@/lib/motion";
import { cn } from "@/lib/utils";

interface BatchCardProps {
  batch: Batch;
  className?: string;
}

/** Forest batch card with seats-left amber warning bar (design.md §5.5). */
export default function BatchCard({ batch, className }: BatchCardProps) {
  const reduced = usePrefersReducedMotion();
  const takenPct = Math.round(((batch.seatsTotal - batch.seatsLeft) / batch.seatsTotal) * 100);
  const course = courseBySlug(batch.courseSlug);

  return (
    <div
      className={cn(
        "flex flex-col rounded-2xl border border-white/10 bg-forest p-6 transition-all duration-300 hover:-translate-y-1 hover:border-amber/40",
        className,
      )}
    >
      <p className="font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-amber">
        {batch.category}
      </p>
      <h3 className="mt-2 font-heading text-xl font-semibold text-white">{batch.courseName}</h3>
      <ul className="mt-4 space-y-2 text-sm text-forest-body">
        <li className="flex items-center gap-2">
          <CalendarDays className="h-4 w-4 text-amber" />
          {batch.startLabel}
        </li>
        <li className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-amber" />
          {batch.duration} · {batch.note}
        </li>
      </ul>
      <div className="mt-5">
        <div className="h-1.5 overflow-hidden rounded-full bg-amber-soft/30">
          <motion.div
            className="h-full rounded-full bg-amber"
            initial={{ width: 0 }}
            whileInView={{ width: `${takenPct}%` }}
            viewport={{ once: true }}
            transition={reduced ? { duration: 0.1 } : { duration: 0.8, delay: 0.3, ease: "easeOut" }}
          />
        </div>
        <p className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-amber">
          <Info className="h-3.5 w-3.5" />
          Only {batch.seatsLeft} seats left
        </p>
      </div>
      <Link
        to={course ? coursePath(course) : "/courses/"}
        className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-white transition-colors hover:text-amber"
      >
        View course →
      </Link>
    </div>
  );
}
