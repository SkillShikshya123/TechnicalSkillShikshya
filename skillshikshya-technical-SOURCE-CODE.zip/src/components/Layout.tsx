import { useEffect } from "react";
import { Outlet, useLocation, useSearchParams } from "react-router";
import { AnimatePresence, motion } from "framer-motion";
import Navbar from "./Navbar";
import Footer from "./Footer";
import CTABanner from "./CTABanner";
import WhatsAppFab from "./WhatsAppFab";
import { initLenis, scrollToTarget } from "@/lib/scroll";
import { ScrollTrigger, usePrefersReducedMotion } from "@/lib/motion";

/**
 * Pages where the page itself is the CTA (contact) — the pre-footer
 * banner is suppressed. Pages can also opt out by wrapping their content
 * in <CTABannerOverride hide /> if needed later.
 */
const NO_CTA_PREFIXES = [
  "/contact-and-counseling",
  "/success-stories",
  "/graduate-registry",
  "/about",
  "/skill-test-and-certification",
];

/** Per-route pre-footer CTA copy variants (design page specs). */
const CTA_VARIANTS: Record<
  string,
  { headline: string; lead?: string; eyebrow?: string; primaryLabel?: string }
> = {
  "/foreign-employment-preparation": {
    headline: "Your trade skill is your visa advantage.",
    lead: "Book a free counseling session — we'll map your target country to the right NSTB level and course.",
    eyebrow: "— WORK ABROAD",
    primaryLabel: "Book Free Counseling Session",
  },
  "/corporate-and-group-training": {
    headline: "Need individual counseling instead?",
    lead: "Looking to train yourself rather than a team? Talk to a career counselor for free.",
    eyebrow: "— INDIVIDUAL TRAINING",
    primaryLabel: "Get Free Career Counseling",
  },
};

export default function Layout() {
  const location = useLocation();
  const reduced = usePrefersReducedMotion();

  useEffect(() => initLenis(), []);

  // Scroll to top on route change (respect ?scroll= section anchors)
  const [searchParams] = useSearchParams();
  useEffect(() => {
    const anchor = searchParams.get("scroll");
    if (anchor) {
      // Assertive snap-scroll: the new page mounts only after AnimatePresence's
      // exit animation, ScrollTrigger inserts pin-spacers on a deferred refresh
      // (shifting every anchor below the pinned section), and Lenis smooth-scroll
      // desyncs if a refresh lands mid-animation. So: poll until the anchor
      // exists, force a synchronous refresh, native-snap to its FINAL position,
      // then re-assert a few times against late layout shifts (fonts/images).
      let raf = 0;
      let tries = 0;
      const timers: number[] = [];
      const snap = () => {
        const el = document.getElementById(anchor);
        if (!el) return false;
        ScrollTrigger.refresh();
        const top = el.getBoundingClientRect().top + window.scrollY - 72;
        window.scrollTo({ top, behavior: "auto" });
        return true;
      };
      const attempt = () => {
        if (snap()) {
          [200, 600, 1200].forEach((ms) => timers.push(window.setTimeout(snap, ms)));
          return;
        }
        if (++tries < 120) raf = requestAnimationFrame(attempt);
      };
      raf = requestAnimationFrame(attempt);
      return () => {
        cancelAnimationFrame(raf);
        timers.forEach(clearTimeout);
      };
    }
    scrollToTarget(0, true);
  }, [location.pathname, location.search]);

  const showCTA = !NO_CTA_PREFIXES.some((p) => location.pathname.startsWith(p));
  const ctaVariant = Object.entries(CTA_VARIANTS).find(([p]) =>
    location.pathname.startsWith(p),
  )?.[1];

  return (
    <div className="flex min-h-[100dvh] flex-col bg-white">
      <Navbar />
      <AnimatePresence mode="wait">
        <motion.main
          key={location.pathname}
          className="flex-1"
          initial={reduced ? { opacity: 0 } : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={reduced ? { opacity: 0 } : { opacity: 0, y: -12 }}
          transition={{ duration: reduced ? 0.15 : 0.35, ease: "easeOut" }}
        >
          <Outlet />
        </motion.main>
      </AnimatePresence>
      {showCTA && <CTABanner {...ctaVariant} />}
      <WhatsAppFab />
      <Footer />
    </div>
  );
}
