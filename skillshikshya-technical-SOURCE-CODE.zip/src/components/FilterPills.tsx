import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface FilterPillsProps {
  options: string[];
  active: string;
  onChange: (value: string) => void;
  className?: string;
}

/** Rounded-full filter pill row (design.md §5.5). */
export default function FilterPills({ options, active, onChange, className }: FilterPillsProps) {
  return (
    <div className={cn("flex flex-wrap items-center gap-2.5", className)} role="tablist">
      {options.map((opt) => {
        const isActive = opt === active;
        return (
          <motion.button
            key={opt}
            role="tab"
            aria-selected={isActive}
            onClick={() => onChange(opt)}
            whileTap={{ scale: 1.03 }}
            className={cn(
              "rounded-full px-4 py-2 text-sm font-medium transition-colors duration-200",
              isActive
                ? "bg-brand text-white shadow-soft"
                : "border border-border-soft bg-white text-ink hover:border-brand/50",
            )}
          >
            {opt}
          </motion.button>
        );
      })}
    </div>
  );
}
