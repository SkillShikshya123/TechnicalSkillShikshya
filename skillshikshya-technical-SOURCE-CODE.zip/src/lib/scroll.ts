import Lenis from "lenis";
import { gsap, ScrollTrigger, prefersReducedMotion } from "./motion";

let lenis: Lenis | null = null;

/** Initialize Lenis smooth scrolling wired to ScrollTrigger. Call once in Layout. */
export function initLenis(): () => void {
  if (lenis) return () => {};
  lenis = new Lenis({ lerp: 0.1, smoothWheel: !prefersReducedMotion() });
  lenis.on("scroll", ScrollTrigger.update);
  const tick = (time: number) => lenis?.raf(time * 1000);
  gsap.ticker.add(tick);
  gsap.ticker.lagSmoothing(0);
  return () => {
    gsap.ticker.remove(tick);
    lenis?.destroy();
    lenis = null;
  };
}

/** Smooth-scroll to an element id or top; falls back to native behavior. */
export function scrollToTarget(target: string | number, immediate = false) {
  // Force any pending ScrollTrigger setup (pin-spacers!) to apply synchronously,
  // so anchor offsets measured below are the FINAL layout, not pre-pin values.
  if (typeof target === "string") ScrollTrigger.refresh();
  if (lenis) {
    lenis.scrollTo(target as never, { immediate, offset: typeof target === "string" ? -72 : 0 });
    return;
  }
  if (typeof target === "number") {
    window.scrollTo({ top: target, behavior: immediate ? "auto" : "smooth" });
  } else {
    document.querySelector(target)?.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}
