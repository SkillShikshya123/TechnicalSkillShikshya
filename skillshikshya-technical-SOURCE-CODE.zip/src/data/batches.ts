export interface Batch {
  id: string;
  courseSlug: string;
  courseName: string;
  category: string;
  startDate: string;
  startLabel: string;
  duration: string;
  note: string;
  seatsTotal: number;
  seatsLeft: number;
}

export const batches: Batch[] = [
  {
    id: "batch-electrician-aug-2026",
    courseSlug: "electrician-training",
    courseName: "Electrician Training",
    category: "Construction & Electrical",
    startDate: "2026-08-01",
    startLabel: "Starts Aug 1, 2026",
    duration: "3 months",
    note: "Morning & evening shifts",
    seatsTotal: 40,
    seatsLeft: 8,
  },
  {
    id: "batch-beautician-aug-2026",
    courseSlug: "makeup-beautician-course",
    courseName: "Makeup & Beautician",
    category: "Beauty & Wellness",
    startDate: "2026-08-05",
    startLabel: "Starts Aug 5, 2026",
    duration: "3 months",
    note: "Day and evening batches",
    seatsTotal: 36,
    seatsLeft: 5,
  },
  {
    id: "batch-caregiver-aug-2026",
    courseSlug: "elderly-caregiver-training",
    courseName: "Elderly Caregiver",
    category: "Care Services",
    startDate: "2026-08-10",
    startLabel: "Starts Aug 10, 2026",
    duration: "3 months",
    note: "G2G Israel/Japan pathway included",
    seatsTotal: 28,
    seatsLeft: 6,
  },
];

export const batchBannerEyebrow = "— UPCOMING BATCH DATES — AUGUST 2026";
export const nextBatchLabel = "Next Batch Starts: August 1, 2026 — Limited seats!";
