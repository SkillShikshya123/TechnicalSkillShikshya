export type CategoryIcon =
  | "Sparkles"
  | "Wrench"
  | "Coffee"
  | "HeartHandshake"
  | "Store"
  | "Award"
  | "Plane"
  | "Briefcase"
  | "HeartPulse"
  | "TrendingUp";

export interface CategoryHighlight {
  icon: CategoryIcon;
  title: string;
  text: string;
}

export interface Category {
  /** URL slug for the static category page: /courses/<slug>/ */
  slug: string;
  name: string;
  /** Anchor/filter key used by the /courses/ hub ?cat= filter pills (UX, not SEO). */
  anchorId: string;
  intro: string;
  courseCount: number;
  fromPrice: string;
  shortLine: string;
  image: string;
  icon: "Sparkles" | "Wrench" | "Coffee" | "HeartHandshake";
  /* --- Static category page (SEO) fields --- */
  pageTitle: string;
  metaDescription: string;
  h1: string;
  heroLead: string;
  /** 120–180 word unique, keyword-rich intro copy for the category page. */
  pageIntro: string;
  /** "Why these trades" outcomes strip on the category page. */
  highlights: CategoryHighlight[];
}

export const categories: Category[] = [
  {
    slug: "beauty-and-wellness",
    name: "Beauty & Wellness",
    anchorId: "beauty-wellness",
    intro:
      "Gain practical training in salon work, advanced makeup, and styling. Built for local self-employment, beauty clinic roles, or starting your own salon business.",
    courseCount: 4,
    fromPrice: "from Rs 8,000",
    shortLine: "Salon work, makeup & styling — for jobs or your own studio.",
    image: "/category-beauty.webp",
    icon: "Sparkles",
    pageTitle:
      "Beauty and Wellness Courses in Nepal — Beautician Training Kathmandu | SkillShikshya",
    metaDescription:
      "Beauty and wellness courses in Nepal: beautician training in Kathmandu, makeup, nail art, hair styling & barber courses. CTEVT affiliated, NSTB-aligned, fees from Rs 8,000.",
    h1: "Beauty and Wellness Courses in Nepal",
    heroLead:
      "Four hands-on salon trade courses — makeup & beautician training, nail art, hair styling, and barber training — taught in salon-style labs in New Baneshwar, Kathmandu.",
    pageIntro:
      "Looking for beauty and wellness courses in Nepal that actually lead to income? SkillShikshya Technical's Beauty & Wellness category brings together four practical programs — a makeup and beautician course, a nail art course, a hair styling course, and barber training — taught in salon-style labs in New Baneshwar, Kathmandu. Our beautician training in Kathmandu is built around daily hands-on practice: bridal makeup on real models, gel and acrylic nail systems, professional cutting and coloring, and classic men's grooming. Every course is CTEVT affiliated, so your certificate is government-recognized, and the syllabus aligns with National Skill Testing Board (NSTB) competencies — useful whether you plan to join a Kathmandu salon, launch your own salon business, or apply for beauty-sector jobs in the Gulf, where certified beauticians earn AED 1,500–2,500 per month. Graduates typically earn Rs 15,000–40,000 per month locally, with bridal artists charging Rs 8,000–30,000 per booking in season. With transparent fees from Rs 8,000, flexible morning and evening batches, installment payment plans, and free career counseling, this is the most practical way to turn an interest in beauty into a certified, employable skill.",
    highlights: [
      {
        icon: "Store",
        title: "Low-cost business launch",
        text: "Salon, nail, and barber startups need minimal capital — graduates launch home-visit services within weeks of finishing.",
      },
      {
        icon: "Award",
        title: "Wedding-season demand",
        text: "Bridal makeup and styling bookings spike every season; certified artists set premium per-booking rates.",
      },
      {
        icon: "Plane",
        title: "Gulf salon pathways",
        text: "UAE and Qatar salons hire certified Nepali beauticians at AED 1,500–2,500/month — your CTEVT certificate strengthens the visa file.",
      },
    ],
  },
  {
    slug: "construction-and-electrical",
    name: "Construction & Electrical",
    anchorId: "construction-electrical",
    intro:
      "Our highest demand trade category for foreign employment. Focuses on practical house wiring, motor repair, and industrial electrical work mapped to Level 1 & 2 exams.",
    courseCount: 2,
    fromPrice: "from Rs 14,000",
    shortLine: "Highest-demand trades for foreign employment.",
    image: "/category-construction.webp",
    icon: "Wrench",
    pageTitle:
      "Construction and Electrical Training in Nepal — CTEVT Certified | SkillShikshya",
    metaDescription:
      "Construction and electrical training in Nepal: electrician course, house wiring training in Kathmandu & carpentry course. CTEVT certified, NSTB Level 1 & 2 mapped, Gulf-ready.",
    h1: "Construction and Electrical Training in Nepal",
    heroLead:
      "Our two highest-demand trade programs — electrician and carpentry training — taught through intensive workshop practice and mapped to NSTB Level 1 & 2 exams.",
    pageIntro:
      "SkillShikshya Technical offers construction and electrical training in Nepal designed for one goal: getting you hired. This category covers our two highest-demand trade programs — an electrician course built on house wiring training in Kathmandu, and a carpentry course covering furniture making and shuttering work — both taught through intensive workshop practice at our New Baneshwar campus. You will work on live wiring panels, distribution boards, motors, and real furniture builds from the first week, not sit through theory lectures. The curriculum maps directly to National Skill Testing Board (NSTB) Level 1 and Level 2 practical exams, and as a CTEVT certified institute your certificate is nationally recognized and verifiable by employers and manpower agencies. These are the trades Gulf recruiters ask for first: certified electricians earn AED 2,500–3,500 per month in the UAE and Qatar, while local graduates earn Rs 22,000–45,000 per month in Kathmandu Valley's construction boom. Courses run 3 months with morning and evening shifts, transparent fees from Rs 14,000, installment options, and placement support through our 30+ employer network.",
    highlights: [
      {
        icon: "Plane",
        title: "Top foreign-employment trades",
        text: "Electrician and carpentry are top-10 Gulf demand trades — NSTB-verified skills unlock skilled-tier visas and wages.",
      },
      {
        icon: "Award",
        title: "NSTB Level 1 & 2 mapped",
        text: "The curriculum mirrors the government practical exams that manpower agencies and visa processes require.",
      },
      {
        icon: "TrendingUp",
        title: "Kathmandu construction boom",
        text: "Valley contractors, fit-out companies, and facility firms hire certified wiring technicians and carpenters year-round.",
      },
    ],
  },
  {
    slug: "hospitality-and-culinary",
    name: "Hospitality & Culinary",
    anchorId: "hospitality-culinary",
    intro:
      "Learn coffee craft, baking, and beverage chemistry. Prepares graduates for barista or kitchen jobs in popular cafes and resorts in Nepal or overseas.",
    courseCount: 3,
    fromPrice: "from Rs 9,000",
    shortLine: "Coffee craft, baking & beverage chemistry.",
    image: "/category-hospitality.webp",
    icon: "Coffee",
    pageTitle:
      "Hospitality and Culinary Courses in Kathmandu — Barista, Baking & Bartending | SkillShikshya",
    metaDescription:
      "Hospitality and culinary courses in Kathmandu: barista training, baking course & bartending course. CTEVT affiliated, café-simulator labs, fees from Rs 9,000.",
    h1: "Hospitality and Culinary Courses in Kathmandu",
    heroLead:
      "Short, intensive programs — barista training, baking & pastry, and bartending — taught in a café-simulator lab, commercial training kitchen, and practice bar.",
    pageIntro:
      "Turn Kathmandu's café boom into your career with hospitality and culinary courses in Kathmandu that employers actually respect. SkillShikshya Technical's Hospitality & Culinary category includes barista training, a baking and pastry course, and a bartending course — short, intensive programs taught in a café-simulator lab, a commercial training kitchen, and a fully equipped practice bar. Our approach is deliberately practical: daily espresso and latte-art practice, commercial breadmaking and cake production, cocktail and mocktail mixing, and mock bar shifts that simulate real service pressure. Every course is CTEVT affiliated with National Skill Testing Board (NSTB) hospitality alignment, giving you a government-recognized certificate that Gulf hotels, cafés, and cruise lines look for when hiring Nepali staff for hotel jobs abroad. Graduates join Kathmandu cafés, bakeries, and hotels at Rs 18,000–30,000 per month, or move abroad where certified baristas and bartenders earn AED 1,200–2,000 monthly. Courses run 1–2 months, transparent fees from Rs 9,000 include all materials, with installment plans and free counseling before you enroll.",
    highlights: [
      {
        icon: "Briefcase",
        title: "Fastest route to employment",
        text: "1–2 month programs with daily practicals — graduates pass café, bakery, and hotel interviews within weeks.",
      },
      {
        icon: "Store",
        title: "Café & bakery entrepreneurship",
        text: "Coffee carts and home-baking brands are proven graduate businesses — costing and pricing are covered in class.",
      },
      {
        icon: "Plane",
        title: "Gulf hotel & cruise demand",
        text: "Certified baristas, bakers, and bartenders are recruited for Gulf hotels and cruise lines at AED 1,200–2,000/month.",
      },
    ],
  },
  {
    slug: "care-services",
    name: "Care Services",
    anchorId: "care-services",
    intro:
      "Gain essential skills in nursing care, elderly care, and basic first aid. Highly recommended for students preparing for G2G programs to Israel, UK, or Japan.",
    courseCount: 1,
    fromPrice: "Rs 25,000",
    shortLine: "Elderly care & first aid — Israel/Japan G2G ready.",
    image: "/category-care.webp",
    icon: "HeartHandshake",
    pageTitle:
      "Caregiver Training in Nepal — 390-Hour CTEVT Caregiver Course | SkillShikshya",
    metaDescription:
      "Caregiver training in Nepal: 390-hour CTEVT elderly caregiver course with first aid/CPR, built for Israel & Japan G2G schemes. NSTB mapped, placement-focused, Rs 25,000.",
    h1: "Caregiver Training in Nepal",
    heroLead:
      "A professional 390-hour elderly caregiver course with first aid & CPR — purpose-built for the Israel and Japan G2G caregiver schemes and local care-home careers.",
    pageIntro:
      "Caregiver training in Nepal is one of the most reliable pathways to a meaningful, well-paid career — at home or abroad. SkillShikshya Technical's 390-hour CTEVT caregiver course is a 3-month professional program built around the Israel and Japan G2G (government-to-government) schemes: elderly health monitoring, safe mobility and transfers, personal hygiene and dementia care, first aid and CPR, nutrition support, and the documentation and interview skills that care employers assess. Training happens in a simulated care room with hospital beds, wheelchairs, and monitoring equipment at our New Baneshwar, Kathmandu centre. The course is CTEVT affiliated, aligned with National Skill Testing Board (NSTB) competencies, and matched to the G2G syllabus standard — our graduates work as caregivers for Israel under the G2G program (around NIS 6,443 per month) and in Japan's kaigo care sector (¥140,000–200,000 per month for SSW candidates). Locally, care homes and private families across Kathmandu Valley hire certified caregivers at Rs 20,000–40,000 per month. The full course fee is a transparent Rs 25,000 — if you want caregiver training that ends in a real placement, start with free counseling today.",
    highlights: [
      {
        icon: "Plane",
        title: "Israel & Japan G2G ready",
        text: "Syllabus, documentation, and interview prep aligned to the government-to-government caregiver schemes.",
      },
      {
        icon: "HeartPulse",
        title: "First aid & CPR included",
        text: "Emergency-response certification is built into the course at no extra cost — a requirement for care employers.",
      },
      {
        icon: "TrendingUp",
        title: "Local care demand growing",
        text: "Care homes, hospitals, and private families across Kathmandu Valley hire certified caregivers year-round.",
      },
    ],
  },
];

export const categoryBySlug = (slug: string) => categories.find((c) => c.slug === slug);
