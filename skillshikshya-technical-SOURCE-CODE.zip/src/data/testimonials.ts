export interface Testimonial {
  id: string;
  name: string;
  course: string;
  category: string;
  location: string;
  quote: string;
  stars: number;
}

export const testimonials: Testimonial[] = [
  {
    id: "ramesh-tamang",
    name: "Ramesh Tamang",
    course: "Electrician Training",
    category: "Construction & Electrical",
    location: "Saudi Arabia",
    quote:
      "After finishing electrician training here, I passed my skill test and now work in Saudi Arabia as a wiring tech. The hands-on workshop hours made all the difference.",
    stars: 5,
  },
  {
    id: "suresh-rai",
    name: "Suresh Rai",
    course: "Electrician Training",
    category: "Construction & Electrical",
    location: "Lalitpur",
    quote:
      "I built three houses' wiring on my own within six months of finishing the course. I'm now a local residential wiring contractor in Lalitpur.",
    stars: 5,
  },
  {
    id: "bikash-thapa",
    name: "Bikash Thapa",
    course: "Carpentry Training",
    category: "Construction & Electrical",
    location: "Kathmandu",
    quote:
      "The carpentry workshop hours made the biggest difference — real practice on power tools, not just boring classroom theory slides.",
    stars: 5,
  },
  {
    id: "sabina-gurung",
    name: "Sabina Gurung",
    course: "Makeup & Beautician",
    category: "Beauty & Wellness",
    location: "Rose Beauty Salon Owner, Kathmandu",
    quote:
      "I always wanted my own beauty studio. This advanced beautician course gave me the confidence and the CTEVT certificate to register my business.",
    stars: 5,
  },
  {
    id: "puja-maharjan",
    name: "Puja Maharjan",
    course: "Nail Art Training",
    category: "Beauty & Wellness",
    location: "Kathmandu",
    quote:
      "Nail art felt like a hobby before — now it's a real income for me. I run home-visit nail extensions services and make a solid monthly living.",
    stars: 5,
  },
  {
    id: "nirmala-kc",
    name: "Nirmala K.C.",
    course: "Hair Styling Course",
    category: "Beauty & Wellness",
    location: "Hair Stylist, Kathmandu",
    quote:
      "I do bridal hair styling and coloring treatments for three major salons in my neighborhood. Fully booked every wedding season!",
    stars: 5,
  },
  {
    id: "anish-shrestha",
    name: "Anish Shrestha",
    course: "Baking & Pastry",
    category: "Hospitality & Culinary",
    location: "Kathmandu",
    quote:
      "I learned baking and pastry operations here. Today, I supply artisanal sourdough bread and custom birthday cakes to three cafes in Kathmandu.",
    stars: 5,
  },
  {
    id: "sandesh-lama",
    name: "Sandesh Lama",
    course: "Barista Training",
    category: "Hospitality & Culinary",
    location: "Kathmandu",
    quote:
      "Passed my barista job interview the week after finishing the course. I'm currently working at a popular coffee chain in Koteshwor.",
    stars: 5,
  },
  {
    id: "kamala-adhikari",
    name: "Kamala Adhikari",
    course: "Elderly Caregiver",
    category: "Care Services",
    location: "Israel G2G Scheme",
    quote:
      "The care training prepared me well for working with elderly families in Israel. The certificate was officially processed by the G2G agency.",
    stars: 5,
  },
];

/** Homepage 3-card variants (shorter quotes per home.md §10). */
export const homeTestimonials: Testimonial[] = [
  {
    id: "ramesh-tamang-home",
    name: "Ramesh Tamang",
    course: "Electrician Training",
    category: "Construction & Electrical",
    location: "Saudi Arabia",
    quote:
      "After finishing electrician training here, I passed my skill test and now work in Saudi Arabia earning 4× what I would have locally.",
    stars: 5,
  },
  {
    id: "sabina-gurung-home",
    name: "Sabina Gurung",
    course: "Makeup & Beautician",
    category: "Beauty & Wellness",
    location: "Salon Owner, Kathmandu",
    quote:
      "The beautician course changed my life. I opened my own salon 3 months after graduating and now have 12 regular clients per day.",
    stars: 5,
  },
  {
    id: "anish-shrestha-home",
    name: "Anish Shrestha",
    course: "Barista Training",
    category: "Hospitality & Culinary",
    location: "Himalayan Java",
    quote:
      "The barista course was intense and practical. The mock café sessions were exactly like working in a real coffee shop.",
    stars: 5,
  },
];
