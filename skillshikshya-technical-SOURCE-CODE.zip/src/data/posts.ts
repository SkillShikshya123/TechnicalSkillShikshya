export type PostBlock =
  | { type: "h2"; text: string }
  | { type: "h3"; text: string }
  | { type: "p"; text: string }
  | { type: "list"; items: string[] }
  | { type: "faq"; faqs: { question: string; answer: string }[] }
  | { type: "cta"; heading: string; text: string; buttonLabel: string; href: string };

export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  category: "Certification" | "Foreign Employment" | "Careers" | "Salaries";
  date: string;
  dateISO: string;
  readTime: string;
  cover: string;
  coverAlt: string;
  body: PostBlock[];
}

export const posts: BlogPost[] = [
  {
    slug: "how-to-get-nstb-skill-test-certificate-nepal",
    title: "How to Get an NSTB Skill Test Certificate in Nepal (2026 Guide)",
    excerpt:
      "How to get an NSTB skill test certificate in Nepal: eligibility, 390-hour training, fees (Rs 500–2,500), exam day, and your Level 1/2 card.",
    category: "Certification",
    date: "Jul 12, 2026",
    dateISO: "2026-07-12",
    readTime: "9 min read",
    cover: "/blog-nstb.webp",
    coverAlt: "NSTB skill test application documents, ID card and pen on a desk",
    body: [
      {
        type: "p",
        text: "If you plan to work in a skilled trade — especially abroad — the NSTB skill test certificate is the single most valuable document you can carry. Manpower agencies in Kathmandu ask for it, Gulf employers verify it, and visa officers use it to separate skilled workers from general helpers. This guide walks you through the entire process: who is eligible, how many training hours you need, how to apply, what happens on exam day, and how your Level 1 or Level 2 card changes your earning power.",
      },
      { type: "h2", text: "What is the NSTB Skill Test?" },
      {
        type: "p",
        text: "The National Skill Testing Board (NSTB) conducts physical, practical exams to certify individual trade workers in Nepal. Unlike a course completion certificate, the NSTB test verifies that you can actually perform the trade — wiring a distribution board, producing a latte to standard, or safely transferring an elderly patient — under timed, assessed conditions. Successful candidates receive the National Skill Certificate — a government skill card recorded in the national database — at Level 1 (entry-level competency) or Level 2 (independent professional competency).",
      },
      {
        type: "p",
        text: "Because the card is issued by a government body and entered into a national database, foreign governments and manpower companies treat it as primary proof of trade competency. It is the credential that turns a helper's wage offer into a skilled-worker's offer.",
      },
      { type: "h2", text: "Who is eligible for the NSTB skill test?" },
      {
        type: "p",
        text: "Eligibility is intentionally broad. You do not need SEE or +2 to sit most NSTB trade tests. What assessors look for is evidence of training or work experience in the trade — typically a course completion certificate from a CTEVT-affiliated institute, or documented work experience with an employer's recommendation. Experienced workers without formal training can also apply through RPL (recognition of prior learning), which assesses on-the-job experience against the same competency standard. In practice, the cleanest route is completing a structured trade course first, because the exam tests exactly the competencies a good course teaches.",
      },
      { type: "h2", text: "Step 1: Complete your training hours" },
      {
        type: "p",
        text: "The foundation is roughly 390 hours of structured practical trade training — the standard our own trade courses are built around. This is not a bureaucratic formality: the NSTB practical exam assumes you can work at professional speed with professional safety habits. Candidates who try to sit the exam on informal experience alone most often fail on time management and safety protocol, not on core skill.",
      },
      {
        type: "list",
        items: [
          "Choose a CTEVT-affiliated course in your trade (electrician, caregiver, barista, beautician, etc.).",
          "Complete the full practical hours — around 390 hours over 3 months for most trades.",
          "Keep your course completion certificate and attendance record safe; you'll need them for the application.",
          "Ask your institute about mock tests — exam-format practice is the strongest predictor of passing.",
        ],
      },
      { type: "h2", text: "Step 2: Application, documents, and fees" },
      {
        type: "p",
        text: "Applications are submitted to the NSTB office or through your training institute, which typically batches applications for each exam window. You will need your citizenship certificate copy, passport-size photos, your training certificate, and the exam fee. The fee is set nationally: Rs 500 for Level 1, Rs 1,200 for Level 2, and Rs 2,500 for Level 3, plus Rs 150 for the certificate and ID card — with concessional rates for women, Dalit, Janajati, and PwD candidates. Exam windows open several times a year per trade; your institute's counseling office tracks the calendar and registers you for the next available session.",
      },
      { type: "h2", text: "Step 3: Exam day — what actually happens" },
      {
        type: "p",
        text: "The exam is practical, not written. You are given a timed task in a controlled lab — for an electrician, wiring a panel to a diagram; for a barista, producing espresso-based drinks to standard; for a caregiver, demonstrating safe patient transfer and vital-sign monitoring. Assessors score technique, safety, hygiene, time management, and finish quality. Candidates who practiced under timed mock conditions report the real exam feels familiar rather than frightening.",
      },
      { type: "h2", text: "Step 4: Getting your Level 1 / Level 2 card" },
      {
        type: "p",
        text: "Results are typically published within a few weeks, and successful candidates receive the NSTB skill card. Level 1 certifies you can perform the trade under supervision; Level 2 certifies independent, professional-grade competency. Most foreign employment applications target Level 1 as the entry ticket, with Level 2 commanding higher wage tiers.",
      },
      { type: "h2", text: "How the NSTB skill card helps for Gulf, Japan, and Europe visas" },
      {
        type: "p",
        text: "Countries like Romania, Poland, Croatia, Saudi Arabia, and the UAE have visa requirements that verify skill certifications, and an NSTB Level 1/2 qualification is the fastest way to pass those checks. Certified workers are eligible for skilled wages that run 50% to 100% higher than general helper wages. For Japan's SSW (Specified Skilled Worker) and Israel's G2G caregiver scheme, the certified training record is part of the file the agency processes.",
      },
      {
        type: "cta",
        heading: "Want hands-on training first?",
        text: "Our CTEVT-affiliated trade courses map directly to the NSTB exam. Electrician, caregiver, barista and 7 more trades start August 2026.",
        buttonLabel: "Explore the certification guide",
        href: "/skill-test-and-certification/",
      },
      {
        type: "faq",
        faqs: [
          {
            question: "How much does the NSTB skill test cost?",
            answer: "The official NSTB skill test fee is Rs 500 for Level 1, Rs 1,200 for Level 2, and Rs 2,500 for Level 3 — with concessional rates for women, Dalit, Janajati, and PwD candidates — plus Rs 150 for the certificate and ID card. Our counseling office confirms the current schedule for your trade when registering you.",
          },
          {
            question: "What happens if I fail the exam?",
            answer: "You can retake the test in the next exam window. Candidates who fail are told which competency areas to improve; focused retraining on those areas usually leads to a pass on the second attempt.",
          },
          {
            question: "How long is the NSTB certificate valid?",
            answer: "The skill card is a lifetime credential recorded in the national database. Some employers may ask for recent work references alongside it, but the card itself does not expire.",
          },
        ],
      },
    ],
  },
  {
    slug: "top-10-skills-in-demand-for-foreign-employment-nepal",
    title: "Top 10 Skills in Demand for Foreign Employment from Nepal (2026)",
    excerpt:
      "The skills most in demand for foreign employment from Nepal in 2026 — electricians, caregivers, welders, baristas — mapped by destination and salary.",
    category: "Foreign Employment",
    date: "Jul 5, 2026",
    dateISO: "2026-07-05",
    readTime: "11 min read",
    cover: "/blog-foreign-skills.webp",
    coverAlt: "Globe with flight paths from Kathmandu toward the Gulf, Japan and Europe",
    body: [
      {
        type: "p",
        text: "Which skills are most in demand for foreign employment from Nepal in 2026? Every year, hundreds of thousands of Nepali workers leave for work abroad — but the wage gap between unskilled helpers and certified skilled workers keeps widening. Employers in the Gulf, Eastern Europe, Israel, and Japan now routinely verify skill certification before issuing visas, and certified candidates earn 50–100% more than helpers in the same country. Here are the ten trades foreign employers are actually hiring, mapped to the destinations that want them.",
      },
      { type: "h2", text: "Why certification matters more than ever" },
      {
        type: "p",
        text: "The old route — fly out as a general helper, learn on the job — is closing. Romania, Poland, Croatia, Saudi Arabia, and the UAE have established visa checks that verify trade certification, and Japan's SSW program is skills-tested by design. The workers who clear these checks fastest carry an NSTB Level 1 or Level 2 qualification card: a government-verified, database-registered proof of trade competency. A complete certified file also moves faster on the Nepali side — the Department of Foreign Employment (DoFE) labour permit, the shram swikriti, and pre-departure steps all hinge on documents that verify cleanly.",
      },
      { type: "h2", text: "The 10 most in-demand skills for foreign employment in 2026" },
      { type: "h3", text: "1. Electrician — Gulf & Croatia/Romania" },
      {
        type: "p",
        text: "The single strongest trade for foreign employment from Nepal. Certified electricians earn QAR 1,200–1,800/month in Qatar and the UAE, and €1,400–2,200/month in Croatia and Romania — against Rs 25,000–45,000 locally. House wiring, panel work, and motor repair skills transfer directly.",
      },
      { type: "h3", text: "2. Caregiver — Israel G2G & Japan SSW" },
      {
        type: "p",
        text: "Japan's SSW caregiver (kaigo) pathway starts at ¥140,000–200,000/month for workers who clear the sector skills test and JLPT N4, rising toward ¥260,000 with experience — and Israel's G2G scheme processes trained Nepali caregivers aged 25–45 at NIS 6,443/month (roughly Rs 3.2 lakh) through the official agency. Training covers health monitoring, mobility support, first aid/CPR, and care documentation.",
      },
      { type: "h3", text: "3. Welder — Gulf" },
      { type: "p", text: "Structural and pipeline welders remain a Gulf staple, with certified welders commanding skilled-tier wages on infrastructure projects." },
      { type: "h3", text: "4. Plumber — Gulf & Europe" },
      { type: "p", text: "Plumbing pairs naturally with electrical skills; certified plumbers are hired across Gulf construction and European facility management." },
      { type: "h3", text: "5. Barista — Gulf hotels & cafés" },
      {
        type: "p",
        text: "Specialty coffee has gone global, and Gulf hotels and café chains hire certified Nepali baristas at AED 1,200–2,000/month. Espresso extraction and latte art are examinable, certifiable skills — exactly what recruiters test at interview.",
      },
      { type: "h3", text: "6. Carpenter — Gulf & Eastern Europe" },
      { type: "p", text: "Fit-out and furniture carpenters with power-tool and blueprint skills are consistently recruited for Gulf and European construction." },
      { type: "h3", text: "7. Beautician — Gulf salons" },
      {
        type: "p",
        text: "Gulf salons hire certified beauticians at AED 1,500–2,500/month. Bridal makeup, skin treatments, and salon hygiene standards are the assessed competencies.",
      },
      { type: "h3", text: "8. Baker / Pastry Cook — Gulf hotels" },
      { type: "p", text: "Hotel bakeries across the Gulf recruit pastry staff with certified commercial-kitchen training — breads, cakes, and production discipline." },
      { type: "h3", text: "9. Bartender — Gulf hotels & cruise lines" },
      { type: "p", text: "Mixology-trained bartenders are recruited by Gulf hotels and international cruise lines at strong wage tiers plus service benefits." },
      { type: "h3", text: "10. Mason — Gulf" },
      { type: "p", text: "Certified masons remain core Gulf construction demand, and certification moves workers out of the lowest helper wage band." },
      { type: "h2", text: "What certified workers earn vs helpers" },
      {
        type: "list",
        items: [
          "Electrician: QAR 1,200–1,800/mo (Gulf) · €1,400–2,200/mo (Europe)",
          "Caregiver: ¥200,000–260,000/mo (Japan G2G)",
          "Beautician: AED 1,500–2,500/mo (Gulf)",
          "Barista: AED 1,200–2,000/mo (Gulf)",
          "Rule of thumb: certified skilled wages run 50–100% above general helper wages in the same market.",
        ],
      },
      { type: "h2", text: "How to get NSTB-certified before you apply abroad" },
      {
        type: "p",
        text: "The pathway is straightforward: complete around 390 hours of practical training at a CTEVT-affiliated institute, practice with NSTB-format mock tests, sit the practical exam, and apply to manpower agencies with your Level card in hand. The whole process takes three to four months — a fraction of the wage difference it unlocks over a two-year contract.",
      },
      {
        type: "cta",
        heading: "Want an abroad-ready trade?",
        text: "Our Electrician, Caregiver (Israel/Japan G2G), Makeup & Beautician, and Carpentry courses are built for NSTB skill tests. August 2026 batches now enrolling.",
        buttonLabel: "See foreign employment prep",
        href: "/foreign-employment-preparation/",
      },
      {
        type: "faq",
        faqs: [
          {
            question: "Which skill has the highest salary abroad for Nepali workers?",
            answer: "Caregivers on Japan's G2G/SSW pathway (¥200,000–260,000/month) and electricians in Europe (€1,400–2,200/month) top the current ranges, with Gulf electrician and beautician roles close behind.",
          },
          {
            question: "Do I need +2 to train for these trades?",
            answer: "No. Most vocational trade courses have no formal education requirement — SEE passed is preferred but not mandatory. What matters is completing certified practical training.",
          },
          {
            question: "How long does it take to get ready for foreign employment?",
            answer: "Typically 3 months of training plus the NSTB exam window — around 3–4 months from enrollment to holding a skill card you can present to manpower agencies.",
          },
        ],
      },
    ],
  },
  {
    slug: "electrician-vs-plumber-which-trade-pays-better-nepal",
    title: "Electrician vs Plumber: Which Trade Pays Better in Nepal? (2026)",
    excerpt:
      "Electrician vs plumber in Nepal: salary data, Gulf and Europe demand, and training costs compared side by side — with the honest verdict for 2026.",
    category: "Salaries",
    date: "Jun 28, 2026",
    dateISO: "2026-06-28",
    readTime: "8 min read",
    cover: "/blog-electrician-plumber.webp",
    coverAlt: "Electrician's multimeter and plumber's wrench on a workshop bench",
    body: [
      {
        type: "p",
        text: "Electrician vs plumber — which trade pays better in Nepal? Two trades dominate the 'which skill should I learn?' conversation, and the short answer is: electricians hold a modest edge locally and a clearer one abroad, while plumbers enjoy a less crowded repair market. Both are hands-on, both are hireable within months, and both travel well abroad. But they differ meaningfully in local pay, overseas demand, training cost, and day-to-day work. Here is the honest, data-based comparison we give students at free counseling.",
      },
      { type: "h2", text: "Electrician vs plumber salary in Nepal" },
      {
        type: "p",
        text: "In Kathmandu Valley, trained electricians earn Rs 25,000–45,000 per month, with freshers and maintenance roles at the lower band and experienced wiring contractors well above it. Plumbers typically earn Rs 20,000–40,000 per month locally, with bathroom fit-out and building-maintenance specialists at the top. On local pay alone, the electrician trade holds a modest edge — driven by the sheer volume of new construction wiring work across the Valley, plus newer demand from inverter and solar installations, 3-phase upgrades, and NEA contractor work.",
      },
      {
        type: "list",
        items: [
          "Electrician (local): Rs 25,000–45,000/mo",
          "Plumber (local): Rs 20,000–40,000/mo",
          "Self-employed contractors in both trades exceed salaried rates within 1–2 years",
        ],
      },
      { type: "h2", text: "Abroad demand: Gulf and Europe" },
      {
        type: "p",
        text: "This is where the gap widens. Certified electricians are recruited at QAR 1,200–1,800/month in Qatar and the UAE, and €1,400–2,200/month in Croatia and Romania — among the highest trade wages available to Nepali workers. Plumbers are also recruited in the Gulf and Europe, but with fewer openings and slightly lower bands. Both trades benefit from the same rule: an NSTB Level 1/2 card moves you from helper wages to skilled wages — a 50–100% jump.",
      },
      { type: "h2", text: "Training cost and duration compared" },
      {
        type: "p",
        text: "Electrician training typically runs 3 months and costs around NPR 15,000 at a CTEVT-affiliated institute, including materials and certification — covering house wiring, MCB and distribution boards, 3-phase connections, and motor repair. Plumbing courses are comparable in duration and slightly cheaper. Both are evening-shift friendly, so you can train while working. Return on investment is fast in both cases: most graduates recover the full course fee within their first month of skilled work.",
      },
      { type: "h2", text: "Electrician vs plumber jobs in Kathmandu Valley" },
      {
        type: "p",
        text: "Every new building needs both trades — but wiring comes first and lasts longer as a service relationship (fault calls, upgrades, maintenance contracts). Electricians also plug into a wider employer network: construction firms, facility companies, and manpower agencies hiring for abroad. Plumbers enjoy steadier renovation and repair demand with less competition for each job.",
      },
      { type: "h2", text: "Which should YOU choose?" },
      {
        type: "list",
        items: [
          "Choose electrician if you want the strongest abroad demand and the highest certified wage ceiling.",
          "Choose plumbing if you prefer renovation/repair work and a less crowded local market.",
          "Choose electrician if you enjoy diagnostics and panels; plumbing if you enjoy visible, finished installations.",
          "If in doubt, start with electrician training — the safety and circuit fundamentals transfer to every other construction trade.",
        ],
      },
      {
        type: "cta",
        heading: "Want hands-on electrician training?",
        text: "Electrician Training (3 months, NPR 15,000) maps to NSTB Level 1 & 2 and Gulf demand. August 2026 batch — only 8 seats left.",
        buttonLabel: "View the electrician course",
        href: "/courses/construction-and-electrical/electrician-training/",
      },
      {
        type: "faq",
        faqs: [
          {
            question: "Which trade pays more in Nepal — electrician or plumber?",
            answer: "Electricians hold a modest edge locally (Rs 25,000–45,000 vs Rs 20,000–40,000 per month in Kathmandu Valley), and a clearer edge abroad, especially in Europe.",
          },
          {
            question: "Which trade is easier to learn?",
            answer: "Both are learnable in about 3 months with no formal education requirement. Plumbing is more physically forgiving; electrical work demands stricter safety discipline.",
          },
          {
            question: "Can I learn both trades?",
            answer: "Yes — many graduates add a second trade later. Combined electrical-and-plumbing skills make you especially valuable to building maintenance employers.",
          },
        ],
      },
    ],
  },
  {
    slug: "best-career-options-after-see-without-plus-two",
    title: "Best Career Options After SEE Without +2 (2026 Guide)",
    excerpt:
      "The best career options after SEE without +2 in Nepal: six vocational trades with real timelines, real incomes, and no academic prerequisite.",
    category: "Careers",
    date: "Jun 20, 2026",
    dateISO: "2026-06-20",
    readTime: "10 min read",
    cover: "/blog-after-see.webp",
    coverAlt: "Young Nepali student thoughtfully reviewing course brochures in bright light",
    body: [
      {
        type: "p",
        text: "What are the best career options after SEE without +2? SEE results are out, and maybe +2 isn't the plan — by choice, by circumstance, or by budget. Here's what nobody tells SEE graduates clearly enough: skipping +2 is not the end of your career. In Nepal's job market, a certified trade skill often out-earns a generic academic path — and it starts paying within months, not years.",
      },
      { type: "h2", text: "You're not stuck — the vocational pathway" },
      {
        type: "p",
        text: "Nepal's vocational training system — regulated by CTEVT and certified through the NSTB skill test — exists precisely for this moment. You complete a practical trade course (1 to 3 months) — the short-term courses after SEE that Nepal's TVET system is built around — earn a government-recognized certificate, and enter the job market with a skill employers can verify. No +2 required for enrollment in most trade courses; SEE passed is preferred but often not even mandatory.",
      },
      { type: "h2", text: "Why a vocational course beats unskilled work after SEE" },
      {
        type: "p",
        text: "The alternative many SEE graduates fall into — unskilled shop work, daily-wage labor, or a helper's job abroad — starts at Rs 12,000–15,000/month and stays flat for years. A certified trade starts higher and grows: trained electricians reach Rs 25,000–45,000/month locally, and certified workers abroad earn 50–100% more than helpers doing similar hours. The difference compounds every single year of your working life.",
      },
      { type: "h2", text: "Six career paths with real timelines" },
      { type: "h3", text: "1. Electrician — 3 months → Rs 25,000–45,000/mo" },
      {
        type: "p",
        text: "The highest-ceiling trade. Three months of house wiring, panel, and motor-repair training, NSTB Level 1/2 mapping, and immediate demand locally and abroad (Gulf: QAR 1,200–1,800/mo; Europe: €1,400–2,200/mo).",
      },
      { type: "h3", text: "2. Beautician — 3 months → your own salon" },
      {
        type: "p",
        text: "Bridal makeup, skin treatments, and salon skills. Graduates join salons at Rs 20,000–40,000/month or open their own studios — several of ours launched within 3 months of graduating. Gulf salons pay AED 1,500–2,500/month.",
      },
      { type: "h3", text: "3. Barista — 1 month → café jobs" },
      {
        type: "p",
        text: "The fastest path to a paycheck. One month of espresso and latte-art training lands you in Kathmandu's booming café scene at Rs 18,000–28,000/month — or a Gulf hotel café at AED 1,200–2,000/month.",
      },
      { type: "h3", text: "4. Caregiver — 3 months → G2G Israel/Japan" },
      {
        type: "p",
        text: "The highest overseas ceiling: Japan's SSW caregiver (kaigo) roles start at ¥140,000–200,000/month for candidates with JLPT N4 and the sector skills test, and Israel's G2G scheme pays NIS 6,443/month (about Rs 3.2 lakh) for caregivers aged 25–45. Training covers elderly care, dementia care basics, first aid/CPR, and the G2G documentation pathway, with local care-home jobs at Rs 18,000–30,000/month as a strong fallback.",
      },
      { type: "h3", text: "5. Carpentry — 3 months → furniture & fit-out work" },
      { type: "p", text: "Power tools, joinery, and modular furniture. Graduates join workshops and fit-out companies, or build custom-furniture businesses — a top-10 Gulf demand trade as well." },
      { type: "h3", text: "6. Nail Art — 6 weeks → home-visit business" },
      { type: "p", text: "The lowest-cost business start: gel extensions and 3D nail art in 6 weeks, then home-visit services with repeat clients and flexible hours — a real monthly income, not a hobby." },
      { type: "h2", text: "How parents should think about it" },
      {
        type: "p",
        text: "For parents reading this: vocational training is not a consolation prize. It is government-regulated (CTEVT affiliated), government-certified (NSTB skill tests), and outcome-verified — our institute alone has placed 2,000+ graduates since 2018 with a 90%+ placement rate. Fees range from Rs 8,000 to Rs 25,000 with installment plans, and most students recover the full fee in their first month of skilled work.",
      },
      { type: "h2", text: "How to enroll" },
      {
        type: "list",
        items: [
          "Book a free counseling session — we map your interests and budget to the right trade.",
          "Choose your course and batch (August 2026 batches now enrolling).",
          "Train for 1–3 months, 80% hands-on, in our Baneshwar workshop labs.",
          "Sit your certification, then use placement support — local employers or abroad pathways.",
        ],
      },
      {
        type: "cta",
        heading: "Not sure which trade fits you?",
        text: "Talk to a career counselor for free — we'll map your goals to the right trade, batch, and budget. Zero obligation.",
        buttonLabel: "Get free career counseling",
        href: "/contact-and-counseling/",
      },
      {
        type: "faq",
        faqs: [
          {
            question: "Can I join a vocational course right after SEE without +2?",
            answer: "Yes. Most trade courses have no formal education requirement — SEE passed is preferred but not mandatory. You can enroll for the next batch immediately.",
          },
          {
            question: "How much can I earn without +2 but with a trade certificate?",
            answer: "Certified tradespeople earn Rs 18,000–45,000/month locally depending on trade — and 50–100% more than helpers on skilled visas abroad.",
          },
          {
            question: "Can I continue academic study later?",
            answer: "Yes. Many students work in their trade and return to academic study later with income and experience. A trade certificate never blocks further education.",
          },
        ],
      },
    ],
  },
  {
    slug: "nstb-level-1-vs-2-vs-3-difference",
    title: "NSTB Level 1 vs Level 2 vs Level 3 — What's the Difference?",
    excerpt:
      "NSTB Level 1 vs Level 2 vs Level 3 explained: what each level certifies, exam fees (Rs 500–2,500), and which level foreign employers ask for.",
    category: "Certification",
    date: "Sep 4, 2026",
    dateISO: "2026-09-04",
    readTime: "9 min read",
    cover: "/blog-nstb-levels.webp",
    coverAlt: "Trainee electrician wiring a practice distribution board in a Kathmandu training lab",
    body: [
      {
        type: "p",
        text: "NSTB Level 1 vs Level 2 vs Level 3 — the short answer: Level 1 certifies entry-level competency and is the card most first-time applicants need for skilled visas abroad; Level 2 certifies independent, professional-grade competency and unlocks higher wage bands; Level 3 is a supervisory credential for senior technicians, not an entry requirement. Ask anyone preparing for foreign employment from Nepal and they will tell you: get an NSTB card. Ask which level, and the answers get vague. The confusion costs people real money — some workers pay for exams they don't need, while others apply for skilled visas with no certification at all and get filtered out at the manpower agency's first screening. This guide explains what each NSTB level actually certifies, who needs which one, and how our trade courses map to each level.",
      },
      { type: "h2", text: "What the NSTB levels actually mean" },
      {
        type: "p",
        text: "The National Skill Testing Board certifies individual trade workers through timed, practical exams — not written tests. You perform the trade in front of assessors: wiring a distribution board, producing espresso-based drinks to standard, executing a bridal makeup look, or demonstrating a safe patient transfer. The level you are awarded reflects how independently and to what standard you can perform the whole occupation. The credential issued is the National Skill Certificate, a government skill card recorded in the national database. Exam fees are set nationally: Rs 500 for Level 1, Rs 1,200 for Level 2, and Rs 2,500 for Level 3, plus Rs 150 for the card itself — with concessional rates for women, Dalit, Janajati, and PwD candidates.",
      },
      { type: "h3", text: "Level 1 — entry-level competency (the 390-hour standard)" },
      {
        type: "p",
        text: "Level 1 certifies that you can perform the core tasks of a trade correctly and safely under normal supervision. The benchmark most institutes build toward is roughly 390 hours of structured practical training — about 3 months of full-time workshop practice — before sitting the Level 1 exam. This is the level the vast majority of first-time foreign employment applicants need: manpower agencies in Kathmandu treat a Level 1 card as the dividing line between a helper application and a skilled-worker application.",
      },
      { type: "h3", text: "Level 2 — independent, professional-grade competency" },
      {
        type: "p",
        text: "Level 2 certifies that you can work independently at professional speed and quality — planning the job, executing it without supervision, and handling faults or variations on your own. Assessors expect faster completion, cleaner finish, and the ability to explain your choices. Level 2 typically assumes real work experience on top of training, and it unlocks the higher wage tiers abroad: certified Level 2 electricians, for example, are quoted at the top of the Gulf skilled-wage bands rather than the entry bands.",
      },
      { type: "h3", text: "Level 3 — advanced and supervisory-level certification" },
      {
        type: "p",
        text: "Level 3 sits at the top of the national skills framework: advanced, supervisory-level competency for senior technicians, site foremen, and trainers. It is aimed at workers with years of documented experience who want to lead teams or assess juniors — not at first-time applicants. For most students reading this, Level 3 is a medium-term career goal, not the certificate you need for your first contract abroad. Be cautious of anyone selling you a Level 3 exam as an entry requirement; it almost never is.",
      },
      { type: "h2", text: "Which level do foreign employers actually ask for?" },
      {
        type: "list",
        items: [
          "Gulf (Qatar, UAE, Saudi Arabia): Level 1 is the standard entry ticket for skilled-wage visas; Level 2 commands the upper wage bands on infrastructure and hotel projects.",
          "Eastern Europe (Croatia, Romania, Poland): visa checks verify trade certification; Level 1 or 2 both pass, with Level 2 strengthening salary negotiations.",
          "Israel G2G caregiver scheme: certified caregiver training aligned to the G2G syllabus is processed through the official agency; the practical competency standard matters more than the level number.",
          "Japan SSW (Specified Skilled Worker): Japan runs its own skills tests per sector, but a certified NSTB-aligned training record is what gets Nepali candidates through agency screening.",
          "Korea EPS: selection is driven by the EPS-TOPIK language test, but certified trade skills improve matching into better-paying manufacturing roles.",
        ],
      },
      {
        type: "p",
        text: "The practical takeaway: if your goal is a skilled job abroad within the next 6–12 months, target Level 1 first. It is achievable in one 3-month training cycle plus an exam window, and it already moves your wage offer 50–100% above helper wages. Upgrade to Level 2 after a year or two of real work — many employers abroad will sponsor or recognize the upgrade.",
      },
      { type: "h2", text: "How SkillShikshya courses map to NSTB levels" },
      {
        type: "p",
        text: "Every course we run is built around the NSTB practical competency list for that trade, so your training hours count directly toward exam readiness rather than being generic classroom time.",
      },
      {
        type: "list",
        items: [
          "Electrician Training (3 months, 390 hours): maps to NSTB Level 1 & Level 2 (Electrician), with mock exams in the final two weeks.",
          "Elderly Caregiver Training (3 months): maps to NSTB Level 1 & 2 (Caregiver) and the Israel/Japan G2G syllabus standard.",
          "Makeup & Beautician (3 months): maps to NSTB Level 1 & Level 2 (Beautician), including bridal and salon-hygiene competencies.",
          "Hair Styling and Barber Training (2 months each): map to NSTB Level 1 for their respective trades.",
          "Barista, Baking & Pastry, and Bartending (1–2 months): CTEVT-affiliated certificates with hospitality skill-test alignment; our counselors advise on the relevant exam window per trade.",
        ],
      },
      { type: "h2", text: "Can you skip Level 1 and sit Level 2 directly?" },
      {
        type: "p",
        text: "Technically, experienced workers can apply for Level 2 through recognition of prior learning (RPL), with documented work experience and an employer's recommendation. In practice, candidates without formal training underestimate the exam: Level 2 is timed, safety-scored, and assumes professional workflow habits that informal work rarely builds. The reliable route we recommend is structured training first (which also gives you the CTEVT-affiliated completion certificate for your visa file), then Level 1, then Level 2 after real job experience. Skipping steps saves weeks and risks failing an exam that costs you a hiring cycle.",
      },
      {
        type: "cta",
        heading: "Not sure which level you need?",
        text: "Our counselors map your trade, target country, and timeline to the right NSTB level — and the course that gets you there. Free, zero obligation.",
        buttonLabel: "Read the CTEVT & NSTB certification guide",
        href: "/skill-test-and-certification/",
      },
      {
        type: "faq",
        faqs: [
          {
            question: "Is NSTB Level 1 enough for a Gulf skilled-worker visa?",
            answer: "Yes. Level 1 is the standard entry credential manpower agencies ask for in Qatar, the UAE, and Saudi Arabia. It already qualifies you for skilled wages 50–100% above helper wages; Level 2 raises you into the upper wage bands.",
          },
          {
            question: "How long does it take to reach Level 1 from zero?",
            answer: "About 3 months of structured practical training (roughly 390 hours) plus one exam window — most students hold their card within 4 months of enrolling.",
          },
          {
            question: "Do I need Level 3 for any foreign employment route?",
            answer: "No current mainstream route — Gulf, Eastern Europe, Israel G2G, Japan SSW, or Korea EPS — requires Level 3 from first-time applicants. Level 3 is for senior technicians and supervisors with years of experience.",
          },
          {
            question: "What is the difference between a course certificate and an NSTB level card?",
            answer: "A course completion certificate proves you trained; the NSTB level card proves a government assessor watched you perform the trade to standard. Foreign employers and visa processes weight the NSTB card far more heavily.",
          },
        ],
      },
    ],
  },
  {
    slug: "skill-test-documents-checklist-foreign-employment",
    title: "Skill Test Documents Checklist for Foreign Employment from Nepal",
    excerpt:
      "NSTB skill test and foreign employment documents for Nepal: citizenship, photos, training proof, manpower file — plus a realistic timeline to visa.",
    category: "Foreign Employment",
    date: "Sep 8, 2026",
    dateISO: "2026-09-08",
    readTime: "10 min read",
    cover: "/blog-documents-checklist.webp",
    coverAlt: "Neatly arranged passport, citizenship certificate and photos on a wooden desk in Kathmandu",
    body: [
      {
        type: "p",
        text: "Most foreign employment applications from Nepal don't fail at the interview — they fail at the document stage. A missing photo in the wrong size, a training certificate the agency can't verify, a citizenship copy without the right stamp: small gaps that stall your file for weeks while someone else's complete file gets processed. This checklist covers every document you need for the NSTB skill test and the manpower-agency pipeline afterward, in the order you should collect them.",
      },
      { type: "h2", text: "Core identity documents for the NSTB skill test" },
      {
        type: "list",
        items: [
          "Citizenship certificate (Nagarikta): original for verification plus several clear photocopies — the NSTB application and every manpower file starts here.",
          "Passport: valid for at least 2–3 years; many Gulf employers reject passports with under 2 years of validity remaining. Apply or renew early — passport queues are a common bottleneck.",
          "Passport-size photos: bring more than you think you need (10–15). Keep both white-background and standard versions; different agencies and exam windows specify differently.",
          "Recent passport-size digital photo: several agencies now pre-screen candidates online before asking for physical documents.",
        ],
      },
      { type: "h2", text: "Training and certification proof" },
      {
        type: "p",
        text: "This is the section that separates skilled-worker files from helper files. You need documentary proof that you actually trained in the trade — not just a verbal claim of experience. The NSTB application itself requires only your citizenship copy, photos, training proof, and the exam fee — Rs 500 for Level 1 and Rs 1,200 for Level 2 — but the documents below are what make an agency's skilled-worker file complete.",
      },
      {
        type: "list",
        items: [
          "Course completion certificate from a CTEVT-affiliated institute — verifiable against the institute's registry (our graduates can be verified by employers through our graduate registry).",
          "Attendance / training-hours record: for trades built on the 390-hour standard, agencies increasingly ask for the hours log alongside the certificate.",
          "NSTB skill test card (Level 1 or Level 2): the single strongest document in your file — a government-verified, database-registered proof of competency.",
          "First aid / CPR certificate for caregiver applicants (required for the Israel and Japan G2G caregiver pathways).",
          "Experience letters from previous employers, if any — on letterhead, with contactable references.",
        ],
      },
      { type: "h2", text: "Manpower agency paperwork and DoFE checks" },
      {
        type: "p",
        text: "Once you engage a manpower agency, the file grows. Expect to provide: the agency's own application form, your documents above, a medical fitness report from an approved medical center (GAMCA-approved centers for Gulf destinations), and police clearance. Reputable agencies will show you the demand letter from the foreign employer before you sign anything — read it, keep a copy, and verify the agency's license with the Department of Foreign Employment (DoFE). Later stages add the shram swikriti (labour permit) and the mandatory pre-departure orientation before you fly. Never hand over your original passport or citizenship certificate except for official processing, and always take a receipt.",
      },
      { type: "h2", text: "How long from training to deployment? A realistic timeline" },
      {
        type: "p",
        text: "Weeks 1–12: complete your trade training (3 months for most trades; barista and bartending run 1 month). Weeks 12–16: sit the NSTB skill test in the next exam window and receive your card. Meanwhile, renew your passport if needed. Weeks 14–20: approach manpower agencies or employer partners with your complete file — certified candidates are typically matched faster because agencies spend no time verifying skills. Weeks 20–28: medical, visa processing, pre-departure orientation, and flight. From enrollment to departure, a well-prepared candidate should budget 5–7 months — and document gaps are what stretch it toward a year.",
      },
      { type: "h2", text: "The five most common document mistakes" },
      {
        type: "list",
        items: [
          "Name mismatches across citizenship, passport, and certificates — fix spellings before you apply anywhere, not after a visa rejection.",
          "Training certificates from non-affiliated institutes that agencies cannot verify — check CTEVT affiliation before you pay any course fee.",
          "Expired or nearly-expired passports discovered at the visa stage.",
          "Photos in the wrong size or background, reshot at premium prices next to the agency office.",
          "Paying 'guaranteed job' agents with no license and no demand letter — if the paperwork isn't verifiable, neither is the job.",
        ],
      },
      {
        type: "p",
        text: "One habit separates smooth applications from stalled ones: build a single document folder — physical and scanned — from day one of training. Every certificate, photo, and receipt goes in. When an agency calls with a sudden vacancy (and the good ones do call suddenly), the candidate whose file is complete that afternoon gets the slot.",
      },
      {
        type: "cta",
        heading: "Building your abroad-ready file?",
        text: "Our foreign employment preparation covers training, NSTB exam registration, and the full document checklist — with counselors who process G2G and Gulf files every week.",
        buttonLabel: "See foreign employment preparation",
        href: "/foreign-employment-preparation/",
      },
      {
        type: "faq",
        faqs: [
          {
            question: "What documents do I need to register for the NSTB skill test?",
            answer: "Citizenship certificate copy, passport-size photos, your training completion certificate (or documented work experience), and the exam fee. Our counseling office registers students for each exam window and confirms the current requirements per trade.",
          },
          {
            question: "Do I need a passport before starting training?",
            answer: "Not to enroll or to sit the NSTB test — but apply for it during training, since passport processing is a common delay later. You will need it the moment an agency matches you to a vacancy.",
          },
          {
            question: "How do I verify a manpower agency is legitimate?",
            answer: "Check the agency's license on the Department of Foreign Employment's official list, ask to see the employer demand letter, and never pay without a receipt. Our counselors help graduates verify agencies for free.",
          },
        ],
      },
    ],
  },
  {
    slug: "beautician-vs-makeup-artist-career-comparison-nepal",
    title: "Beautician vs Makeup Artist: Career Comparison in Nepal (2026)",
    excerpt:
      "Beautician vs makeup artist in Nepal: salary, self-employment options, and Gulf demand compared — and which training route fits which career.",
    category: "Careers",
    date: "Sep 12, 2026",
    dateISO: "2026-09-12",
    readTime: "9 min read",
    cover: "/blog-beautician-vs-makeup.webp",
    coverAlt: "Nepali beautician applying bridal makeup on a client in a warm salon studio",
    body: [
      {
        type: "p",
        text: "Beautician vs makeup artist — which career fits you better in Nepal? The two are used interchangeably in everyday conversation, but as careers they diverge meaningfully — in what you do daily, how you earn, how you train, and how the skills travel abroad. The short answer: beauticians earn steadier salaries and visa-ready certification, while makeup artists command higher per-booking rates on seasonal work. If you're choosing between the two (or deciding how to combine them), this is the honest comparison we walk students through at free counseling.",
      },
      { type: "h2", text: "What each role actually does" },
      {
        type: "p",
        text: "A beautician runs a broad service menu: facials and skin treatments, threading, waxing, basic hair services, manicures, and everyday makeup. The work is recurring — the same clients return monthly — and it anchors salons and beauty clinics. A makeup artist specializes narrowly and deeply: bridal looks, party and photoshoot makeup, HD and airbrush techniques, draping and styling coordination. The work is episodic — booked per event, peaking hard in wedding season — and commands higher per-booking rates (bridal packages typically run NPR 8,000–30,000 in the Kathmandu market) with less predictable volume.",
      },
      { type: "h2", text: "Beautician vs makeup artist salary in Nepal" },
      {
        type: "list",
        items: [
          "Salon beautician (employed): Rs 20,000–40,000/month in Kathmandu, stable year-round with seasonal bonuses.",
          "Makeup artist (freelance): per-booking rates from a few thousand rupees for party looks to substantially more for full bridal packages; busy artists in wedding season out-earn salaried beauticians, but off-season months run lean.",
          "Salon/studio owner (beautician skillset): exceeds salaried income within the first year for most graduates who open their own studios.",
          "Combined profile: beauticians who add professional bridal makeup raise both their salary band and their freelance ceiling — the strongest earning profile of the three.",
        ],
      },
      { type: "h2", text: "Self-employment: which is easier to start?" },
      {
        type: "p",
        text: "Both are among the lowest-capital businesses in Nepal, but the shapes differ. A beautician's self-employment is location-based: a home parlour or rented chair builds a repeat client base within walking distance, and income grows predictably with the client list. A makeup artist's self-employment is portfolio-based: your Instagram grid and word-of-mouth from each wedding drive the next booking, so the first 6–12 months are spent building visible work. Beautician businesses start slower but compound; makeup artistry can spike early if one bridal season goes well.",
      },
      { type: "h2", text: "Abroad demand: Gulf salon jobs for certified beauticians" },
      {
        type: "p",
        text: "Gulf salons hire certified beauticians at AED 1,500–2,500/month — and what they certify is the broad beautician menu: skin treatments, hygiene standards, and bridal makeup under one qualification. Pure makeup artistry is harder to visa-verify abroad because it lacks a standardized skill-test stream; candidates applying for salon visas are far stronger with a certified beautician qualification that includes bridal makeup competencies. If abroad is your plan, train as a beautician first and let makeup artistry be your specialization inside it.",
      },
      { type: "h2", text: "Training routes compared" },
      {
        type: "p",
        text: "Our Makeup & Beautician course (3 months, NPR 15,000) covers the full beautician menu plus bridal makeup mastery — skin science, facials, threading, day-to-bridal makeup, hair styling essentials, and the salon-business module — and maps to NSTB Level 1 (Assistant Beautician) and Level 2 (Beautician). Students who want to deepen the styling side add the Hair Styling course (2 months, NPR 10,000), and those targeting the home-visit market add Nail Art Training (6 weeks, NPR 8,000) for the fastest-return add-on skill. A freelance makeup-only career is possible from the same course — you simply weight your portfolio toward bridal work.",
      },
      { type: "h2", text: "Which should you choose?" },
      {
        type: "list",
        items: [
          "Choose the beautician route if you want stable income, repeat clients, a future salon, or a Gulf salon visa.",
          "Choose the makeup-artist specialization if you love event work, build a strong portfolio fast, and can ride seasonal income swings.",
          "Choose the combined profile if you want the highest ceiling — it is also what Gulf employers actually certify.",
          "Unsure? Start with the full beautician course; the makeup-artist path stays open to you afterward by default.",
        ],
      },
      {
        type: "cta",
        heading: "Train the full beautician skillset",
        text: "Makeup & Beautician — 3 months, NPR 15,000, NSTB Level 1 & 2 mapped, with bridal mastery and a salon-business module. Next batch enrolling now.",
        buttonLabel: "View the Makeup & Beautician course",
        href: "/courses/beauty-and-wellness/makeup-beautician-course/",
      },
      {
        type: "cta",
        heading: "Add the styling edge",
        text: "Pair it with professional cutting, coloring and bridal hair — the combination neighborhood salons book out every wedding season.",
        buttonLabel: "View the Hair Styling course",
        href: "/courses/beauty-and-wellness/hair-styling-course/",
      },
      {
        type: "faq",
        faqs: [
          {
            question: "Can I work abroad as a makeup artist only?",
            answer: "Gulf salon visas are built around certified beautician qualifications. A beautician certificate that includes bridal makeup competencies is far stronger for visa files than a makeup-only portfolio.",
          },
          {
            question: "Which career earns more in Kathmandu?",
            answer: "Salaried beauticians earn Rs 20,000–40,000/month steadily; freelance makeup artists can out-earn them in wedding season but earn less predictably off-season. Combined profiles and studio owners earn the most.",
          },
          {
            question: "Do I need +2 to train in either field?",
            answer: "No. There is no formal education requirement — SEE passed is preferred but not mandatory. Consistent practice matters far more than academic background.",
          },
        ],
      },
    ],
  },
  {
    slug: "barista-course-vs-on-the-job-training-nepal",
    title: "Barista Course vs On-the-Job Training in Nepal: Is It Worth It?",
    excerpt:
      "Barista course vs on-the-job training in Nepal: Kathmandu's café job market, what cafés actually teach, the Gulf hotel angle, and the honest math.",
    category: "Careers",
    date: "Sep 16, 2026",
    dateISO: "2026-09-16",
    readTime: "8 min read",
    cover: "/blog-barista-comparison.webp",
    coverAlt: "Barista pouring latte art behind the counter of a warm Kathmandu café",
    body: [
      {
        type: "p",
        text: "Barista course vs on-the-job training in Nepal — which route actually pays off? Every aspiring barista in Kathmandu faces the same fork: pay NPR 9,000 for a 1-month barista course, or hunt for a café job that trains you on the job. Both routes produce working baristas. But they produce different baristas, on different timelines, with different options afterward — especially if the Gulf is on your horizon. Here is the honest comparison, including when on-the-job training is genuinely the better call.",
      },
      { type: "h2", text: "Barista jobs in Kathmandu: the café market right now" },
      {
        type: "p",
        text: "Kathmandu's specialty café scene keeps expanding — new cafés open across the Valley every month, and trained baristas start at Rs 18,000–28,000/month. The catch is at the entry point: most cafés hiring 'trainee baristas' are actually hiring waiters who might get machine time eventually. The counter is the café's revenue engine, and owners don't hand it to untrained staff during service. That is the structural reason on-the-job entry takes longer than it looks.",
      },
      { type: "h2", text: "What on-the-job training actually teaches you" },
      {
        type: "p",
        text: "Working up from service staff teaches real things a course cannot: customer pressure at rush hour, the rhythm of a specific café's workflow, and how a business actually runs. But it teaches them on one machine, with one coffee blend, at your employer's pace — and the espresso fundamentals (extraction science, grind calibration, milk texture) are exactly the things busy cafés have no time to explain. Plenty of working baristas with a year of service experience have never dialed in a grinder, because nobody ever let them.",
      },
      { type: "h2", text: "What a course adds that a job doesn't" },
      {
        type: "list",
        items: [
          "Structured fundamentals: extraction, dosing, grind calibration, and milk science taught deliberately, not absorbed by accident.",
          "Volume of practice: daily shots and daily pours in a café-simulator lab — hundreds of repetitions in a month, more machine time than most junior baristas get in half a year.",
          "Latte art to a testable standard: heart, tulip, and rosetta poured on demand, which is exactly what job interviews and skill tests assess.",
          "A CTEVT-affiliated certificate: the document that turns 'I worked in a café' into verifiable proof — decisive for Gulf applications and increasingly for Kathmandu's better cafés.",
          "Mock café shifts: real-speed service practice with feedback, so your first real Friday rush isn't your first-ever rush.",
        ],
      },
      { type: "h2", text: "The Gulf hotel angle — where the gap becomes decisive" },
      {
        type: "p",
        text: "Gulf hotels and café chains hire Nepali baristas at AED 1,200–2,000/month — but they hire certified baristas. Recruiters test espresso extraction and latte art at interview, and the visa file needs training proof that a reference letter from a Kathmandu café cannot provide. International credentials like SCA (Specialty Coffee Association) certificates carry weight with specialty employers, but for the visa file a verifiable CTEVT-affiliated, NSTB-mapped certificate is the standard recruiters expect. On-the-job experience abroad is a fine second step; as a first step it closes the very door most people learn barista skills to open. This is the single strongest argument for the course route.",
      },
      { type: "h2", text: "Is a barista course worth it? The honest cost-benefit math" },
      {
        type: "p",
        text: "A 1-month course costs NPR 9,000 including all coffee, milk, and certification. The alternative — applying for café jobs untrained — typically means 1–3 months of rejections or waiter-level pay (Rs 12,000–15,000) before touching the machine. Course graduates pass barista interviews within weeks and start at trained-barista wages; most recover the full fee within their first month of skilled work. Even in the purely local scenario, the course is the cheaper route once opportunity cost is counted. The exception: if a café owner you know has genuinely promised machine training from day one, take it — then certify later to keep the abroad option alive.",
      },
      { type: "h2", text: "The verdict: barista course or on-the-job training?" },
      {
        type: "list",
        items: [
          "For a Kathmandu café job fast: course first — you interview as a trained barista, not a hopeful waiter.",
          "For Gulf hotels and cafés: course is effectively mandatory — certification and tested skills are the entry requirement.",
          "For pure café-business knowledge: nothing beats working in one — do it after you're trained, at a better wage.",
          "Best combined play: 1-month course → 6–12 months of real café work → Gulf application with both certificate and experience.",
        ],
      },
      {
        type: "cta",
        heading: "Train on commercial machines, not trial-and-error",
        text: "Barista Training — 1 month, NPR 9,000, all materials included, taught by an SCA-certified trainer. Daily shots, daily pours, mock café shifts.",
        buttonLabel: "View the Barista Training course",
        href: "/courses/hospitality-and-culinary/barista-training/",
      },
      {
        type: "faq",
        faqs: [
          {
            question: "Can I get a café job in Kathmandu without any training?",
            answer: "Yes, but usually as service staff at waiter wages with no guaranteed machine time. Trained applicants skip that queue and interview directly for barista roles at Rs 18,000–28,000/month.",
          },
          {
            question: "Do Gulf employers accept café experience instead of a certificate?",
            answer: "Rarely. Gulf recruiters test practical skills at interview and require verifiable training proof for the visa file — a CTEVT-affiliated certificate plus demonstrated latte art is the standard expectation.",
          },
          {
            question: "Is one month really enough to become a barista?",
            answer: "For entry-level professional competency, yes — the intensity matters more than the calendar. Daily espresso and latte-art practice for a month exceeds the machine time most untrained café staff accumulate in half a year.",
          },
        ],
      },
    ],
  },
  {
    slug: "what-is-vocational-training-nepal-guide",
    title: "What Is Vocational Training? A Nepal-Specific Guide (2026)",
    excerpt:
      "What is vocational training? How Nepal's CTEVT system actually works, who it's built for, and the real SEE and +2 pathways into skilled work.",
    category: "Careers",
    date: "Sep 19, 2026",
    dateISO: "2026-09-19",
    readTime: "10 min read",
    cover: "/blog-what-is-vocational.webp",
    coverAlt: "Nepali students practicing hands-on trade skills in a bright Kathmandu workshop",
    body: [
      {
        type: "p",
        text: "Vocational training is education built around a specific occupation — you learn a trade by doing it, mostly hands-on, in weeks or months rather than years. Yet it remains the most talked-about and least clearly explained corner of Nepal's education system. Parents hear it's 'an alternative to +2'. Students hear it leads abroad. Employers complain they can't find skilled workers while thousands of graduates hunt for jobs. All of these are partly true — and none of them explains what vocational training actually is, who runs it, and how to use it well. This is the Nepal-specific guide we wish every SEE graduate and parent read before making the next decision.",
      },
      { type: "h2", text: "What vocational training actually means" },
      {
        type: "p",
        text: "Vocational training means learning to do a job by doing it. Instead of studying the theory of electricity for years, you spend most of your hours wiring practice panels; instead of reading about hospitality, you pull espresso shots daily. In Nepal, short-cycle vocational courses — the segment policy documents call TVET (technical and vocational education and training) — run from 6 weeks to 3 months at private and public institutes, with roughly 80% of hours hands-on. The output is not a degree — it is a verifiable, certifiable skill that employers can test.",
      },
      { type: "h2", text: "What is the difference between CTEVT and NSTB?" },
      {
        type: "p",
        text: "Two government bodies anchor the system, and knowing the difference saves you from expensive mistakes. CTEVT (the Council for Technical Education and Vocational Training) is the national regulator: it affiliates training institutes, approves curricula, and sets standards. When you choose an institute, CTEVT affiliation is the baseline check — it means the curriculum, instructors, and certificates sit inside the national system. NSTB (the National Skill Testing Board) is the certifier: it conducts practical skill tests and issues the National Skill Certificate — the Level 1 and Level 2 cards — proving to employers, manpower agencies, and foreign visa processes that you can actually perform the trade to a government-assessed standard. Experienced workers without formal training can be assessed the same way through RPL (recognition of prior learning).",
      },
      {
        type: "p",
        text: "The clean way to think about it: CTEVT affiliation governs the training, NSTB governs the testing. A strong institute gives you both — affiliated training plus exam preparation mapped to the NSTB competency list.",
      },
      { type: "h2", text: "Who vocational training is for" },
      {
        type: "list",
        items: [
          "SEE graduates not continuing to +2 — the fastest legitimate route to a skilled income, with no academic prerequisite for most trades.",
          "+2 or bachelor's graduates whose degree isn't converting to a job — a trade skill adds employability in months, not years.",
          "Workers preparing for foreign employment — certified skills are the difference between helper wages and skilled wages abroad (a 50–100% gap).",
          "Aspiring business owners — salons, cafés, contracting services, and home-visit beauty businesses all start with the trade skill itself.",
          "Career changers — evening and morning shifts exist precisely so you can train while working.",
        ],
      },
      { type: "h2", text: "The SEE and +2 pathways, honestly explained" },
      {
        type: "p",
        text: "After SEE, Nepal offers three realistic routes: academic +2, long-cycle technical education (CTEVT diploma programs of 3 years, such as the diploma in engineering), and short-cycle vocational training (6 weeks to 3 months per trade). They are not enemies. Many students combine them — a vocational course during or after +2 for immediate income, or a trade skill now and academic study later. What matters is matching the route to the goal: if you need income within months or plan to apply for foreign employment, short-cycle vocational training with NSTB certification is the direct path. If you want a supervisory engineering career in Nepal, the diploma route fits better. The mistake is drifting into neither — unskilled work while 'deciding'.",
      },
      { type: "h2", text: "How much does vocational training cost in Nepal, and how long does it take?" },
      {
        type: "p",
        text: "Short-cycle trade courses in Kathmandu run from Rs 8,000 to Rs 25,000 depending on trade and duration — nail art at the low end (6 weeks), the elderly caregiver course at the high end (3 months, including first aid/CPR certification). Installment plans are standard. For context: most graduates recover the full fee within their first month of skilled work, and the certificate is a lifetime credential in the national database. Duration runs 6 weeks to 3 months; the trades mapped to NSTB Level 1 & 2 (electrician, beautician, caregiver, carpentry) cluster around the 390-hour, 3-month standard that foreign employers recognize.",
      },
      { type: "h2", text: "How to choose an institute without getting burned" },
      {
        type: "list",
        items: [
          "Verify CTEVT affiliation before paying anything — ask for the registration number.",
          "Ask how many hours are practical. Anything under 70% hands-on for a trade course is a red flag.",
          "Ask who teaches. Active trade professionals teach current standards; full-time lecturers often teach dated ones.",
          "Ask about NSTB exam mapping and mock tests — the exam is practical, so your practice must be too.",
          "Ask where the last three batches actually got placed. Real institutes name employers; weak ones name statistics.",
        ],
      },
      {
        type: "cta",
        heading: "Want help mapping your route?",
        text: "Free counseling, zero obligation — we'll map your education, budget, and goals to the right trade and the right batch.",
        buttonLabel: "Get free career counseling",
        href: "/contact-and-counseling/",
      },
      {
        type: "faq",
        faqs: [
          {
            question: "Is vocational training only for students who failed SEE?",
            answer: "No — and this is the most damaging myth in Nepal. Vocational training is for anyone who wants a verifiable skill: SEE graduates, +2 graduates, bachelor's holders, and working adults. Many top-performers choose it deliberately for speed to income.",
          },
          {
            question: "Is a vocational certificate valid for government jobs in Nepal?",
            answer: "CTEVT-affiliated certificates and NSTB level cards are government-recognized credentials in the national database. Specific job requirements vary, but the credentials themselves carry official standing.",
          },
          {
            question: "Can I do vocational training and continue academic study?",
            answer: "Yes. Many students work in their trade while continuing +2 or a bachelor's. A trade certificate never blocks further education — it funds it.",
          },
        ],
      },
    ],
  },
  {
    slug: "vocational-training-vs-technical-training-difference",
    title: "Vocational Training vs Technical Training: What's the Difference?",
    excerpt:
      "What is the difference between vocational and technical training in Nepal? Durations, costs, credentials, and career outcomes — plainly explained.",
    category: "Careers",
    date: "Sep 23, 2026",
    dateISO: "2026-09-23",
    readTime: "8 min read",
    cover: "/blog-vocational-vs-technical.webp",
    coverAlt: "Workshop bench with electrical tools and carpentry tools side by side in warm light",
    body: [
      {
        type: "p",
        text: "Search for training options in Nepal and you'll hit both terms within minutes — sometimes on the same page, sometimes meaning the same thing, sometimes not. Institutes call themselves 'technical and vocational'; CTEVT's own name contains both words. Are they different? Mostly yes, and the difference matters when you're choosing between a 3-month course and a 3-year program. Here is the plain-language explanation.",
      },
      { type: "h2", text: "What is the difference between vocational and technical training?" },
      {
        type: "p",
        text: "The short answer: vocational training teaches a specific occupation so you can perform it: barista, beautician, mason, caregiver. It is short (weeks to months), overwhelmingly practical, and ends in trade-level certification. Technical training teaches the broader technical foundation behind a family of occupations — electrical engineering technology, civil engineering technology, mechanical trades — and typically runs 1 to 3 years, ending in a diploma or pre-diploma qualification. Vocational training makes you job-ready in one trade fast; technical training makes you supervisory-ready across a field slowly.",
      },
      { type: "h2", text: "Side-by-side comparison" },
      {
        type: "list",
        items: [
          "Duration: vocational = 6 weeks to 3 months per trade; technical = typically 1–3 years (diploma / pre-diploma programs).",
          "Content: vocational = one occupation, 70–80% hands-on practice; technical = a field of study with theory, math, and design alongside practicals.",
          "Entry requirement: vocational = usually none (SEE preferred, not mandatory); technical diploma = SEE with set grades.",
          "Credential: vocational = course certificate plus NSTB Level 1/2 skill card; technical = CTEVT diploma (e.g., Diploma in Electrical Engineering).",
          "Cost: vocational = Rs 8,000–25,000 per course; technical diploma = significantly more across multiple years.",
          "First income: vocational = within weeks of graduating; technical = after the full program, at higher starting designations.",
          "Typical first job: vocational = skilled tradesperson (electrician, barista, beautician); technical = junior technician, site supervisor, sub-engineer.",
        ],
      },
      { type: "h2", text: "Why Nepal blurs the two" },
      {
        type: "p",
        text: "The confusion is structural, not accidental. CTEVT — the Council for Technical Education and Vocational Training — regulates both tracks, and its name fuses them. NSTB then certifies individuals at trade level regardless of which track they came through: a diploma holder and a 3-month course graduate can sit the same NSTB electrician skill test and earn the same National Skill Certificate. On the ground, many 'technical training centers' mostly run short vocational courses, and many people say 'technical' when they mean 'vocational'. When comparing options, ignore the label on the signboard and ask the concrete questions: how long, how practical, and which credential at the end?",
      },
      { type: "h2", text: "Which one fits which goal?" },
      {
        type: "list",
        items: [
          "Goal: income within 3–4 months → vocational training.",
          "Goal: skilled work abroad (Gulf, Europe, Israel, Japan) → vocational training plus NSTB certification — foreign employers test trade skills, not diplomas.",
          "Goal: supervisory or junior-engineer roles in Nepal's construction/industry → technical diploma.",
          "Goal: your own salon, café, or contracting service → vocational training, then business practice.",
          "Goal: keeping long-term options open → vocational first (income now), diploma later if the career calls for it — the trade certificate never blocks further study.",
        ],
      },
      { type: "h2", text: "A concrete example: the electrical pathway" },
      {
        type: "p",
        text: "Take the electrical field. The vocational route is a 3-month Electrician Training course: 390 hours of house wiring, panels, and motor repair, mapping to the NSTB Level 1 & 2 exam, leading to Rs 25,000–45,000/month locally or QAR 1,200–1,800/month in the Gulf. The technical route is a 3-year CTEVT diploma in electrical engineering technology, leading to junior technician and supervisor roles. Neither is 'better' — they answer different questions. The expensive mistake is enrolling in the long route when you needed the short one, or assuming a short course qualifies you for supervisory designations.",
      },
      { type: "h2", text: "The bottom line" },
      {
        type: "p",
        text: "In Nepal's job market, vocational training is the fast lane to a verified, certifiable trade skill — the one that feeds you this year and travels abroad. Technical training is the slow lane to supervisory qualification — the one that pays off over a decade. Most people comparing the two actually need the vocational lane now; the technical lane can always be added later, funded by the trade income you already have.",
      },
      {
        type: "cta",
        heading: "See what the vocational route looks like",
        text: "Our most in-demand trade: Electrician Training — 3 months, 390 practical hours, NSTB Level 1 & 2 mapped, NPR 15,000 all-in.",
        buttonLabel: "View the Electrician Training course",
        href: "/courses/construction-and-electrical/electrician-training/",
      },
      {
        type: "faq",
        faqs: [
          {
            question: "Is vocational training lower quality than technical training?",
            answer: "No — they serve different purposes. Vocational training is deep and practical within one occupation; technical training is broader and more theoretical across a field. For performing a trade, vocational training is often the more rigorous preparation.",
          },
          {
            question: "Which is better for foreign employment?",
            answer: "Vocational training plus an NSTB skill card. Foreign employers and visa processes test practical trade competency — the exact thing vocational courses and NSTB exams certify.",
          },
          {
            question: "Can I do a technical diploma after a vocational course?",
            answer: "Yes. Many workers do exactly this — earning in their trade while planning further study. Entry requirements for diploma programs are academic (SEE grades), so a vocational certificate never disqualifies you.",
          },
        ],
      },
    ],
  },
  {
    slug: "self-employment-ideas-after-beauty-wellness-course",
    title: "Self-Employment Ideas After a Beauty & Wellness Course in Nepal",
    excerpt:
      "Self-employment ideas after a beauty and wellness course in Nepal: home salons, bridal freelancing, home visits — with real startup costs in rupees.",
    category: "Careers",
    date: "Sep 27, 2026",
    dateISO: "2026-09-27",
    readTime: "10 min read",
    cover: "/blog-self-employment-beauty.webp",
    coverAlt: "Cozy home salon corner with a mirror, chair and makeup kit in warm natural light",
    body: [
      {
        type: "p",
        text: "What can you actually do for self-employment after a beauty and wellness course in Nepal? The beauty and wellness trade is Nepal's most self-employment-friendly skill: low startup capital, repeat customers, flexible hours, and demand that peaks reliably every wedding season. Most of our beauty graduates don't wait to be hired — they start earning from their own clients within weeks of finishing. But 'start your own salon' is advice, not a plan. Here are seven realistic self-employment routes after a beauty and wellness course, with the actual startup costs and the mistakes that sink each one.",
      },
      { type: "h2", text: "1. Home salon corner" },
      {
        type: "p",
        text: "The classic first step: convert a well-lit room or corner of your home into a service space — a styling chair, a mirror, a wash basin, sterilization equipment, and your product kit. Realistic startup: Rs 60,000–150,000 depending on what your home already provides. The economics work because you carry no rent and your first clients are your own network; a neighborhood home salon charging market rates for threading, facials, and hair services can match a salaried beautician's income (Rs 20,000–40,000/month) within months. The mistake to avoid: skipping hygiene standards. Visible sterilization is what turns relatives into regulars and regulars into referrals.",
      },
      { type: "h2", text: "2. Freelance bridal makeup and styling" },
      {
        type: "p",
        text: "The highest per-booking income in the trade. A bridal package — makeup, hair, draping, touch-up kit — commands NPR 8,000–30,000 per booking in the Kathmandu market, and wedding seasons can fill a calendar months ahead. Startup is your professional kit (Rs 40,000–100,000 for quality long-wear products) plus a portfolio, which you begin building during training itself. The growth lever is visible work: every bride's photos are your advertisement. The mistake: underpricing early and training the market to expect it. Price at market from booking one; discount through added service, not lower rates.",
      },
      { type: "h2", text: "3. Home-visit beauty services" },
      {
        type: "p",
        text: "No premises at all: you bring the service to the client's home — facials, waxing, threading, party makeup, mehendi-day packages. Startup is essentially your portable kit (Rs 25,000–60,000). Home visits command a convenience premium and build intensely loyal client bases, especially among clients who won't visit salons. Nail services fit this model perfectly — a Nail Art graduate running home-visit gel extensions with repeat monthly fill-ins has one of the lowest-cost, highest-retention microbusinesses in the Valley. The mistake: no booking system. Home-visit businesses live or die on scheduling discipline and confirmed deposits.",
      },
      { type: "h2", text: "4. Chair rental in an established salon" },
      {
        type: "p",
        text: "The middle path between employment and ownership: rent a chair in an existing salon for a fixed monthly fee or revenue share, serve your own clients, keep your own pricing. Startup is just your personal kit, since the salon provides premises, basin, and footfall. This is the lowest-risk way to test whether your client list can sustain a future salon of your own — and salon owners prefer trained renters because your service quality reflects on their brand.",
      },
      { type: "h2", text: "5. Full salon business" },
      {
        type: "p",
        text: "The destination, usually in year one or two rather than month one. A small two-to-three-chair salon in a Kathmandu neighborhood realistically costs Rs 300,000–800,000 to open: deposit and rent, chairs and basins, wash station, sterilization, signage, initial stock, and business registration (ward office registration is straightforward for a sole proprietorship; PAN registration follows). The salons that survive share three habits: a service menu priced from real costing, repeat-client systems (packages, reminders), and staff training as the business grows. Our beautician course's salon-business module covers exactly these — pricing, client retention, and registration basics — because technique alone doesn't keep a salon open.",
      },
      { type: "h2", text: "6. Add-on services that raise every ticket" },
      {
        type: "list",
        items: [
          "Nail art add-on (6-week course): raises average billing per salon or home-visit client with almost no extra space.",
          "Hair styling specialization (2-month course): bridal buns and party updos convert makeup bookings into full bridal packages.",
          "Men's grooming corner: a barber chair beside a ladies' salon doubles the household catchment of the same premises.",
          "Product retail: selling the products you already use adds margin with zero service time.",
        ],
      },
      { type: "h2", text: "7. Training and content, later" },
      {
        type: "p",
        text: "Once your own practice is established and visibly successful, two further income lines open: taking junior trainees (formally, once you have the experience base and certification level), and local-language beauty content — tutorial videos and live demos that now function as the top of the funnel for every other idea on this list. Neither works before you have real, bookable skill; both work extremely well after.",
      },
      { type: "h2", text: "The sequence that works" },
      {
        type: "p",
        text: "The pattern across our most successful graduates is consistent: complete the full Makeup & Beautician course first (the broad menu is what early clients actually buy), start with the lowest-capital route that fits your situation — home visits, home corner, or a rented chair — reinvest into a portfolio and better kit through your first wedding season, and open premises only when your booked weeks prove the demand. Skill first, clients second, rent third. Reverse that order and the business pays rent on an empty chair.",
      },
      {
        type: "cta",
        heading: "Get the skill the businesses are built on",
        text: "Makeup & Beautician — 3 months, NPR 15,000, NSTB Level 1 & 2 mapped, with a dedicated salon-business module. Day and evening batches.",
        buttonLabel: "View the Makeup & Beautician course",
        href: "/courses/beauty-and-wellness/makeup-beautician-course/",
      },
      {
        type: "cta",
        heading: "Start smaller, start faster",
        text: "Nail Art Training — 6 weeks, NPR 8,000. The lowest-capital route to home-visit income, and the highest-margin add-on for any salon.",
        buttonLabel: "View the Nail Art course",
        href: "/courses/beauty-and-wellness/nail-art-training/",
      },
      {
        type: "faq",
        faqs: [
          {
            question: "How much money do I need to start a home beauty business in Nepal?",
            answer: "A home-visit kit starts around Rs 25,000–60,000; a home salon corner Rs 60,000–150,000; a small neighborhood salon Rs 300,000–800,000 including deposit, equipment, stock, and registration.",
          },
          {
            question: "Do I need to register a home salon as a business?",
            answer: "Yes, once you operate commercially. Ward-level sole-proprietorship registration followed by PAN is the standard, straightforward route — our course's business module walks you through it.",
          },
          {
            question: "How fast can I earn back the course fee?",
            answer: "Most graduates working with their own clients recover the NPR 15,000 beautician course fee within their first one to two months of paid services; nail-art graduates often recover Rs 8,000 within weeks.",
          },
        ],
      },
    ],
  },
];

export const postBySlug = (slug: string) => posts.find((p) => p.slug === slug);

export const blogCategories = ["All Posts", "Certification", "Foreign Employment", "Careers", "Salaries"] as const;
