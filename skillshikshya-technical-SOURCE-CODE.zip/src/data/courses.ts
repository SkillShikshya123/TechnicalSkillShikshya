export interface CurriculumModule {
  week: string;
  title: string;
  points: string[];
}

export interface CourseFAQ {
  question: string;
  answer: string;
}

export interface Course {
  slug: string;
  name: string;
  h1: string;
  category: string;
  categorySlug: string;
  duration: string;
  fee: number;
  feeLabel: string;
  badge: string | null;
  image: string;
  imageAlt: string;
  description: string;
  primaryKeywords: string[];
  longTailKeywords: string[];
  overview: string;
  whoItsFor: { title: string; description: string }[];
  curriculum: CurriculumModule[];
  eligibility: string;
  nstbLevel: string;
  outcomes: {
    localSalary: string;
    abroadNote: string;
    roles: string[];
  };
  faqs: CourseFAQ[];
  relatedSlugs: string[];
}

export const courses: Course[] = [
  {
    slug: "electrician-training",
    name: "Electrician Training",
    h1: "Electrician Training Course in Nepal",
    category: "Construction & Electrical",
    categorySlug: "construction-and-electrical",
    duration: "3 Months",
    fee: 15000,
    feeLabel: "NPR 15,000",
    badge: "Highly Popular",
    image: "/course-electrician.webp",
    imageAlt: "electrician student practicing house wiring, Kathmandu training lab",
    description:
      "Domestic house wiring, 3-phase panels, MCB/RCCB safety, inverter & solar backup, and motor repair basics.",
    primaryKeywords: ["electrician training in Nepal", "electrician course fee in Nepal"],
    longTailKeywords: ["house wiring course Kathmandu", "electrician salary in Nepal", "3-phase wiring training Kathmandu", "electrician course for Gulf job"],
    overview:
      "Looking for practical electrician training in Nepal that actually gets you hired? Our 3-month Electrician Training course in Kathmandu is built around real house wiring practice — not classroom theory. From day one you work on live training panels: single-phase and 3-phase domestic wiring, MCB/RCCB installation, earthing systems, inverter and solar backup setup, and motor repair basics, guided by a licensed electrical engineer who still works in the trade. The 390-hour curriculum maps directly to the National Skill Testing Board (NSTB) Level 1 and Level 2 practical exams — the government credential manpower agencies and Gulf employers ask for — and as a CTEVT-affiliated institute your certificate is nationally recognized and verifiable. Graduates take wiring and maintenance jobs across Kathmandu Valley (including NEA contractor crews), start their own electrical contracting services, or deploy to Qatar, Saudi Arabia, Croatia, and Romania on skilled-worker visas. Morning and evening shifts, 390 hours of structured practice, and placement support through our 30+ employer and manpower agency network.",
    whoItsFor: [
      {
        title: "Local Job Seeker",
        description:
          "Get hired as a wiring technician, maintenance electrician, or site electrician in Kathmandu Valley's construction boom.",
      },
      {
        title: "Self-Employment",
        description:
          "Start your own residential wiring and repair service — our graduates run contracting businesses across Lalitpur and Kathmandu.",
      },
      {
        title: "Foreign-Employment Prep",
        description:
          "NSTB Level 1 & 2 mapping plus mock skill tests for Gulf, Croatia, and Romania skilled-worker visas.",
      },
    ],
    curriculum: [
      { week: "Weeks 1–2", title: "Electrical Fundamentals & Safety", points: ["Current, voltage, resistance & power basics", "PPE, lockout-tagout & safe work habits", "Tools, testers & multimeter practice"] },
      { week: "Weeks 3–4", title: "Domestic House Wiring I", points: ["Single-phase circuits & cable sizing", "Switch, socket & lighting point installation", "Conduit laying & surface wiring practice"] },
      { week: "Weeks 5–6", title: "Domestic House Wiring II", points: ["Distribution boards, MCB & RCCB installation", "Earthing systems & leakage protection", "Full mock-house wiring project"] },
      { week: "Weeks 7–8", title: "Industrial Panels & 3-Phase Motors", points: ["Three-phase supply & control panels", "Motor winding basics & fault finding", "Contactors, relays & starters"] },
      { week: "Weeks 9–10", title: "Fault Diagnosis, Inverter & Solar", points: ["Tracing short circuits & open circuits", "Inverter & solar backup installation basics", "Energy metering & NEA billing basics"] },
      { week: "Weeks 11–12", title: "NSTB Skill Test Preparation", points: ["Mock NSTB Level 1 & 2 practical exams", "Timed wiring tasks with assessor feedback", "Documentation & exam application support"] },
    ],
    eligibility: "No formal education requirement — you can join right after SEE. Motivation and discipline matter more than marks.",
    nstbLevel: "Maps to NSTB Level 1 & Level 2 (Electrician)",
    outcomes: {
      localSalary: "Rs 25,000–45,000/month in Kathmandu Valley",
      abroadNote:
        "Gulf (Qatar/UAE): QAR 1,200–1,800/mo · Europe (Croatia/Romania): €1,400–2,200/mo. NSTB-certified electricians qualify for skilled-tier wages 50–100% above helper wages.",
      roles: ["Wiring Technician", "Maintenance Electrician", "Site Electrician", "Electrical Contractor (self-employed)"],
    },
    faqs: [
      {
        question: "How long is the electrician course in Nepal?",
        answer: "Our electrician training runs 3 months — 390 hours of structured practical training at our New Baneshwar, Kathmandu lab. Morning and evening shifts let working students attend.",
      },
      {
        question: "What is the electrician course fee in Nepal?",
        answer: "At SkillShikshya the full electrician course fee is NPR 15,000, covering all lab materials and your certification exam fee. A 50/50 interest-free installment plan and a 5% upfront-payment discount are available.",
      },
      {
        question: "Can I join electrician training after SEE?",
        answer: "Yes. SEE passed is preferred but not mandatory — there is no formal education requirement. We assess motivation and commitment during free counseling before enrollment.",
      },
      {
        question: "Is the electrician certificate valid for foreign employment?",
        answer: "Yes. SkillShikshya is CTEVT affiliated and the curriculum maps directly to NSTB Level 1 & 2 — the qualification card manpower agencies and Gulf/European visa processes require for skilled-electrician deployment.",
      },
      {
        question: "What is the salary after an electrician course in Nepal?",
        answer: "Graduate electricians earn Rs 25,000–45,000/month in Kathmandu Valley, rising with industrial and 3-phase panel experience. Abroad, certified electricians earn QAR 1,200–1,800/month in the Gulf and €1,400–2,200/month in Croatia and Romania.",
      },
      {
        question: "Can this course help me get an NEA job?",
        answer: "Yes — the course covers exactly what Nepal Electricity Authority (NEA) contractor crews look for: house wiring, energy metering, earthing, and 3-phase distribution. An NSTB Level 1/2 certificate strengthens applications to NEA contractors and utilities.",
      },
      {
        question: "Do you teach inverter and solar installation?",
        answer: "Yes. The fault-diagnosis module includes inverter and solar backup installation basics — one of the fastest-growing income streams for electricians in Kathmandu.",
      },
    ],
    relatedSlugs: ["carpentry-training", "elderly-caregiver-training", "barista-training"],
  },
  {
    slug: "carpentry-training",
    name: "Carpentry Training",
    h1: "Carpentry Training Course in Nepal",
    category: "Construction & Electrical",
    categorySlug: "construction-and-electrical",
    duration: "3 Months",
    fee: 14000,
    feeLabel: "NPR 14,000",
    badge: null,
    image: "/course-carpentry.webp",
    imageAlt: "carpentry student using power tools on a wooden frame, Kathmandu workshop",
    description:
      "Furniture making, traditional joinery, formwork & shuttering, power tools, and blueprint reading.",
    primaryKeywords: ["carpentry training in Nepal", "furniture making course Kathmandu"],
    longTailKeywords: ["furniture maker NSTB Level 1 course", "joinery and shuttering training Nepal", "carpentry training for foreign employment"],
    overview:
      "Carpentry training in Nepal rarely goes beyond basic woodworking — ours covers the full trade. Over 3 months in our Kathmandu workshop you train on real benches and real power tools — planers, circular saws, routers, sanders — mastering timber selection, traditional joinery, blueprint reading, modular furniture making, and the formwork and shuttering skills construction sites pay a premium for. Around 80% of your hours are workshop practice: you complete full furniture pieces before you graduate, not just watch demonstrations. The syllabus maps to NSTB Furniture Maker competencies from Level 1 upward, and as a CTEVT-affiliated institute your certificate is nationally recognized. Graduates join furniture workshops and interior fit-out companies across Kathmandu Valley, start custom furniture services of their own, or go abroad — certified carpenters are a top-10 demand trade in the Gulf and Eastern Europe. Morning and evening shifts, installment payment options, and placement support through our employer network.",
    whoItsFor: [
      {
        title: "Local Job Seeker",
        description:
          "Join furniture workshops, interior fit-out companies, and construction crews across Kathmandu Valley.",
      },
      {
        title: "Self-Employment",
        description:
          "Start a custom furniture or repair service — graduates supply modular kitchens, doors, and frames locally.",
      },
      {
        title: "Foreign-Employment Prep",
        description:
          "Carpentry is a top-10 Gulf demand trade; NSTB-aligned practice prepares you for skill-test visa requirements.",
      },
    ],
    curriculum: [
      { week: "Weeks 1–2", title: "Wood Science & Hand Tools", points: ["Timber types, seasoning & selection", "Measuring, marking & hand-tool mastery", "Workshop safety & PPE"] },
      { week: "Weeks 3–4", title: "Joinery Fundamentals", points: ["Mortise & tenon, dovetail, lap joints", "Gluing, clamping & assembly technique", "Frame construction practice"] },
      { week: "Weeks 5–6", title: "Power Tools & Machinery", points: ["Circular saw, planer, router & sander operation", "Blade selection & maintenance", "Precision cutting exercises"] },
      { week: "Weeks 7–8", title: "Blueprint Reading & Modular Furniture", points: ["Reading drawings & cutting lists", "Modular furniture standards & board materials", "Estimating material & costing a job"] },
      { week: "Weeks 9–10", title: "Furniture Making Project Build", points: ["Full furniture piece construction", "Sanding, filling & surface preparation", "Polishing, painting & finishing"] },
      { week: "Weeks 11–12", title: "Site Work, Formwork & NSTB Prep", points: ["Door/window & shutter installation practice", "Formwork & shuttering basics for construction sites", "Mock NSTB practical tasks & feedback"] },
    ],
    eligibility: "No formal education requirement. You can join after SEE; physical fitness for workshop work is recommended.",
    nstbLevel: "Maps to NSTB Level 1 & Level 2 (Carpenter)",
    outcomes: {
      localSalary: "Rs 22,000–40,000/month in Kathmandu Valley",
      abroadNote:
        "Carpenters are a top Gulf & Eastern Europe demand trade; certified candidates move from helper to skilled wage tiers.",
      roles: ["Furniture Maker", "Site Carpenter", "Fit-out Technician", "Custom Furniture Business Owner"],
    },
    faqs: [
      {
        question: "How long is the carpentry course in Nepal?",
        answer: "The course runs 3 months at our Kathmandu workshop, with morning and evening shifts. Around 80% of hours are hands-on practice — you complete full furniture pieces before graduating.",
      },
      {
        question: "What is the fee for carpentry training in Kathmandu?",
        answer: "The full fee is NPR 14,000 including materials and the certification exam fee. 50/50 interest-free installments or a 5% upfront discount are available.",
      },
      {
        question: "Can I join carpentry training after SEE?",
        answer: "Yes — there is no formal education requirement and SEE passed is preferred. Physical fitness for workshop work is recommended.",
      },
      {
        question: "Is the carpentry certificate valid for foreign employment?",
        answer: "Yes — we are CTEVT affiliated and the syllabus maps to NSTB Furniture Maker competencies from Level 1 upward, the credential Gulf and Eastern European employers verify. Carpentry is a top-10 Gulf demand trade.",
      },
      {
        question: "What is the salary after a carpentry course in Nepal?",
        answer: "Graduate carpenters earn roughly Rs 22,000–40,000/month in Kathmandu Valley, with formwork/shuttering specialists and self-employed furniture makers earning more. Gulf and Eastern Europe wages are significantly higher at skilled tiers.",
      },
      {
        question: "What is the difference between furniture making and shuttering carpentry?",
        answer: "Furniture making — joinery, modular kitchens, doors and frames — is finished workshop work, while shuttering/formwork carpentry builds the concrete moulds used on construction sites. Our course covers both: furniture modules first, formwork basics in the final weeks.",
      },
      {
        question: "Can I start my own furniture workshop after this course?",
        answer: "Yes. The blueprint and modular design module includes material estimating and job costing, and graduates have gone on to supply modular kitchens, doors, and frames across Lalitpur and Kathmandu.",
      },
    ],
    relatedSlugs: ["electrician-training", "baking-pastry-course", "elderly-caregiver-training"],
  },
  {
    slug: "makeup-beautician-course",
    name: "Makeup & Beautician",
    h1: "Makeup & Beautician Course in Nepal",
    category: "Beauty & Wellness",
    categorySlug: "beauty-and-wellness",
    duration: "3 Months",
    fee: 15000,
    feeLabel: "NPR 15,000",
    badge: "Abroad Ready",
    image: "/course-beautician.webp",
    imageAlt: "beautician student practicing bridal makeup on a model, Kathmandu salon lab",
    description:
      "Bridal & party makeup, skin treatments, hair styling, salon hygiene, and parlour business basics.",
    primaryKeywords: ["beautician course in Nepal", "makeup course Kathmandu"],
    longTailKeywords: ["bridal makeup course Kathmandu", "beauty parlour training Nepal", "assistant beautician Level 1 vs beautician Level 2"],
    overview:
      "Looking for a beautician course in Nepal that leads to real income? Our 3-month Makeup & Beautician course in Kathmandu covers bridal and party makeup, skin analysis and treatments, hair styling fundamentals, and professional salon hygiene — practiced daily on real models in our salon-style lab, not on paper charts. Your instructor is an award-winning salon owner who runs her own studio in Lazimpat. The course is designed for three outcomes: joining Kathmandu's growing salon and beauty-clinic industry, opening your own beauty parlour (many graduates launch within 3 months), or working abroad, where Gulf salons hire certified beauticians at AED 1,500–2,500 per month. We map the syllabus to NSTB Assistant Beautician Level 1 and Beautician Level 2 competencies, and your CTEVT-affiliated certificate is nationally recognized. Bridal specialists in Kathmandu charge NPR 8,000–30,000 per booking in wedding season — so we also teach pricing, client handling, and beauty-business registration basics. Day and evening batches, installment plans, and free career counseling before you enroll.",
    whoItsFor: [
      {
        title: "Local Job Seeker",
        description:
          "Work in salons, beauty clinics, and bridal studios across Kathmandu — demand peaks every wedding season.",
      },
      {
        title: "Self-Employment",
        description:
          "Open your own salon or home-visit makeup service — we teach pricing, client handling, and business registration basics.",
      },
      {
        title: "Foreign-Employment Prep",
        description:
          "Gulf salons hire certified beauticians at AED 1,500–2,500/month; your CTEVT certificate strengthens the visa file.",
      },
    ],
    curriculum: [
      { week: "Weeks 1–2", title: "Skin Science & Salon Hygiene", points: ["Skin types, analysis & consultation", "Salon safety, sterilization & hygiene standards", "Product knowledge: primers to setting sprays"] },
      { week: "Weeks 3–4", title: "Facials & Skin Treatments", points: ["Cleansing, exfoliation & extraction technique", "Facial massage & mask application", "Threading and basic hair removal"] },
      { week: "Weeks 5–6", title: "Makeup Fundamentals", points: ["Base, contouring & color theory", "Day, party & photoshoot looks", "Eye makeup: liner, lashes & blending"] },
      { week: "Weeks 7–8", title: "Bridal Makeup Mastery", points: ["Nepali bridal looks: traditional & modern", "Long-wear techniques & touch-up kits", "Full bridal trials on real models"] },
      { week: "Weeks 9–10", title: "Hair Styling Essentials", points: ["Blow-drying, curling & straightening", "Bridal buns, braids & party updos", "Saree & dupatta draping for bridal clients"] },
      { week: "Weeks 11–12", title: "Salon Business & Portfolio", points: ["Pricing, packages & client retention", "Beauty business registration & CTEVT certification", "Portfolio shoot & graduation assessment"] },
    ],
    eligibility: "No formal education requirement — you can join after SEE. Passion and consistency matter most.",
    nstbLevel: "Maps to NSTB Level 1 & Level 2 (Beautician)",
    outcomes: {
      localSalary: "Rs 20,000–40,000/month; salon owners earn more",
      abroadNote:
        "Gulf salons (UAE/Qatar): AED 1,500–2,500/month for certified beauticians.",
      roles: ["Salon Beautician", "Bridal Makeup Artist", "Beauty Clinic Therapist", "Salon Owner"],
    },
    faqs: [
      {
        question: "How long is the beautician course in Nepal?",
        answer: "The course runs 3 months with day and evening batches at our Kathmandu salon lab. You practice on real models from the first week.",
      },
      {
        question: "What is the fee for a beautician course in Kathmandu?",
        answer: "The full fee is NPR 15,000 including all practice materials and the certification exam fee. 50/50 interest-free installments or a 5% upfront discount apply.",
      },
      {
        question: "Can I join the beautician course after SEE?",
        answer: "Yes — there is no formal education requirement. SEE passed is preferred, but passion and consistency matter most in this trade.",
      },
      {
        question: "Is the beautician certificate valid for Gulf salon jobs?",
        answer: "Yes. SkillShikshya is CTEVT affiliated and the syllabus maps to NSTB competencies — the certificate plus skill-test alignment Gulf salon employers and visa processes look for. Certified beauticians earn AED 1,500–2,500/month in UAE and Qatar salons.",
      },
      {
        question: "What is the salary after a beautician course in Nepal?",
        answer: "Salon jobs pay Rs 20,000–40,000/month locally. Bridal makeup artists charge NPR 8,000–30,000 per booking in wedding season, and graduates who open their own studios typically exceed salaried income within the first year.",
      },
      {
        question: "What is the difference between Assistant Beautician Level 1 and Beautician Level 2?",
        answer: "NSTB Level 1 (Assistant Beautician) certifies entry-level skills — facials, threading, basic makeup — while Level 2 (Beautician) covers independent full-service work including bridal. Our 3-month course builds Level 1 competence and prepares you to test for Level 2 after shop-floor experience.",
      },
      {
        question: "Can I open my own beauty parlour after this course?",
        answer: "Yes — many graduates launch within 3 months. The final module covers pricing, packages, client retention, and beauty-business registration in Nepal, and home-visit bridal makeup needs almost no startup capital.",
      },
    ],
    relatedSlugs: ["nail-art-training", "hair-styling-course", "barber-training"],
  },
  {
    slug: "nail-art-training",
    name: "Nail Art Training",
    h1: "Nail Art Course in Nepal",
    category: "Beauty & Wellness",
    categorySlug: "beauty-and-wellness",
    duration: "6 Weeks",
    fee: 8000,
    feeLabel: "NPR 8,000",
    badge: "Popular",
    image: "/course-nailart.webp",
    imageAlt: "student applying gel nail art with fine brush, salon training lab Kathmandu",
    description:
      "Gel nail extensions, acrylic shapes, overlays, fill-ins, and 3D nail art design.",
    primaryKeywords: ["nail art course in Nepal", "nail technician course Kathmandu"],
    longTailKeywords: ["gel nail extension training Nepal", "acrylic nails course Kathmandu", "nail technician course for GCC salons"],
    overview:
      "This Nail Art course in Nepal is the fastest way to turn a creative hobby into real income: 6 weeks of hands-on nail technician training in our Kathmandu salon lab. You master gel nail extensions, acrylic shaping, overlays, fill-ins, and 3D nail art design with professional kits provided — every session is live practice with instructor feedback, and no prior salon experience is needed. Nail services are among the fastest-growing home-visit and studio businesses in Kathmandu, with low startup costs and high repeat clientele. Graduates run home-visit nail extension services, rent chairs in established salons, or add nail art to an existing beauty business — and Gulf (GCC) salons regularly hire trained nail technicians from Nepal. As a CTEVT-affiliated institute, your certificate is government-recognized, which matters if you later expand into a full salon business or apply for salon work abroad. Flexible payment options and free career counseling before you enroll.",
    whoItsFor: [
      {
        title: "Local Job Seeker",
        description:
          "Join nail studios and salons in Kathmandu, or rent a chair and build your own client base.",
      },
      {
        title: "Self-Employment",
        description:
          "Home-visit nail extension services are a proven graduate business — low startup cost, high repeat bookings.",
      },
      {
        title: "Add-On Skill",
        description:
          "Beauticians and salon owners add nail art to raise average billing per client.",
      },
    ],
    curriculum: [
      { week: "Week 1", title: "Nail Anatomy, Hygiene & Prep", points: ["Nail structure & health assessment", "Sanitization & workstation setup", "Cuticle care, shaping & buffing"] },
      { week: "Week 2", title: "Gel Polish & Basic Nail Art", points: ["Gel polish application & curing", "French tips & color gradients", "Dotting, striping & marble effects"] },
      { week: "Week 3", title: "Gel Nail Extensions", points: ["Tip selection & application", "Building apex & structure", "Curing, filing & finishing"] },
      { week: "Week 4", title: "Acrylic Nail Systems", points: ["Acrylic mixing ratios & bead control", "Popular shapes: square, almond, coffin", "Overlays and natural-nail strengthening"] },
      { week: "Week 5", title: "3D Nail Art & Advanced Designs", points: ["3D flowers & encapsulation", "Chrome, foil & glitter effects", "Fill-ins, repairs & safe removal"] },
      { week: "Week 6", title: "Client Work & Business Setup", points: ["Timed full-set practice on models", "Pricing, booking & home-visit setup", "Portfolio photos & graduation assessment"] },
    ],
    eligibility: "No formal education requirement. Open to complete beginners — no salon experience needed.",
    nstbLevel: "CTEVT-affiliated certificate; NSTB beauty stream alignment",
    outcomes: {
      localSalary: "Rs 15,000–35,000/month; home-visit artists set their own rates",
      abroadNote:
        "Nail technicians are hired by Gulf (GCC) salons; combine with the beautician course for a stronger visa file.",
      roles: ["Nail Technician", "Home-Visit Nail Artist", "Salon Chair Renter", "Beauty Business Add-On"],
    },
    faqs: [
      {
        question: "How long is the nail art course in Nepal?",
        answer: "6 weeks of practical, hands-on sessions at our Kathmandu salon lab. You complete full gel and acrylic sets on models before graduating.",
      },
      {
        question: "What is the fee for a nail art course in Kathmandu?",
        answer: "NPR 8,000 total, including practice materials and certification. Installment options are available — ask at free counseling.",
      },
      {
        question: "Can beginners join the nail art course?",
        answer: "Yes — the course is beginner-friendly with no formal education requirement. We start from nail anatomy, hygiene, and prep before any product work.",
      },
      {
        question: "Is the nail technician certificate valid for salon jobs abroad?",
        answer: "Your CTEVT-affiliated certificate is government-recognized. For GCC salon visas we recommend pairing it with the Makeup & Beautician course and an NSTB skill test — Gulf salons regularly hire trained Nepali nail technicians.",
      },
      {
        question: "What is the salary after a nail art course in Nepal?",
        answer: "Salon nail technicians earn Rs 15,000–35,000/month locally. Home-visit nail artists with repeat clients often earn more on flexible hours, since gel and acrylic sets command premium per-session rates.",
      },
      {
        question: "What is the difference between gel nails and acrylic nails?",
        answer: "Gel extensions are cured under a UV/LED lamp and look glossier and more natural; acrylics air-dry from a liquid-powder bead and are stronger for long shapes. You learn both systems — gel in week 3, acrylic in week 4 — so you can serve any client preference.",
      },
      {
        question: "Can I earn from home after a nail art course?",
        answer: "Yes — home-visit nail services are a proven graduate business in Kathmandu with low startup cost: a kit, a lamp, and transport. The final week covers pricing, booking, and home-visit setup.",
      },
    ],
    relatedSlugs: ["makeup-beautician-course", "hair-styling-course", "barber-training"],
  },
  {
    slug: "hair-styling-course",
    name: "Hair Styling Course",
    h1: "Hair Styling Course in Nepal",
    category: "Beauty & Wellness",
    categorySlug: "beauty-and-wellness",
    duration: "2 Months",
    fee: 10000,
    feeLabel: "NPR 10,000",
    badge: null,
    image: "/course-hairstyling.webp",
    imageAlt: "hair styling student practicing cutting technique in a Kathmandu salon lab",
    description:
      "Professional hair cutting, coloring, perming, straightening, and bridal styling.",
    primaryKeywords: ["hair styling course in Nepal", "hair cutting course Kathmandu"],
    longTailKeywords: ["hairdressing training Nepal", "hair coloring course Kathmandu", "ladies and gents hair cutting course"],
    overview:
      "Our Hair Styling Course in Nepal is a 2-month professional program in Kathmandu covering cutting, coloring, perming, straightening, and treatment services for all hair types — ladies' and gents'. Training happens in a working salon environment with mannequin practice and supervised real clients, taught by stylists who serve paying customers every day. You learn modern layer cuts, bridal styling, color theory and chemical safety for coloring and rebonding, and the client-consultation skills a Kathmandu salon expects from day one. Graduates work as salon hair stylists, specialize in bridal hair, or open their own parlours; three neighborhood salons book our recent graduates every wedding season. The course is CTEVT affiliated and maps to NSTB Level 1 (Hair Stylist), so your hairdressing certificate carries government recognition in Nepal and supports salon visa applications abroad. With day and evening batches and installment payments, this is one of the fastest routes into the beauty industry — from first scissor cut to paid client work in about eight weeks.",
    whoItsFor: [
      {
        title: "Local Job Seeker",
        description:
          "Salons across Kathmandu hire trained stylists year-round, with peak demand in wedding season.",
      },
      {
        title: "Self-Employment",
        description:
          "Open a home parlour or freelance bridal styling service with a portfolio you build during the course.",
      },
      {
        title: "Career Upgrade",
        description:
          "Working beauticians add cutting & coloring to serve full salon menus and raise income.",
      },
    ],
    curriculum: [
      { week: "Weeks 1–2", title: "Hair Science & Cutting Basics", points: ["Hair types, growth patterns & consultation", "Sectioning, tension & scissor control", "One-length, graduation & layer cuts"] },
      { week: "Weeks 3–4", title: "Advanced Cutting & Styling", points: ["Texturizing, thinning & razor work", "Blow-dry styling & finishing", "Bridal and party updos"] },
      { week: "Weeks 5–6", title: "Hair Coloring & Chemical Treatments", points: ["Color theory, levels & mixing", "Highlights, balayage & global color", "Patch testing & chemical safety"] },
      { week: "Weeks 7–8", title: "Perming, Straightening & Client Work", points: ["Perming & rebonding technique", "Keratin & hair spa treatments", "Supervised real-client services & portfolio"] },
    ],
    eligibility: "No formal education requirement. You can join after SEE; the course starts from zero.",
    nstbLevel: "Maps to NSTB Level 1 (Hair Stylist)",
    outcomes: {
      localSalary: "Rs 18,000–35,000/month; bridal specialists charge per booking",
      abroadNote:
        "Salon stylists are hired across the Gulf; CTEVT certification supports skilled-visa applications.",
      roles: ["Salon Hair Stylist", "Bridal Hair Specialist", "Color Technician", "Parlour Owner"],
    },
    faqs: [
      {
        question: "How long is the hair styling course in Nepal?",
        answer: "2 months, with day and evening batches at our Kathmandu salon lab. You practice on mannequins first, then serve real clients under supervision.",
      },
      {
        question: "What is the fee for a hair styling course in Kathmandu?",
        answer: "NPR 10,000 including materials and certification. 50/50 interest-free installments or a 5% upfront discount are available.",
      },
      {
        question: "What qualification do I need for a hair cutting course?",
        answer: "No formal education requirement — the course starts from zero, from scissor handling and sectioning to advanced coloring. SEE passed is preferred.",
      },
      {
        question: "Is the hair styling certificate valid for foreign employment?",
        answer: "Yes — it is CTEVT affiliated and maps to NSTB Level 1 (Hair Stylist), which Gulf salon employers and visa processes recognize.",
      },
      {
        question: "What is the salary after a hair styling course in Nepal?",
        answer: "Salon stylists earn Rs 18,000–35,000/month locally. Bridal hair specialists charge per booking and are fully booked through wedding season, often exceeding salaried income.",
      },
      {
        question: "Does the course cover both ladies' and gents' hair?",
        answer: "Yes — cutting, coloring, and treatments for all hair types. If you want to specialize in men's fades, beard design, and straight-razor work, our Barber Training course is the better fit.",
      },
      {
        question: "Can I open my own parlour after this hair styling course?",
        answer: "Yes. Graduates open home parlours and freelance bridal styling services using the portfolio they build during the course — three neighborhood salons also book our graduates every wedding season.",
      },
    ],
    relatedSlugs: ["makeup-beautician-course", "barber-training", "nail-art-training"],
  },
  {
    slug: "barber-training",
    name: "Barber Training",
    h1: "Barber Training Course in Nepal",
    category: "Beauty & Wellness",
    categorySlug: "beauty-and-wellness",
    duration: "2 Months",
    fee: 10000,
    feeLabel: "NPR 10,000",
    badge: null,
    image: "/course-barber.webp",
    imageAlt: "barber student trimming a beard with clippers, Kathmandu barbershop training",
    description:
      "Classic & modern men's grooming — fades, scissor cuts, beard design, and straight-razor shaves.",
    primaryKeywords: ["barber training in Nepal", "barber course Kathmandu"],
    longTailKeywords: ["fade and beard training Kathmandu", "barbershop business course Nepal", "barber salary in Kathmandu"],
    overview:
      "Barber training in Nepal has almost no serious competition — and serious demand. Our 2-month Barber Training course in Kathmandu is a hands-on program covering classic and modern men's grooming: clipper work, skin fades, scissor cuts, beard design and line-ups, hot-towel straight-razor shaves, and professional hygiene standards. You train in a barbershop-style lab on live models from week two, guided by working barbers who cut hair for paying clients every day. Men's grooming is one of the most stable local businesses in Nepal — every neighborhood supports multiple barbershops — and skilled barbers are in steady demand in Gulf men's salons as well. Graduates join established barbershops, rent chairs, or open their own shops with modest startup capital, and we teach shop setup and pricing so the business side is covered too. The course is CTEVT affiliated and maps to NSTB Level 1 (Barber), giving you a government-recognized certificate for employment in Nepal and abroad. Day and evening batches, flexible payment plans.",
    whoItsFor: [
      {
        title: "Local Job Seeker",
        description:
          "Barbershops in every Kathmandu neighborhood hire trained barbers — a stable, year-round trade.",
      },
      {
        title: "Self-Employment",
        description:
          "Open your own barbershop with modest startup capital; we cover shop setup and pricing.",
      },
      {
        title: "Foreign-Employment Prep",
        description:
          "Gulf men's salons hire skilled barbers; a CTEVT certificate strengthens your visa application.",
      },
    ],
    curriculum: [
      { week: "Weeks 1–2", title: "Tools, Hygiene & Clipper Basics", points: ["Clipper, trimmer & razor maintenance", "Sanitization & hygiene standards", "Guard systems, basic buzz cuts & tapering"] },
      { week: "Weeks 3–4", title: "Skin Fades & Scissor Work", points: ["Skin fades, low/mid/high fades", "Scissor-over-comb technique", "Classic gentlemen's cuts"] },
      { week: "Weeks 5–6", title: "Beard Design & Straight-Razor Shaving", points: ["Beard shaping & line-ups", "Hot-towel preparation & straight-razor shave", "Facial & scalp massage basics"] },
      { week: "Weeks 7–8", title: "Styling, Client Service & Barbershop Setup", points: ["Modern textured styles & product use", "Client consultation & time management", "Supervised full services + shop setup basics"] },
    ],
    eligibility: "No formal education requirement. Complete beginners welcome — join after SEE or any time.",
    nstbLevel: "Maps to NSTB Level 1 (Barber)",
    outcomes: {
      localSalary: "Rs 18,000–35,000/month; shop owners earn more",
      abroadNote:
        "Gulf men's salons are a steady employer of Nepali barbers with certified training.",
      roles: ["Barbershop Barber", "Freelance Grooming Specialist", "Chair Renter", "Barbershop Owner"],
    },
    faqs: [
      {
        question: "How long is barber training in Nepal?",
        answer: "Our barber course runs 2 months with day and evening batches in Kathmandu. You cut real hair on live models from the second week.",
      },
      {
        question: "What is the fee for a barber course in Kathmandu?",
        answer: "NPR 10,000 including practice tools and certification. Installments and a 5% upfront discount are available.",
      },
      {
        question: "Can I join barber training with no experience?",
        answer: "Yes — complete beginners are welcome and there is no formal education requirement. Training starts with clipper control and hygiene before live cutting.",
      },
      {
        question: "Is the barber certificate valid for Gulf salon jobs?",
        answer: "Yes — it is CTEVT affiliated and maps to NSTB Level 1 (Barber), recognized by Gulf men's salon employers and visa processes. Gulf salons are a steady employer of certified Nepali barbers.",
      },
      {
        question: "What is a barber's salary in Kathmandu?",
        answer: "Barbers earn Rs 18,000–35,000/month in Kathmandu. Shop owners earn more, and Gulf-employed barbers earn considerably higher skilled-tier wages.",
      },
      {
        question: "Do you teach skin fades and straight-razor shaving?",
        answer: "Yes — weeks 3–4 cover skin, low, mid, and high fades plus scissor-over-comb work; weeks 5–6 cover beard shaping, line-ups, and hot-towel straight-razor shaves.",
      },
      {
        question: "How much does it cost to open a barbershop in Nepal?",
        answer: "A small neighborhood shop needs modest startup capital — mainly chairs, mirrors, clippers, and rent. The final module covers shop setup and pricing, and many graduates start by renting a single chair in an established barbershop.",
      },
    ],
    relatedSlugs: ["hair-styling-course", "makeup-beautician-course", "nail-art-training"],
  },
  {
    slug: "barista-training",
    name: "Barista Training",
    h1: "Barista Training Course in Kathmandu",
    category: "Hospitality & Culinary",
    categorySlug: "hospitality-and-culinary",
    duration: "1 Month",
    fee: 9000,
    feeLabel: "NPR 9,000",
    badge: "High Demand",
    image: "/course-barista.webp",
    imageAlt: "barista student pouring latte art rosetta, espresso training café Kathmandu",
    description:
      "Espresso extraction, milk frothing, latte art styles, brew methods, machine care, and café service skills.",
    primaryKeywords: ["barista training in Kathmandu", "barista course fee in Nepal"],
    longTailKeywords: ["espresso and latte art course Kathmandu", "SCA vs CTEVT barista certificate", "barista course for cafe jobs abroad"],
    overview:
      "Barista training in Kathmandu that employers actually respect: our intensive 1-month Barista Training course runs inside a real café-simulator lab with commercial espresso machines. You learn espresso extraction, grind calibration, milk steaming and frothing, latte art styles, machine cleaning and maintenance, plus the service soft skills cafés actually hire for. Your instructor is an SCA-certified barista trainer and former head barista at Himalayan Java — so you learn today's specialty-coffee standards, not outdated theory, alongside a CTEVT-affiliated certificate that supports foreign-employment documentation. Kathmandu's café scene is booming and our graduates pass job interviews within weeks; several now work at popular coffee chains in Koteshwor and beyond. Barista skills also travel well: Gulf hotels and cafés hire certified Nepali baristas at AED 1,200–2,000 per month. The course is intensely practical — daily shots, daily pours, and full mock café shifts that feel exactly like real service. Fast, affordable, and consistently one of our highest-demand courses.",
    whoItsFor: [
      {
        title: "Local Job Seeker",
        description:
          "Kathmandu's café boom means constant hiring — graduates pass interviews within weeks of finishing.",
      },
      {
        title: "Self-Employment",
        description:
          "Plan a coffee cart or small café with costing, menu design, and workflow basics covered in class.",
      },
      {
        title: "Foreign-Employment Prep",
        description:
          "Gulf hotels and cafés hire certified baristas at AED 1,200–2,000/month; your CTEVT certificate supports the visa file.",
      },
    ],
    curriculum: [
      { week: "Week 1", title: "Coffee Foundations & Espresso Extraction", points: ["Beans, roast levels & freshness", "Grind calibration & dosing", "Espresso extraction & tasting"] },
      { week: "Week 2", title: "Milk Frothing & Latte Art", points: ["Milk steaming & microfoam texture", "Heart, tulip & rosetta pours", "Full espresso-menu practice"] },
      { week: "Week 3", title: "Brew Methods & Machine Care", points: ["V60, French press & cold brew", "Machine cleaning, backflushing & maintenance", "Speed & workflow drills"] },
      { week: "Week 4", title: "Service Skills & Mock Café Shifts", points: ["Order taking & customer service", "Café hygiene & workstation setup", "Full mock café shifts with real-time feedback"] },
    ],
    eligibility: "No formal education requirement. SEE passed preferred — a great short-term course right after SEE.",
    nstbLevel: "CTEVT-affiliated certificate; hospitality skill-test alignment",
    outcomes: {
      localSalary: "Rs 18,000–28,000/month in Kathmandu cafés",
      abroadNote:
        "Gulf hotels & cafés (UAE/Qatar): AED 1,200–2,000/month for certified baristas.",
      roles: ["Café Barista", "Head Barista (with experience)", "Coffee Cart Owner", "Hotel F&B Staff (Gulf)"],
    },
    faqs: [
      {
        question: "How long is barista training in Kathmandu?",
        answer: "Just 1 month — intensive and practical, with daily espresso and latte-art practice in our café-simulator lab plus full mock café shifts.",
      },
      {
        question: "What is the barista course fee in Nepal?",
        answer: "Barista courses in Nepal range from about NPR 10,500 to NPR 85,000 depending on certification. At SkillShikshya the fee is NPR 9,000 all-inclusive — coffee, milk, materials, and CTEVT-affiliated certification — with installment options.",
      },
      {
        question: "Can I join barista training after SEE?",
        answer: "Yes — no formal education requirement. SEE passed is preferred; enthusiasm for coffee and customer service matters most.",
      },
      {
        question: "Is the barista certificate valid for cafe jobs abroad?",
        answer: "Yes — it is CTEVT affiliated, and Gulf hotels and cafés hiring Nepali baristas recognize certified training at AED 1,200–2,000/month. We also support NSTB skill-test preparation for foreign-employment documentation.",
      },
      {
        question: "What is a barista's salary in Nepal?",
        answer: "Kathmandu cafés pay Rs 18,000–28,000/month to start; experienced and head baristas earn more as the specialty-coffee scene grows. Gulf hotel and café jobs pay AED 1,200–2,000/month.",
      },
      {
        question: "What is the difference between an SCA and a CTEVT/NSTB barista certificate?",
        answer: "SCA (Specialty Coffee Association) is the global industry credential specialty cafés know; CTEVT/NSTB is the Nepal government credential needed for foreign-employment paperwork. Our trainer is SCA-certified, so you learn specialty standards while earning the CTEVT-affiliated certificate visa processes require.",
      },
      {
        question: "Do I need my own espresso machine to learn barista skills?",
        answer: "No — you train on commercial espresso machines, grinders, and brewers in our café-simulator lab. All coffee, milk, and materials are included in the fee.",
      },
    ],
    relatedSlugs: ["baking-pastry-course", "bartending-course", "makeup-beautician-course"],
  },
  {
    slug: "baking-pastry-course",
    name: "Baking & Pastry",
    h1: "Baking and Pastry Course in Kathmandu",
    category: "Hospitality & Culinary",
    categorySlug: "hospitality-and-culinary",
    duration: "2 Months",
    fee: 12000,
    feeLabel: "NPR 12,000",
    badge: null,
    image: "/course-baking.webp",
    imageAlt: "student piping cream on a cake in a bright training kitchen, Kathmandu",
    description:
      "Commercial breadmaking, cakes, cookies, pastries, desserts, and professional kitchen safety.",
    primaryKeywords: ["baking and pastry course in Kathmandu", "cake making course Nepal"],
    longTailKeywords: ["bakery course fee Kathmandu", "pastry chef training Nepal", "home baking business course"],
    overview:
      "Our Baking and Pastry course in Kathmandu is a 2-month commercial-kitchen program covering breadmaking, cakes, cookies, pastries, desserts, and professional kitchen safety. You bake every day in our training kitchen — measuring, mixing, proofing, baking, and decorating — until recipes become technique, from commercial breads and chiffon sponges to puff pastry and celebration cakes with piping and fondant work. The course is built for both employment and entrepreneurship: graduates join bakeries, hotels, and café kitchens as pastry cooks and cake decorators, or start home-baking businesses supplying birthday cakes and artisanal bread to Kathmandu cafés — several of our graduates already do. We teach recipe costing and pricing, so a hobby becomes a business with real margins. The course is CTEVT affiliated, and for those aiming abroad, bakery and pastry roles in Gulf hotels are a documented demand area where certified candidates stand out. Morning and evening batches, all ingredients included in the fee, and installment payment options.",
    whoItsFor: [
      {
        title: "Local Job Seeker",
        description:
          "Bakeries, hotels, and café kitchens across Kathmandu hire trained bakers and pastry assistants.",
      },
      {
        title: "Self-Employment",
        description:
          "Start a home-baking brand — graduates supply sourdough and custom cakes to Kathmandu cafés.",
      },
      {
        title: "Foreign-Employment Prep",
        description:
          "Gulf hotel bakeries hire certified pastry staff; your CTEVT certificate supports skilled-visa applications.",
      },
    ],
    curriculum: [
      { week: "Weeks 1–2", title: "Bakery Science & Breadmaking", points: ["Kitchen safety, hygiene & mise en place", "Yeast science & proofing control", "Commercial bread, buns & dinner rolls"] },
      { week: "Weeks 3–4", title: "Cakes & Sponges", points: ["Sponge, butter & chiffon cakes", "Creaming, folding & baking control", "Layering, filling & crumb coating"] },
      { week: "Weeks 5–6", title: "Cookies, Pastries & Desserts", points: ["Cookies, brownies & tarts", "Puff & shortcrust pastry", "Puddings, mousse & plated desserts"] },
      { week: "Weeks 7–8", title: "Cake Decoration, Costing & Production", points: ["Piping, fondant & celebration cakes", "Recipe costing & pricing for business", "Timed production runs & graduation showcase"] },
    ],
    eligibility: "No formal education requirement. You can join after SEE; the course starts from kitchen basics.",
    nstbLevel: "CTEVT-affiliated certificate; hospitality skill-test alignment",
    outcomes: {
      localSalary: "Rs 18,000–30,000/month; home bakers set their own margins",
      abroadNote:
        "Gulf hotel bakeries are a documented demand area for certified pastry staff.",
      roles: ["Bakery Assistant", "Pastry Cook", "Cake Decorator", "Home-Baking Business Owner"],
    },
    faqs: [
      {
        question: "How long is the baking and pastry course in Kathmandu?",
        answer: "2 months with daily hands-on baking in our training kitchen — morning and evening batches available.",
      },
      {
        question: "What is the bakery course fee in Nepal?",
        answer: "At SkillShikshya the fee is NPR 12,000 including all ingredients, materials, and certification. 50/50 interest-free installments or a 5% upfront discount apply.",
      },
      {
        question: "Can beginners join the baking and pastry course?",
        answer: "Yes — no formal education requirement; the course starts from kitchen safety, hygiene, and mise en place. SEE passed is preferred.",
      },
      {
        question: "Is the baking certificate valid for jobs abroad?",
        answer: "Yes — it is CTEVT affiliated. Gulf hotel bakeries are a documented demand area for certified pastry staff, and we guide students toward NSTB skill tests where relevant.",
      },
      {
        question: "What is the salary after a baking and pastry course in Nepal?",
        answer: "Bakery and pastry roles pay Rs 18,000–30,000/month locally. Home-baking businesses set their own margins, and Gulf hotel bakery jobs pay more.",
      },
      {
        question: "Can I start a home baking business after this course?",
        answer: "Yes — the final module covers recipe costing and pricing, and several graduates already supply sourdough, birthday cakes, and celebration cakes to Kathmandu cafés from home kitchens.",
      },
      {
        question: "Is this course enough to become a pastry chef?",
        answer: "It gives you the professional foundation — breads, sponges, pastries, plated desserts, and decoration — that hotel and bakery kitchens expect from pastry cooks. Chef-level roles come with 1–2 years of kitchen experience on top of this training.",
      },
    ],
    relatedSlugs: ["barista-training", "bartending-course", "nail-art-training"],
  },
  {
    slug: "bartending-course",
    name: "Bartending Course",
    h1: "Bartending Course in Nepal",
    category: "Hospitality & Culinary",
    categorySlug: "hospitality-and-culinary",
    duration: "1 Month",
    fee: 9000,
    feeLabel: "NPR 9,000",
    badge: null,
    image: "/course-bartending.webp",
    imageAlt: "bartending student shaking a cocktail mixer, training bar Kathmandu",
    description:
      "Mixology, classic cocktails & mocktails, speed-pouring, flair basics, and bar operations.",
    primaryKeywords: ["bartending course in Nepal", "mixology course Kathmandu"],
    longTailKeywords: ["bartender salary in Nepal", "cocktail and mocktail training Kathmandu", "bartending course for Dubai and cruise jobs"],
    overview:
      "Our Bartending course in Nepal is a 1-month Kathmandu intensive covering mixology principles, classic and contemporary cocktails and mocktails, bar equipment management, speed-pouring, and customer service. You train behind a fully equipped practice bar with professional tools — building, shaking, stirring, layering, and garnish craft — plus working flair basics, responsible service, bar hygiene, and inventory control. Kathmandu's nightlife and hotel scene keeps growing, and trained bartenders are consistently hired by bars, lounges, clubs, and hotels across the valley. The skill also travels: Gulf hotels, Dubai bars, and international cruise lines recruit certified bartenders from Nepal at significantly higher wage tiers. The course is CTEVT affiliated and fast — one month from your first pour to job-ready, with mock bar shifts that simulate real Friday-night pressure. Whether your goal is a Thamel lounge, a five-star hotel bar, or a cruise-line contract, you leave with the speed, recipes, and confidence to pass a working interview. Morning and evening batches, all practice materials included, installment payments available.",
    whoItsFor: [
      {
        title: "Local Job Seeker",
        description:
          "Bars, lounges, clubs, and hotels across Kathmandu hire trained bartenders year-round.",
      },
      {
        title: "Hospitality Career",
        description:
          "Add bartending to an F&B profile and move toward bar supervisor and F&B management roles.",
      },
      {
        title: "Foreign-Employment Prep",
        description:
          "Gulf hotels and cruise lines recruit certified Nepali bartenders at strong wage tiers.",
      },
    ],
    curriculum: [
      { week: "Week 1", title: "Bar Setup & Mixology Basics", points: ["Bar tools, glassware & workstation setup", "Spirits, liqueurs & mixer knowledge", "Pouring accuracy & jigger control"] },
      { week: "Week 2", title: "Classic Cocktails & Mocktails", points: ["Shaking, stirring & straining technique", "20+ classic cocktail & mocktail builds", "Garnish craft & presentation"] },
      { week: "Week 3", title: "Speed-Pouring, Flair & Service", points: ["Speed-pouring drills & free-pouring accuracy", "Basic flair & working flair moves", "Customer service & responsible service of alcohol"] },
      { week: "Week 4", title: "Bar Operations & Mock Shifts", points: ["Inventory, costing & wastage control", "Bar hygiene & closing procedures", "Full mock bar shifts with timed service"] },
    ],
    eligibility: "No formal education requirement. Must be 18+.",
    nstbLevel: "CTEVT-affiliated certificate; hospitality skill-test alignment",
    outcomes: {
      localSalary: "Rs 18,000–30,000/month plus tips in Kathmandu venues",
      abroadNote:
        "Gulf hotels and cruise lines recruit certified bartenders at markedly higher wages.",
      roles: ["Bartender", "Bar Supervisor (with experience)", "Hotel F&B Staff", "Cruise-line Bar Staff"],
    },
    faqs: [
      {
        question: "How long is the bartending course in Nepal?",
        answer: "1 month — intensive and practical. You train behind a fully equipped practice bar every session, ending with timed mock bar shifts.",
      },
      {
        question: "What is the fee for a bartending course in Kathmandu?",
        answer: "NPR 9,000 including all practice materials and certification. Installment options are available.",
      },
      {
        question: "What qualification do I need to join a bartending course?",
        answer: "No formal education requirement, but you must be 18 or older, in line with responsible-service standards.",
      },
      {
        question: "Is the bartending certificate valid for Dubai or cruise ship jobs?",
        answer: "Yes — it is CTEVT affiliated, and Gulf hotels, Dubai bars, and international cruise lines recruit certified bartenders from Nepal at markedly higher wage tiers.",
      },
      {
        question: "What is a bartender's salary in Nepal?",
        answer: "Kathmandu bars, lounges, and hotels pay Rs 18,000–30,000/month plus tips. Gulf and cruise-line bartending roles pay significantly more.",
      },
      {
        question: "Do you teach flair bartending?",
        answer: "Yes — week 3 covers basic and working flair moves alongside speed-pouring drills, so you can entertain guests without sacrificing service speed.",
      },
      {
        question: "Do I have to drink alcohol during bartending training?",
        answer: "No. Training focuses on technique, recipes, and service — tasting is optional and never required to master mixology.",
      },
    ],
    relatedSlugs: ["barista-training", "baking-pastry-course", "makeup-beautician-course"],
  },
  {
    slug: "elderly-caregiver-training",
    name: "Elderly Caregiver",
    h1: "Elderly Caregiver Training Course in Nepal",
    category: "Care Services",
    categorySlug: "care-services",
    duration: "3 Months",
    fee: 25000,
    feeLabel: "NPR 25,000",
    badge: "Israel/Japan Ready",
    image: "/course-caregiver.webp",
    imageAlt: "caregiver trainee assisting an elderly person walking, Kathmandu training centre",
    description:
      "Elderly health monitoring, mobility support, dementia care basics, first aid/CPR, and G2G pathway prep.",
    primaryKeywords: ["elderly caregiver training in Nepal", "caregiver course in Nepal"],
    longTailKeywords: ["390-hour CTEVT caregiver course", "caregiver training for Israel G2G", "Japan SSW kaigo caregiver course Nepal"],
    overview:
      "Elderly caregiver training in Nepal is one of the strongest overseas employment pathways open today — and our 3-month Elderly Caregiver course in Kathmandu is purpose-built for it. Structured around the 390-hour CTEVT caregiver standard, the program covers elderly health monitoring (BP, pulse, SpO2), safe mobility support and transfers, personal hygiene care, dementia and Alzheimer's care basics, nutrition support, first aid and CPR certification, and the documentation and communication skills care employers assess at interview. Practice happens in a simulated care room with real equipment: hospital beds, wheelchairs, walkers, and monitoring devices. The syllabus aligns with the Israel G2G (government-to-government) and Japan SSW/kaigo caregiver schemes, and our graduates' certificates have been officially processed by the G2G agency — several now work with elderly families in Israel and Japan, where G2G caregivers earn ¥200,000–260,000 per month. Locally, care homes and private families across Kathmandu Valley hire certified caregivers at Rs 18,000–30,000 per month. This is our most placement-focused course.",
    whoItsFor: [
      {
        title: "G2G / Israel–Japan Pathway",
        description:
          "Purpose-built for the Israel G2G and Japan SSW caregiver schemes — syllabus, documentation, and interview prep included.",
      },
      {
        title: "Local Job Seeker",
        description:
          "Care homes, hospitals, and private families in Kathmandu Valley hire certified caregivers at Rs 18,000–30,000/month.",
      },
      {
        title: "Healthcare Starter",
        description:
          "A foundation for nursing-assistant and care careers, with first aid/CPR certification included.",
      },
    ],
    curriculum: [
      { week: "Weeks 1–2", title: "Caregiving Foundations & Dementia Care", points: ["Roles, ethics & professional boundaries", "Dementia & Alzheimer's care basics", "Communication with families & daily reporting"] },
      { week: "Weeks 3–4", title: "Elderly Health Monitoring", points: ["Vital signs: BP, pulse, temperature, SpO2", "Medication reminders & schedules", "Recognizing and escalating warning signs"] },
      { week: "Weeks 5–6", title: "Mobility & Safe Transfers", points: ["Wheelchair, walker & transfer technique", "Fall prevention & safe positioning", "Bed-to-chair and assisted-walking practice"] },
      { week: "Weeks 7–8", title: "Personal Care & Hygiene", points: ["Assisted bathing, grooming & dressing", "Oral care, skin care & pressure-sore prevention", "Feeding support & nutrition basics"] },
      { week: "Weeks 9–10", title: "First Aid & CPR Certification", points: ["CPR & recovery position", "Choking, bleeding & burn response", "Emergency protocols & certification assessment"] },
      { week: "Weeks 11–12", title: "G2G Pathway & Placement Prep", points: ["Israel G2G / Japan SSW syllabus alignment", "Interview & language-support preparation", "Documentation, agency processing & mock assessments"] },
    ],
    eligibility: "No formal education requirement. SEE passed preferred. Compassion and physical fitness are essential.",
    nstbLevel: "Maps to NSTB Level 1 & 2 (Caregiver); G2G syllabus aligned",
    outcomes: {
      localSalary: "Rs 18,000–30,000/month in Kathmandu Valley",
      abroadNote:
        "Japan G2G caregivers earn ¥200,000–260,000/month; Israel G2G placements are processed through the official agency.",
      roles: ["Elderly Caregiver", "Care Home Assistant", "Private Family Caregiver", "G2G Caregiver (Israel/Japan)"],
    },
    faqs: [
      {
        question: "How long is the elderly caregiver course in Nepal?",
        answer: "3 months, structured around the 390-hour CTEVT caregiver standard, including first aid/CPR certification and G2G pathway preparation in the final weeks.",
      },
      {
        question: "What is the caregiver course fee in Nepal?",
        answer: "Many institutes charge around NPR 35,000 for a 390-hour caregiver course. At SkillShikshya the fee is NPR 25,000 all-inclusive — training materials, first aid certification, and exam fees — with installment and scholarship options.",
      },
      {
        question: "Can I join caregiver training after SEE?",
        answer: "Yes — no formal education requirement; SEE passed is preferred. Compassion, patience, and physical fitness are essential, and we assess these at free counseling.",
      },
      {
        question: "Is the caregiver certificate valid for Israel G2G or Japan SSW?",
        answer: "Yes — it is CTEVT affiliated, NSTB-aligned, and matches the G2G syllabus standard. Our graduates' certificates have been officially processed by the Israel G2G agency, and the final module prepares you for Japan SSW/kaigo interviews and documentation.",
      },
      {
        question: "What is the salary after a caregiver course in Nepal and abroad?",
        answer: "Locally, certified caregivers earn Rs 18,000–30,000/month in Kathmandu Valley. Japan G2G caregivers earn ¥200,000–260,000/month, and Israel G2G caregivers earn around NIS 6,443/month — roughly NPR 3.2 lakh.",
      },
      {
        question: "What is the age limit for caregiver jobs in Israel through G2G?",
        answer: "Current Israel G2G caregiver criteria generally require applicants to be aged 25–45, medically fit, and to hold recognized caregiver training — our course is built around those requirements.",
      },
      {
        question: "Does the caregiver course cover dementia care and first aid?",
        answer: "Yes — dementia and Alzheimer's care basics are covered in the foundations module, and weeks 9–10 deliver full first aid and CPR training with a certification assessment.",
      },
    ],
    relatedSlugs: ["electrician-training", "makeup-beautician-course", "barista-training"],
  },
];

export const courseBySlug = (slug: string) => courses.find((c) => c.slug === slug);
export const coursesByCategory = (categorySlug: string) =>
  courses.filter((c) => c.categorySlug === categorySlug);

/** Canonical nested URL helpers (site-wide single source of truth). */
export const coursePath = (c: Pick<Course, "categorySlug" | "slug">) =>
  `/courses/${c.categorySlug}/${c.slug}/`;
export const categoryPath = (categorySlug: string) => `/courses/${categorySlug}/`;
