export interface GraduateRecord {
  certificateId: string;
  name: string;
  trade: string;
  courseSlug: string;
  status: string;
  nstbLevel: string;
  placement: string;
}

export const graduates: GraduateRecord[] = [
  {
    certificateId: "SS-2026-001",
    name: "Ramesh Tamang",
    trade: "Electrician",
    courseSlug: "electrician-training",
    status: "Graduated — Certificate Verified",
    nstbLevel: "NSTB Level 2",
    placement: "Placed — Saudi Arabia (Wiring Technician)",
  },
  {
    certificateId: "SS-2026-002",
    name: "Sabina Gurung",
    trade: "Beautician",
    courseSlug: "makeup-beautician-course",
    status: "Graduated — Certificate Verified",
    nstbLevel: "NSTB Level 1",
    placement: "Self-employed — Salon Owner, Kathmandu",
  },
  {
    certificateId: "SS-2026-003",
    name: "Anish Shrestha",
    trade: "Barista",
    courseSlug: "barista-training",
    status: "Graduated — Certificate Verified",
    nstbLevel: "NSTB Level 1",
    placement: "Placed — Himalayan Java, Kathmandu",
  },
  {
    certificateId: "SS-2026-004",
    name: "Pooja Rai",
    trade: "Caregiver",
    courseSlug: "elderly-caregiver-training",
    status: "Graduated — Certificate Verified",
    nstbLevel: "NSTB Level 1",
    placement: "Placed — Israel G2G Caregiver Scheme",
  },
];

export function lookupGraduate(id: string): GraduateRecord | undefined {
  const normalized = id.trim().toUpperCase();
  return graduates.find((g) => g.certificateId === normalized);
}
