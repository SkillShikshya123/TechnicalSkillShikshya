export interface SalaryRow {
  trade: string;
  local: string;
  gulf: string;
  europe: string;
  japan: string;
  /** Key of the highlighted (highest-potential) cell in this row. */
  highlight: "local" | "gulf" | "europe" | "japan";
}

export const salaryColumns = [
  { key: "local", label: "Local (Nepal)" },
  { key: "gulf", label: "Gulf (Qatar/UAE)" },
  { key: "europe", label: "Europe (Croatia/Romania)" },
  { key: "japan", label: "Japan G2G" },
] as const;

export const salaryRows: SalaryRow[] = [
  {
    trade: "Electrician",
    local: "Rs 25,000–45,000/mo",
    gulf: "QAR 1,200–1,800/mo",
    europe: "€1,400–2,200/mo",
    japan: "—",
    highlight: "europe",
  },
  {
    trade: "Beautician",
    local: "Rs 20,000–40,000/mo",
    gulf: "AED 1,500–2,500/mo",
    europe: "—",
    japan: "—",
    highlight: "gulf",
  },
  {
    trade: "Caregiver",
    local: "Rs 18,000–30,000/mo",
    gulf: "—",
    europe: "—",
    japan: "¥200,000–260,000/mo",
    highlight: "japan",
  },
  {
    trade: "Barista",
    local: "Rs 18,000–28,000/mo",
    gulf: "AED 1,200–2,000/mo",
    europe: "—",
    japan: "—",
    highlight: "gulf",
  },
];

export const salaryDisclaimer =
  "These salary ranges are based on actual employer data and graduate reports from our Batch 2024–2026 graduates. Local estimates are for Kathmandu Valley.";
