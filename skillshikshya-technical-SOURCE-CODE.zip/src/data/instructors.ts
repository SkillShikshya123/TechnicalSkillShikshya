export interface Instructor {
  id: string;
  name: string;
  role: string;
  yearsExp: number;
  bio: string;
  credential: string;
  image: string;
}

export const instructors: Instructor[] = [
  {
    id: "suraj-khadka",
    name: "Er. Suraj Khadka",
    role: "Electrical Engineering",
    yearsExp: 14,
    bio: "Licensed electrical engineer. Wired 200+ commercial & residential projects across Kathmandu Valley. NSTB Level 2 examiner.",
    credential: "NSTB Level 2 Examiner · Licensed Electrical Engineer",
    image: "/instructor-suraj.webp",
  },
  {
    id: "sunita-maharjan",
    name: "Sunita Maharjan",
    role: "Beauty & Cosmetics",
    yearsExp: 10,
    bio: "Award-winning salon owner, Glow Studio Lazimpat. CIBTAC UK & CIDESCO certified. 800+ students trained.",
    credential: "CIBTAC UK & CIDESCO Certified · Salon Owner",
    image: "/instructor-sunita.webp",
  },
  {
    id: "suman-lama",
    name: "Barista Suman Lama",
    role: "Coffee Science & Hospitality",
    yearsExp: 8,
    bio: "SCA-certified Barista Instructor, former head barista at Himalayan Java. Specialty coffee consultant for 6 Kathmandu cafés.",
    credential: "SCA-Certified Barista Instructor · Ex-Himalayan Java",
    image: "/instructor-suman.webp",
  },
];
