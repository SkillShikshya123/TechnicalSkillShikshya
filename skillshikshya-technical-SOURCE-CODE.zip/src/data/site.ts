export const site = {
  name: "SkillShikshya Technical",
  domain: "technical.skillshikshya.com",
  url: "https://technical.skillshikshya.com",
  tagline: "Learn a skill. Get certified. Get hired.",
  description:
    "CTEVT-affiliated technical & vocational training institute in New Baneshwar, Kathmandu. Hands-on trade skills since 2018.",
  registration: "CTEVT Registered Training Centre · Reg. No. 2018-KTM-0421",
  accreditations: [
    { name: "CTEVT", descriptor: "Council for Technical Education" },
    { name: "NSTB", descriptor: "National Skill Testing Board" },
    { name: "Ministry of Labour & Employment", descriptor: "Government of Nepal" },
  ],
  contact: {
    address: "New Baneshwar, Kathmandu (Opposite Civil Hospital)",
    addressShort: "New Baneshwar, Kathmandu",
    phoneLandline: "01-4000000",
    phoneMobile: "9800-000-000",
    email: "hello@skillshikshya.com",
    hours: "Sun–Fri 9am–5pm",
    whatsapp:
      "https://wa.me/9779800000000?text=Hi%20SkillShikshya!%20I%20want%20free%20career%20counseling.",
    whatsappNumber: "9779800000000",
  },
  stats: [
    { value: 2000, suffix: "+", label: "Graduates" },
    { value: 90, suffix: "%+", label: "Placement Rate" },
    { value: 10, suffix: "", label: "Trade Courses" },
    { value: 7, suffix: "+", label: "Countries Hired" },
  ],
  partners: [
    { name: "Vrit Technology", note: "Hires our electrician graduates for facility contracts" },
    { name: "Gulf Manpower Pvt.", note: "Places certified tradespeople across the Gulf" },
    { name: "Israel G2G Agency", note: "Processes caregiver graduates for Israel G2G scheme" },
    { name: "Himalayan Java", note: "Hires our barista graduates" },
    { name: "Al-Khobar Contracting", note: "Recruits NSTB-certified electricians for Saudi projects" },
  ],
  ogImage: "/og-image.png",
} as const;

export type Site = typeof site;
