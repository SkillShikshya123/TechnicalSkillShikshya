import type { Course } from "./courses";
import { courses, courseBySlug } from "./courses";

export interface QuizOption {
  id: string;
  label: string;
  icon?: "Plane" | "Briefcase" | "Store";
}

export interface QuizQuestion {
  id: "goal" | "timeframe" | "interest";
  title: string;
  options: QuizOption[];
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: "goal",
    title: "What's your main career goal?",
    options: [
      { id: "abroad", label: "Work Abroad (Gulf, Japan, Europe)", icon: "Plane" },
      { id: "local", label: "Get a job locally in Nepal", icon: "Briefcase" },
      { id: "business", label: "Start my own business — salon / café", icon: "Store" },
    ],
  },
  {
    id: "timeframe",
    title: "How soon do you want to start earning?",
    options: [
      { id: "fast", label: "Within 1–2 months" },
      { id: "medium", label: "In about 3 months" },
      { id: "flexible", label: "I'm flexible" },
    ],
  },
  {
    id: "interest",
    title: "What kind of work do you enjoy?",
    options: [
      { id: "tools", label: "Working with tools & machines" },
      { id: "beauty", label: "Beauty & personal care" },
      { id: "food", label: "Food, coffee & hospitality" },
      { id: "care", label: "Caring for people" },
    ],
  },
];

export interface QuizAnswers {
  goal: string;
  timeframe: string;
  interest: string;
}

const interestCategory: Record<string, string> = {
  tools: "construction-electrical",
  beauty: "beauty-wellness",
  food: "hospitality-culinary",
  care: "care-services",
};

/** Abroad-biased picks per category (badge courses first). */
const abroadPick: Record<string, string> = {
  "construction-electrical": "electrician-training",
  "beauty-wellness": "makeup-beautician-course",
  "hospitality-culinary": "barista-training",
  "care-services": "elderly-caregiver-training",
};

/** Fast-timeframe picks per category (shortest courses first). */
const fastPick: Record<string, string> = {
  "construction-electrical": "electrician-training",
  "beauty-wellness": "nail-art-training",
  "hospitality-culinary": "barista-training",
  "care-services": "elderly-caregiver-training",
};

/** Business picks per category. */
const businessPick: Record<string, string> = {
  "construction-electrical": "carpentry-training",
  "beauty-wellness": "makeup-beautician-course",
  "hospitality-culinary": "baking-pastry-course",
  "care-services": "elderly-caregiver-training",
};

/** Local-job picks per category. */
const localPick: Record<string, string> = {
  "construction-electrical": "electrician-training",
  "beauty-wellness": "makeup-beautician-course",
  "hospitality-culinary": "barista-training",
  "care-services": "elderly-caregiver-training",
};

export function recommendCourse(answers: QuizAnswers): Course {
  const category = interestCategory[answers.interest] ?? "construction-electrical";
  let slug: string;
  if (answers.goal === "abroad") slug = abroadPick[category];
  else if (answers.goal === "business") slug = businessPick[category];
  else if (answers.timeframe === "fast") slug = fastPick[category];
  else slug = localPick[category];
  return courseBySlug(slug) ?? courses[4]; // fallback: electrician
}

export function quizReason(answers: QuizAnswers, course: Course): string {
  const goalText =
    answers.goal === "abroad"
      ? `working abroad — ${course.name} maps to NSTB Level 1 & 2 and strong Gulf/abroad demand`
      : answers.goal === "business"
        ? `starting your own business — ${course.name} has low startup cost and proven graduate businesses`
        : `getting a local job — ${course.name} has steady employer demand in Kathmandu Valley`;
  return `Based on your goal of ${goalText}. Duration: ${course.duration} · Fee: ${course.feeLabel}.`;
}
